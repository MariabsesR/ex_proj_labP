import java.util.Iterator;
import java.util.List;

public class Robot {

    // ...

    private String id;
    private int influence;
    private Type type;
    private boolean working;
    private boolean headOfFamily;
    private List<Robot> children;

    // ...

    /**
     * The three possible types of a Robot: ENGINEER, PROTOTYPE and GIGACHAD
     */
    public enum Type {
        ENGINEER, PROTOTYPE, GIGACHAD;
    }

    // ...

    /**
     * Add some prefix to the buffer based on the robot status.
     * 
     * @param buffer     buffer to load strings
     * @param separator  character that wll be used as separator
     * @param typeString String that represents a type
     */
    private void addStats(StringBuilder buffer, String separator, String typeString) {
        if (headOfFamily)
            buffer.append("Lord ");
        buffer.append(id);
        if (working) {
            buffer.append(" ").append(separator);
            buffer.append(typeString).append(":");
            buffer.append(influence).append(separator);
        } else {
            buffer.append("®");
        }
    }

    // This algorithm to print trees is an adaptation of the code by VasiliNovikov
    // - https://diasp.de/u/vn971
    public String toString() {
        StringBuilder buffer = new StringBuilder(50);
        print(buffer, "", "");
        return buffer.toString();
    }

    private void print(StringBuilder buffer, String prefix, String childrenPrefix) {
        buffer.append(prefix);
        switch (type) {
            case GIGACHAD:
                addStats(buffer, ":", "Æ");
                break;
            case ENGINEER:
                addStats(buffer, "|", "E");
                break;
            case PROTOTYPE:
                addStats(buffer, "|", "A");
                break;
        }
        buffer.append(GameMsg.EOL);

        for (Iterator<Robot> it = children.iterator(); it.hasNext();) {
            Robot next = it.next();
            if (it.hasNext()) {
                next.print(buffer, childrenPrefix + "├── ", childrenPrefix + "│   ");
            } else {
                next.print(buffer, childrenPrefix + "└── ", childrenPrefix + "    ");
            }
        }
    }

}
