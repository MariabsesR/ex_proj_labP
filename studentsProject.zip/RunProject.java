import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class RunProject {

    final String FILE_FORMAT = "UTF-8";

    public static void main(String[] args) throws FileNotFoundException {
        new RunProject();
    }

    /**
     * Run the LABP project 5
     * You can change the scanner input from a file to System.in to play the game in
     * the console.
     */
    RunProject() {
        try {
            try (Scanner input = new Scanner(new File("input.txt"))) {
                PrintWriter output = new PrintWriter("output.txt", FILE_FORMAT);
                smallInput(input, output);
            }
            try (Scanner input = new Scanner(new File("inputB1.txt"))) {
                PrintWriter output = new PrintWriter("outputB1.txt", FILE_FORMAT);
                bigInputB1(input, output);
            }
            try (Scanner input = new Scanner(new File("inputB2.txt"))) {
                PrintWriter output = new PrintWriter("outputB2.txt", FILE_FORMAT);
                bigInputB2(input, output);
            }
            try (Scanner input = new Scanner(new File("inputB3.txt"))) {
                PrintWriter output = new PrintWriter("outputB3.txt", FILE_FORMAT);
                bigInputB3(input, output);
            }
            try (Scanner input = new Scanner(new File("inputB4.txt"))) {
                PrintWriter output = new PrintWriter("outputB4.txt", FILE_FORMAT);
                bigInputB4(input, output);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Runs the smallest sample.
     * 
     * @param scan    input to insert the actions
     * @param printer output to print the game
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    private void smallInput(Scanner scan, PrintWriter printer)
            throws FileNotFoundException, UnsupportedEncodingException {
        String[] families = new String[] { "0", "1" };
        int[] influences = new int[] { 5, 6, };

        GameEngine game = new GameEngine(new Game(families, influences), printer);
        game.play(scan);
        printer.close();
    }

    /**
     * Runs the example number 1.
     * 
     * @param scan    input to insert the actions
     * @param printer output to print the game
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    private void bigInputB1(Scanner scan, PrintWriter printer)
            throws FileNotFoundException, UnsupportedEncodingException {

        String[] families = new String[] { "0", "1", "2" };
        int[] influences = new int[] { 10, 6, 8, };

        GameEngine game = new GameEngine(new Game(families, influences), printer);
        game.play(scan);
        printer.close();

    }

    /**
     * Runs the example number 2.
     * 
     * @param scan    input to insert the actions
     * @param printer output to print the game
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    private void bigInputB2(Scanner scan, PrintWriter printer)
            throws FileNotFoundException, UnsupportedEncodingException {

        String[] families = new String[] { "0", "1", "2", "3", "4", "5", "6" };
        int[] influences = new int[] { 10, 6, 8, 10, 35, 15, 18 };

        GameEngine game = new GameEngine(new Game(families, influences), printer);
        game.play(scan);
        printer.close();

    }

    /**
     * Runs the example number 3.
     * 
     * @param scan    input to insert the actions
     * @param printer output to print the game
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    private void bigInputB3(Scanner scan, PrintWriter printer)
            throws FileNotFoundException, UnsupportedEncodingException {

        String[] families = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        int[] influences = new int[] { 10, 6, 8, 10, 35, 15, 18, 14, 19, 34 };

        GameEngine game = new GameEngine(new Game(families, influences), printer);
        game.play(scan);
        printer.close();

    }

    /**
     * Runs the example number 4.
     * 
     * @param scan    input to insert the actions
     * @param printer output to print the game
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    private void bigInputB4(Scanner scan, PrintWriter printer)
            throws FileNotFoundException, UnsupportedEncodingException {

        String[] families = new String[] { "Stark", "Baratheon", "Martell", "Arryn",
                "Greyjoy", "Tully", "Targeryan", "Lannister", "Tyrell" };
        int[] influences = new int[] { 10, 6, 8, 20, 14, 30, 35, 30, 20 };

        GameEngine game = new GameEngine(new Game(families, influences), printer);
        game.play(scan);
        printer.close();
    }

}
