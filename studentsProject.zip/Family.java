public class Family {

    private String name;
    private Robot owner;

    // ...

    @Override
    public String toString() {
        StringBuilder stb = new StringBuilder();
        stb.append(GameMsg.EOL).append(name).append(GameMsg.EOL);
        stb.append(owner.toString());
        return stb.toString();
    }

    // ...
}
