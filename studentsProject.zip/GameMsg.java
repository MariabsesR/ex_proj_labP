public final class GameMsg {
    public final static String EOL = System.getProperty("line.separator");

    // ACTIONS
    private static final String ACTION_DESTROY = ">>Escolha um prototipo da famlia %s para ser removido";
    private static final String ACTION_OFFER = ">>Escolha para qual familia doar o prototipo";
    private static final String ACTION_CREATE = ">>Escolha o %s que devera criar um novo robo";
    private static final String ACTION_CREATE_TYPE = ">Indique de que tipo deverá ser criado. 0 para %s e 1 para %s";
    private static final String ACTION_ATTACK = ">>Escolha um robo da familia %s para atacar";
    private static final String ACTION_MERGE = ">>Escolha um robo da familia %s para se juntar a um robo de outra familia";
    private static final String ACTION_FAMILY_NAME = "  digite o nome da família:";
    private static final String ACTION_ID_ROBOT = "  digite id do robo:";
    private static final String ACTION_NEW_ROBOT_NAME = "  digite nome do novo robo:";

    // MESSAGES
    private static final String MSG_WELCOME = "Bem vindo ao jogo.";
    private static final String MSG_FAMILIES = "As famílias [%s] vão participar do jogo";
    private static final String MSG_DECISION = "Qual a decisão do senhor %s da familia %s";
    private static final String MSG_MAKE_PLAY = "A familia %s deve realizar a jogada";
    private static final String MSG_CHALLENGE_BEGINS = ">>>>> O senhor da família %s foi desafiado! <<<<<<";
    private static final String MSG_LETS_PLAY = ">>> Digite: C criar um novo robo, A atacar, M merge," +
            " O oferecer prototipo, D destruir um prototipo";
    private static final String MSG_FAMILY_ROBOT = "Selecione uma família e robo para %s %s";
    private static final String MSG_TURN_OVER = "O TURNO %d ACABOU!";
    private static final String MSG_FAMILY_OVER = ".:: Familia %s foi derrotada e não joga mais ::.";
    private static final String MSG_GAME_OVER = "~ ~ O JOGO ACABOU! A FAMILIA %s FOI A GRANDE VENCEDORA NO TURNO %d! ~ ~";
    private static final String MSG_ROBOT_FIGHT = "<< O robo %s da familia %s foi vitorioso! O robo %s da familia %s foi desativado >>";
    private static final String MSG_DUEL_RESULT = "O ganhador do duelo foi %s e ele é o novo senhor da familia. O robô %s foi derrotado e foi desativado";

    // MISC
    private static final String NO_LEADER = "sem lider";
    private static final String INVALID_PLAY = "jogada invalida";
    private static final String JOIN = "se juntar";
    private static final String ATTACK = "atacar";

    public static String destroy(String familyName) {
        return String.format(GameMsg.ACTION_DESTROY, familyName);
    }

    public static String newRobotName() {
        return ACTION_NEW_ROBOT_NAME;
    }

    public static String offer() {
        return ACTION_OFFER;
    }

    public static String create() {
        return String.format(GameMsg.ACTION_CREATE, Robot.Type.GIGACHAD);
    }

    public static String createType() {
        return String.format(GameMsg.ACTION_CREATE_TYPE, Robot.Type.ENGINEER, Robot.Type.PROTOTYPE);
    }

    public static String attack(String family) {
        return String.format(GameMsg.ACTION_ATTACK, family);
    }

    public static String merg(String familyName) {
        return String.format(GameMsg.ACTION_MERGE, familyName);
    }

    public static String familyName() {
        return ACTION_FAMILY_NAME;
    }

    public static String idRobot() {
        return ACTION_ID_ROBOT;
    }

    public static String welcome() {
        return MSG_WELCOME;
    }

    public static String familyNames(String families) {
        return String.format(MSG_FAMILIES, families);
    }

    public static String decision(String nameHead, String family) {
        return String.format(MSG_DECISION, nameHead, family);
    }

    public static String makePlay(String family) {
        return String.format(MSG_MAKE_PLAY, family);
    }

    public static String challengeBegins(String robot) {
        return String.format(MSG_CHALLENGE_BEGINS, robot);
    }

    public static String letsPlay() {
        return MSG_LETS_PLAY;
    }

    public static String familyRobotJoin(String robotId) {
        return String.format(MSG_FAMILY_ROBOT, robotId, JOIN);
    }

    public static String familyRobotAttack(String robotId) {
        return String.format(MSG_FAMILY_ROBOT, robotId, ATTACK);
    }

    public static String turnOver(int turn) {
        return String.format(MSG_TURN_OVER, turn);
    }

    public static String familyOver(String family) {
        return String.format(MSG_FAMILY_OVER, family);
    }

    public static String gameOver(String family, int turn) {
        char[] chars = { 76, 97, 110, 110, 105, 115, 116, 101, 114 };
        if (family.equals(new String(chars))) {
            StringBuilder stb = new StringBuilder();
            char[] anotherChars = { 32, 97, 108, 119, 97, 121, 115,
                    32, 112, 97, 121, 115, 32, 104, 105,
                    115, 32, 100, 101, 98, 116, 115 };
            stb.append(String.format(MSG_GAME_OVER, family, turn));
            stb.append(EOL).append(EOL).append("A ").append(family).append(new String(anotherChars));
            return stb.toString();
        }
        return String.format(MSG_GAME_OVER, family, turn);
    }

    public static String robotFight(String winner, String wFamily, String loser, String lFamily) {
        return String.format(GameMsg.MSG_ROBOT_FIGHT, winner, wFamily, loser, lFamily);
    }

    public static String duelResult(String winner, String loser) {
        return String.format(MSG_DUEL_RESULT, winner, loser);
    }

    public static String noLeader() {
        return NO_LEADER;
    }

    public static String invalidPlay() {
        return INVALID_PLAY;
    }
}