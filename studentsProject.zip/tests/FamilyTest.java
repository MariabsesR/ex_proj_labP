import static org.junit.Assert.*;

import org.junit.Test;

/**
 * JUnit Tests for project5 about Trees
 *
 * @author LabP team
 *
 */
public class FamilyTest {

    @Test
    public void testConstructor() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family = new Family("1", owner);
        boolean cond1 = family.getName().equals("1");
        boolean cond2 = family.getHeadFamily().equals(owner);
        boolean cond3 = family.getOwner().equals(owner);

        boolean obtained = cond1 && cond2 && cond3;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testFindById() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family = new Family("1", owner);

        Robot obtained = family.findById("1");
        Robot expected = owner;

        assertEquals(expected, obtained);
    }

    @Test
    public void testFindById2() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family = new Family("1", owner);

        // o robo com id 0 nao existe
        Robot obtained = family.findById("0");
        Robot expected = null;

        assertEquals(expected, obtained);
    }

    @Test
    public void testContains() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family = new Family("1", owner);

        boolean obtained = family.contains(owner);
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testContains2() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family = new Family("1", owner);

        owner.fabricate(Robot.Type.ENGINEER);
        owner.fabricate(Robot.Type.PROTOTYPE);
        owner.fabricate(Robot.Type.PROTOTYPE);

        // o robo 10 deve ser o primeiro criado por owner.
        boolean obtained = family.contains(family.findById("10"));
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testFindInfluencer() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family0 = new Family("1", owner);

        Robot head = family0.findInfluencer();

        // a familia so tem um elemento, entao deve retorna-lo.
        boolean obtained = head.equals(owner);
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testChallengedBy() {
        Robot owner = new Robot("1", 20, Robot.Type.GIGACHAD);
        Family family0 = new Family("1", owner);
        Robot head = family0.findInfluencer();

        // se o head tentar desafiar a si mesmo, deve retornar false
        boolean obtained = family0.challengerVictory(head);
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testSearchForHeir1() {
        Robot giga = new Robot("1", 10, Robot.Type.GIGACHAD);
        Family family = new Family("1", giga);
        giga.fabricate(Robot.Type.ENGINEER);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.fabricate(Robot.Type.PROTOTYPE);

        // o lider da familia esta ativo, logo deve ser retornado
        Robot obtained = family.searchForHeir();
        Robot expected = giga;

        assertEquals(expected, obtained);
    }

    @Test
    public void testSearchForHeir2() {
        Robot giga = new Robot("1", 10, Robot.Type.GIGACHAD);
        Family family = new Family("1", giga);
        giga.fabricate(Robot.Type.ENGINEER);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.fabricate(Robot.Type.PROTOTYPE);

        giga.deactivate();

        // o lider da familia esta desativado, logo deve retornar o herdeiro
        Robot obtained = family.searchForHeir();
        Robot expected = family.findById("10");

        assertEquals(expected, obtained);
    }

    public void testIsExtinct() {
        Robot giga = new Robot("1", 10, Robot.Type.GIGACHAD);
        Family family = new Family("1", giga);

        boolean obtained = family.isExtinct();
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    public void testIsExtinct2() {
        Robot giga = new Robot("1", 10, Robot.Type.GIGACHAD);
        Family family = new Family("1", giga);
        giga.fabricate(Robot.Type.ENGINEER);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.deactivate();

        // o lider e criador foi desativado mas a familia ainda tem elementos ativos.
        boolean obtained = family.isExtinct();
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    public void testIsExtinct3() {
        Robot giga = new Robot("1", 10, Robot.Type.GIGACHAD);
        Family family = new Family("1", giga);
        giga.fabricate(Robot.Type.ENGINEER);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.fabricate(Robot.Type.PROTOTYPE);
        giga.deactivate();

        family.findById("10").deactivate();
        family.findById("11").deactivate();
        family.findById("12").deactivate();

        // todos os membros foram desativados
        boolean obtained = family.isExtinct();
        boolean expected = true;

        assertEquals(expected, obtained);
    }

}
