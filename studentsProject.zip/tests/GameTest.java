
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

/**
 * JUnit Tests for project5 about Trees
 *
 * @author LabP team
 *
 */
public class GameTest {

    @Test
    public void testConstructor() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);

        List<Family> families = game.getFamilies();

        boolean condN1 = families.get(0).getName().equals("0");
        boolean condN2 = families.get(1).getName().equals("1");
        boolean condN3 = families.get(2).getName().equals("2");

        // cada robo fundador deve criar tres robos diferentes e isso vai alterar sua
        // influencia.
        boolean condI1 = families.get(0).getOwner().getInfluence() == 4;
        boolean condI2 = families.get(1).getOwner().getInfluence() == 1;
        boolean condI3 = families.get(2).getOwner().getInfluence() == 2;

        boolean oneOk = condI1 && condN1;
        boolean twoOk = condI2 && condN2;
        boolean threeOk = condI3 && condN3;

        boolean obtained = oneOk && twoOk && threeOk;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testConstructor2() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);

        Family family = game.getFamilies().get(0);

        // ids dos robos criados ao inicializar um novo jogo
        Robot bot00 = family.findById("00");
        Robot bot01 = family.findById("01");
        Robot bot02 = family.findById("02");

        // tipos dos robos criados ao inicializar um novo jogo
        boolean condN1 = bot00.getType() == Robot.Type.ENGINEER;
        boolean condN2 = bot01.getType() == Robot.Type.PROTOTYPE;
        boolean condN3 = bot02.getType() == Robot.Type.PROTOTYPE;

        // influencias dos robos criados ao inicializar um novo jogo
        boolean condI1 = bot00.getInfluence() == 5;
        boolean condI2 = bot01.getInfluence() == 4;
        boolean condI3 = bot02.getInfluence() == 3;

        boolean oneOk = condI1 && condN1;
        boolean twoOk = condI2 && condN2;
        boolean threeOk = condI3 && condN3;

        boolean obtained = oneOk && twoOk && threeOk;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testCreateRobot() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family = game.getFamilies().get(0);
        Robot owner = family.getOwner();

        // owner deve fabricar um robo do tipo ENGINEER
        game.createRobot(owner, Robot.Type.ENGINEER);

        // robo criado pelo comando anterior
        Robot bot03 = family.findById("03");

        assertNotNull(bot03);

        boolean botInfluence = bot03.getInfluence() == 2;
        boolean ownerInfluence = bot03.getInfluence() == 2;
        boolean correctType = bot03.getType() == Robot.Type.ENGINEER;

        boolean obtained = botInfluence && ownerInfluence && correctType;
        boolean expected = true;

        assertEquals(expected, obtained);

    }

    @Test
    public void testCreateRobot2() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot00 = family0.findById("00");
        Robot bot11 = family1.findById("11");

        // junta o robo 00 que e do tipo ENGINEER com bot11 do tipo PROTOTYPE
        game.merge(bot00, family1, bot11);

        // bot00 deve fabricar um robo do tipo ENGINEER
        game.createRobot(bot00, Robot.Type.ENGINEER);

        Robot bot000 = family0.findById("000");

        assertNotNull(bot000);

        boolean botInfluence = bot000.getInfluence() == 3;
        boolean correctType = bot000.getType() == Robot.Type.ENGINEER;

        boolean obtained = botInfluence && correctType;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testMerge() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot00 = family0.findById("00");
        Robot bot11 = family1.findById("11");

        // junta o robo 00 que e do tipo ENGINEER com bot11 do tipo PROTOTYPE
        game.merge(bot00, family1, bot11);

        boolean correctInfluence = bot00.getInfluence() == 7;
        boolean botRemoved = family1.findById("11") == null;
        boolean correctType = bot00.getType() == Robot.Type.GIGACHAD;

        boolean obtained = correctInfluence && botRemoved && correctType;
        boolean expected = true;

        assertEquals(expected, obtained);

    }

    @Test
    public void testMerge2() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot01 = family0.findById("01");
        Robot bot10 = family1.findById("10");

        // tenta juntar o robo 01 que e do tipo PROTOTYPE com bot11 do tipo ENGINEER
        game.merge(bot01, family1, bot10);

        boolean correctInfluence = bot10.getInfluence() == 3;
        boolean botNotRemoved = family0.findById("01") != null;
        boolean correctType = bot10.getType() == Robot.Type.ENGINEER;

        boolean obtained = correctInfluence && botNotRemoved && correctType;
        boolean expected = true;

        assertEquals(expected, obtained);

    }

    @Test
    public void testMergeF() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        // junta o robo 01 que do tipo PROTOTYPE com bot11 do tipo PROTOTYPE
        Robot bot01 = family0.findById("01");
        Robot bot11 = family1.findById("11");

        boolean obtained = game.merge(bot01, family1, bot11);
        boolean expected = false;

        assertEquals(expected, obtained);

    }

    @Test
    public void testSearchForHeirGame() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot firstHead = family0.getHeadFamily();
        Robot bot00 = family0.findById("00");
        Robot bot11 = family1.findById("11");

        // first heir is the creator and head of family.
        boolean expected = true;
        boolean obtained = family0.searchForHeir().equals(firstHead);
        assertEquals(expected, obtained);

        game.createRobot(firstHead, Robot.Type.ENGINEER);

        // deactivate head of family.
        firstHead.deactivate();

        // first heir is the robot 00
        expected = true;
        obtained = family0.searchForHeir().equals(bot00);
        assertEquals(expected, obtained);

        bot00.deactivate();

        Robot bot03 = family0.findById("03");

        // second heir should be the the robot 03
        expected = true;
        obtained = family0.searchForHeir().equals(bot03);
        assertEquals(expected, obtained);

        game.merge(bot03, family1, bot11);
        game.createRobot(bot03, Robot.Type.ENGINEER);
        bot03.deactivate();

        // last heir should be robot 030
        Robot bot030 = family0.findById("030");

        expected = true;
        obtained = family0.searchForHeir().equals(bot030);
        assertEquals(expected, obtained);
    }

    @Test
    public void testDeactivatedPrototype() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();

        // desativa o bot 01 que do tipo PROTOTYPE
        game.destroyPrototype(family0.findById("01"));

        Robot obtained = family0.findById("01");
        Robot expected = null;

        assertEquals(expected, obtained);

    }

    @Test
    public void testDeactivatedPrototypeF() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();

        // tenta desativar o bot 0 que do tipo GIGACHAD
        boolean obtained = game.destroyPrototype(family0.findById("0"));
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testOffer() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        // a familia 0 vai doar um prototipo para familia 1
        game.offerPrototype(family1);

        boolean removedBot = family0.findById("01") == null;
        boolean correctOffered = family1.findById("13").getInfluence() == 4;
        boolean correctInfluence = family0.getHeadFamily().getInfluence() == 12;

        boolean obtained = removedBot && correctOffered && correctInfluence;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testOffer2() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot00 = family0.findById("00");
        Robot bot11 = family1.findById("11");

        // junta o bot00 (ENGINEER) com o bot11 (PROTOTYPE)
        game.merge(bot00, family1, bot11);

        // cria dos bots do tipo PROTOTYPE
        game.createRobot(bot00, Robot.Type.PROTOTYPE);
        game.createRobot(bot00, Robot.Type.PROTOTYPE);

        // a familia 0 doa 3 PROTOTYPEs para familia 1
        // devem ser doados 01, 02 e 100, nesta ordem.
        game.offerPrototype(family1);
        game.offerPrototype(family1);
        game.offerPrototype(family1);

        boolean offered01 = family0.findById("01") == null;

        // ultimo bot doado pela familia 0
        boolean lastOffered = family1.findById("15").getInfluence() == 3;

        boolean correctInfluenceHead = family0.getHeadFamily().getInfluence() == 24;
        boolean correctInfluenceCreator = bot00.getInfluence() == 3;
        boolean offered000 = family0.findById("000") == null;
        boolean notOffered001 = family0.findById("001") != null;

        boolean obtained = offered01 &&
                lastOffered &&
                correctInfluenceHead &&
                correctInfluenceCreator &&
                offered000 &&
                notOffered001;
        boolean expected = true;

        assertEquals(expected, obtained);

    }

    @Test
    public void testOfferF() {

        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family1 = game.getFamilies().get(1);

        // doa os dois prototipos da familia 0 para familia 1
        game.offerPrototype(family1);
        game.offerPrototype(family1);

        // nao deve ser possivel doar mais prototipos.
        boolean obtained = game.offerPrototype(family1);
        boolean expected = false;

        assertEquals(expected, obtained);

    }

    @Test
    public void testAttack() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot11 = family1.findById("11");

        // o bot 0 (influencia 4) vai atacar o bot 11 (influencia 2)
        game.attack(family0.getOwner(), family1, bot11);

        boolean obtained = bot11.isWorking();
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testAttack2() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot11 = family1.findById("11");
        Robot bot01 = family0.findById("01");

        // o bot 11 (influencia 2) vai atacar o bot 01 (influencia 4)
        game.attack(bot11, family1, bot01);

        boolean obtained = bot11.isWorking();
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testAttack3() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot0 = family0.findById("0");
        Robot bot1 = family1.findById("1");

        // o bot 0 (influencia 4) vai atacar o bot 1 (influencia 1)
        game.attack(bot0, family1, bot1);

        // como consequencia, 1 vai ser desativado.

        // a familia 1 deve ter um novo chefe (o bot 10)
        Robot newHead = family1.getHeadFamily();
        Robot supposedToBeHead = family1.findById("10");

        boolean cond1 = !bot1.isWorking();
        boolean cond2 = !bot1.isHeadOfFamily();
        boolean cond3 = newHead.equals(supposedToBeHead);
        boolean cond4 = newHead.isHeadOfFamily();
        boolean cond5 = family1.getOwner().equals(bot1);

        boolean obtained = cond1 && cond2 && cond3 && cond4 && cond5;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testAttack4() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        game.updatePlaying();
        Family family0 = game.getFamilies().get(0);
        Family family1 = game.getPlaying();

        Robot bot0 = family0.findById("0");
        Robot bot1 = family1.findById("1");

        // o bot 1 (influencia 1) vai atacar o bot 0 (influencia 4)
        game.attack(bot1, family0, bot0);

        // como consequencia, 1 vai ser desativado.

        // a familia 1 deve ter um novo chefe (o bot 10)
        Robot newHead = family1.getHeadFamily();
        Robot supposedToBeHead = family1.findById("10");

        boolean cond1 = !bot1.isWorking();
        boolean cond2 = !bot1.isHeadOfFamily();
        boolean cond3 = newHead.equals(supposedToBeHead);
        boolean cond4 = newHead.isHeadOfFamily();
        boolean cond5 = family1.getOwner().equals(bot1);

        boolean obtained = cond1 && cond2 && cond3 && cond4 && cond5;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testAttack5() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot bot0 = family0.findById("0");
        Robot bot1 = family1.findById("1");

        // o bot 0 (influencia 4) vai atacar o bot 1 (influencia 1)
        game.attack(bot0, family1, bot1);

        // a familia 1 deve ter um novo chefe (o bot 10)

        // o bot 0 (influencia 4) vai atacar o bot 10 (influencia 3)
        game.attack(bot0, family1, family1.getHeadFamily());

        // ja nao ha quem possa ser chefe da familia 1
        boolean cond1 = family1.getHeadFamily() == null;
        boolean cond2 = family1.getOwner().equals(bot1);
        boolean cond3 = !family1.isExtinct();

        boolean obtained = cond1 && cond2 && cond3;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    /**
     * Desafiante com influência maior. Desafiante ganha.
     */
    @Test
    public void testChallengeGame() {
        String[] names = { "0", "1", "2" };
        int[] influences = { 10, 6, 8 };

        Game game = new Game(names, influences);
        Family family0 = game.getPlaying();
        Family family1 = game.getFamilies().get(1);

        Robot firstHead = family0.getHeadFamily();
        Robot bot00 = family0.findById("00");
        Robot bot11 = family1.findById("11");

        // junta o robo 00 (influencia 5) que do tipo ENGINEER com bot11 do tipo
        // PROTOTYPE (influencia 2)
        game.merge(bot00, family1, bot11);

        // o maior bot deve ser o 00 com influencia 7
        Robot influencer = family0.findInfluencer();

        // o desafiante tem maior influencia que o chefe da familia, logo ira ser o novo
        // chefe.
        boolean cond1 = family0.challengerVictory(influencer);
        boolean cond2 = !firstHead.isWorking() && !firstHead.isHeadOfFamily();
        boolean cond3 = bot00.isHeadOfFamily();
        boolean cond4 = family0.getHeadFamily().equals(bot00);

        boolean obtained = cond1 && cond2 && cond3 && cond4;
        boolean expected = true;

        assertEquals(expected, obtained);

    }

    /**
     * Empate entre o desafiante e o chefe. Chefe ganha.
     */
    @Test
    public void testChallengeGame2() {

        String[] names = { "0", "1", "2", "3" };
        int[] influences = { 10, 6, 8, 18 };

        Game game = new Game(names, influences);

        Family family0 = game.getPlaying();
        Family family3 = game.getFamilies().get(3);

        Robot firstHead = family0.getHeadFamily();
        Robot bot00 = family0.findById("00");
        Robot bot32 = family3.findById("32");

        // junta o robo 00 (influencia 5) que do tipo ENGINEER com bot32 do tipo
        // PROTOTYPE (influencia 7)
        game.merge(bot00, family3, bot32);

        // a familia 0 doa para familia 3. O valor da influencia do chefe sobe para 12
        game.offerPrototype(family3);

        // o influencer deve ser o robo 00 com influencia 12
        Robot influencer = family0.findInfluencer();

        // o desafiante tem a mesma influencia do chefe, logo deve perder.
        boolean cond1 = !family0.challengerVictory(influencer);
        boolean cond2 = firstHead.isWorking() && firstHead.isHeadOfFamily();
        boolean cond3 = !bot00.isWorking() && !bot00.isHeadOfFamily();
        boolean cond4 = family0.getHeadFamily().equals(firstHead);

        boolean obtained = cond1 && cond2 && cond3 && cond4;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testSimpleGame() {

        String[] names = { "0", "1" };
        int[] influences = { 10, 7 };
        Game game = new Game(names, influences);

        Family playing = game.getPlaying();
        Robot bot0 = playing.findById("0");
        Family otherFamily = game.findFamilyByName("1");
        Robot bot10 = otherFamily.findById("10");
        boolean worked = game.attack(bot0, otherFamily, bot10);

        assertTrue(worked);
        game.updatePlaying();

        playing = game.getPlaying();
        otherFamily = game.findFamilyByName("0");
        worked = game.destroyPrototype(playing.findById("11"));

        assertTrue(worked);

        game.updatePlaying();
        playing = game.getPlaying();
        otherFamily = game.findFamilyByName("1");
        worked = game.offerPrototype(otherFamily);

        assertTrue(worked);

        game.updatePlaying();
        playing = game.getPlaying();
        worked = game.destroyPrototype(otherFamily.findById("13"));

        assertTrue(worked);

        game.updatePlaying();
        playing = game.getPlaying();
        otherFamily = game.findFamilyByName("1");
        worked = game.attack(playing.getHeadFamily(), otherFamily, otherFamily.getHeadFamily());

        assertTrue(worked);

        game.updatePlaying();
        playing = game.getPlaying();
        otherFamily = game.findFamilyByName("0");
        game.attack(playing.findById("12"), otherFamily, otherFamily.getHeadFamily());

        assertTrue(game.isFinished());

    }

}
