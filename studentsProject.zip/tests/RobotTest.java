import static org.junit.Assert.*;

import org.junit.Test;

/**
 * JUnit Tests for project5 about Trees
 *
 * @author LabP team
 *
 */
public class RobotTest {

    @Test
    public void testConstructor() {
        Robot bot = new Robot("1", 1, Robot.Type.GIGACHAD);
        boolean cond1 = bot.getId().equals("1");
        boolean cond2 = bot.getInfluence() == 1;
        boolean cond3 = bot.getType() == Robot.Type.GIGACHAD;
        boolean cond4 = bot.isWorking();

        boolean obtained = cond1 && cond2 && cond3 && cond4;
        boolean expected = true;
        assertEquals(expected, obtained);
    }

    @Test
    public void testDeactivated() {
        Robot bot = new Robot("1", 1, Robot.Type.GIGACHAD);
        bot.deactivate();

        boolean obtained = bot.isHeadOfFamily() || bot.isWorking();
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testGetType() {
        Robot giga = new Robot("1", 1, Robot.Type.GIGACHAD);
        Robot eng = new Robot("2", 1, Robot.Type.ENGINEER);
        Robot prot = new Robot("3", 1, Robot.Type.PROTOTYPE);

        boolean obtained = giga.getType() == Robot.Type.GIGACHAD
                && eng.getType() == Robot.Type.ENGINEER
                && prot.getType() == Robot.Type.PROTOTYPE;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testHasDefeated() {
        Robot bot1 = new Robot("1", 10, Robot.Type.GIGACHAD);
        Robot bot2 = new Robot("2", 1, Robot.Type.GIGACHAD);

        boolean obtained = bot1.hasDefeated(bot2);
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testHasDefeated2() {
        Robot bot1 = new Robot("1", 10, Robot.Type.GIGACHAD);
        Robot bot2 = new Robot("2", 10, Robot.Type.GIGACHAD);

        // com influenciais iguais, o bot1 deve perder para o bot2
        boolean obtained = bot1.hasDefeated(bot2);
        boolean expected = false;

        assertEquals(expected, obtained);
    }

    @Test
    public void testFabricate() {
        Robot giga = new Robot("1", 1, Robot.Type.GIGACHAD);
        boolean untilTen = true;
        for (int i = 0; i < 10; i++) {
            untilTen &= giga.fabricate(Robot.Type.ENGINEER);
        }

        // o robo deve ser capaz de criar ate 10 robos diferentes.
        boolean obtained = untilTen;
        boolean expected = true;

        assertEquals(expected, obtained);
    }

    @Test
    public void testFabricate2() {
        Robot giga = new Robot("1", 1, Robot.Type.GIGACHAD);
        for (int i = 0; i < 10; i++) {
            giga.fabricate(Robot.Type.ENGINEER);
        }

        // nao deve ser possível criar 11 robos.
        boolean obtained = giga.fabricate(Robot.Type.PROTOTYPE);
        boolean expected = false;

        assertEquals(expected, obtained);
    }

}
