import java.io.PrintWriter;
import java.util.Scanner;
import java.util.stream.Collectors;

public class GameEngine {

    public static final int TURNS_TO_DUEL = 3;
    private PrintWriter printer;
    private Game game;

    /**
     * Constructor to the GameEngine class
     * 
     * @param game    the game to be played.
     * @param printer output to print the game
     */
    GameEngine(Game game, PrintWriter printer) {
        this(game);
        this.printer = printer;
    }

    /**
     * Constructor to the GameEngine class
     * 
     * @param game the game to be played.
     */
    GameEngine(Game game) {
        this.game = game;
    }

    /**
     * Represents each action that can happen in a game.
     */
    public enum Action {
        CREATE, ATTACK, MERGE, OFFER, DESTROY;

        /**
         * Converts an String to an specific Action. In case the String isnt A, M, O, D,
         * or C, should return null.
         * 
         * @param action a single caracter String
         * @return The Action associated with the specific letter.
         */
        public static Action byLetter(String action) {
            switch (action) {
                case "A":
                    return ATTACK;
                case "M":
                    return MERGE;
                case "O":
                    return OFFER;
                case "D":
                    return DESTROY;
                case "C":
                    return CREATE;
                default:
                    return null;
            }
        }
    }

    /**
     * Read the input from the user and check if its valid.
     * If the input is valid, return true, otherwise, returns false.
     * 
     * @param scan   input to insert the actions
     * @param family the current family playing the game
     */
    private boolean isValidPlay(Scanner scan, Family family) {
        String action = readAndPrint(scan);
        switch (Action.byLetter(action)) {
            case CREATE: {
                return readCreateRobot(scan, family);
            }
            case ATTACK: {
                return readAttackRobot(scan, family);
            }
            case MERGE: {
                return readMergeRobot(scan, family);
            }
            case OFFER: {
                return readOfferRobot(scan, family);
            }
            case DESTROY: {
                return readDestroyRobot(scan, family);
            }
            default:
                return false;
        }
    }

    /**
     * Play the game.
     * On this game, each family will take a single action per turn.
     * If a family does not have any active robots, if should be considered extinct
     * and cant play anymore.
     * When there's only one family remaining with active robots, this family should
     * be considered the winner.
     * 
     * @param scan input to insert the actions
     */
    public void play(Scanner scan) {

        print(GameMsg.welcome());
        print(GameMsg.familyNames(getFamiliesNames()));
        print(this.toString());

        while (!game.isFinished()) {

            if (game.getPlaying().isExtinct()) {
                print(GameMsg.familyOver(game.getPlaying().getName()));
            } else {
                readAction(scan, game.getPlaying());
                if (isTimeForDuel()) {
                    duelTime(game.getPlaying().getHeadFamily());
                }
                print(this.toString());
            }

            if (game.getFamilies().indexOf(game.getPlaying()) == game.getFamilies().size() - 1) {
                print(GameMsg.turnOver(game.getTurn()));
                game.nextTurn();
            }
            game.updatePlaying();
        }

        print(GameMsg.gameOver(findWinner(), game.getTurn()));
    }

    /**
     * Verify if its possible to have a duel. The three main conditions are:
     * 1) The family playing cant be extinct.
     * 2) The turn must be a multiple of 3
     * 3) There must be a head of family
     * 
     * @return if all three conditions are true, return true. Otherwise, return
     *         false.
     */
    protected boolean isTimeForDuel() {
        return !game.getPlaying().isExtinct() &&
                game.getTurn() % TURNS_TO_DUEL == 0 &&
                game.getPlaying().getHeadFamily() != null;
    }

    /**
     * The influencer should challenge the head of the family.
     * If the influencer is the head of the family, should do nothing.
     * Otherwhise, it will output the winner.
     * 
     * @requires {@code isTimeForDuel()}
     */
    protected void duelTime(Robot headOfFamily) {
        Robot influencer = game.getPlaying().findInfluencer();
        if (!influencer.equals(headOfFamily)) {
            print(GameMsg.challengeBegins(game.getPlaying().getName()));
            boolean duelWinner = game.getPlaying().challengerVictory(influencer);

            String idWinner = duelWinner ? influencer.getId() : headOfFamily.getId();
            String idLoser = duelWinner ? headOfFamily.getId() : influencer.getId();

            print(GameMsg.duelResult(idWinner, idLoser));
        }
    }

    /**
     * Returns the winner family
     * 
     * @return the name of the winner family
     */
    protected String findWinner() {
        return game.getFamilies().stream()
                .filter(family -> !family.isExtinct())
                .findFirst().get().getName();
    }

    /**
     * Uses the scanner to read the inputs for the action DESTROY
     * 
     * @param scan   input to insert the actions
     * @param family the current family playing the game
     * @return if it was possible to destroy the prototype, returns true. Otherwise,
     *         returns false.
     */
    private boolean readDestroyRobot(Scanner scan, Family family) {
        print(GameMsg.destroy(family.getName()));
        String robotId = readAndPrint(scan);
        Robot robot = family.findById(robotId);
        return game.destroyPrototype(robot);
    }

    /**
     * Uses the scanner to read the inputs for the action OFFER
     * A family cannot offer to itself.
     * 
     * @param scan   input to insert the actions
     * @param fOffer the current family playing the game
     * @return if it was possible to offer the prototype, returns true. Otherwise,
     *         returns false.
     */
    private boolean readOfferRobot(Scanner scan, Family fOffer) {
        print(GameMsg.offer());
        String fReceiveName = readAndPrint(scan);
        Family fReceive = game.findFamilyByName(fReceiveName);
        if (fOffer.equals(fReceive))
            return false;
        return game.offerPrototype(fReceive);
    }

    /**
     * Uses the scanner to read the inputs for the action MERGE
     * A family cannot merge with itself.
     * 
     * @param scan   input to insert the actions
     * @param family the current family playing the game
     * @return if it was possible to merge the two robots, returns true. Otherwise,
     *         returns false.
     */
    private boolean readMergeRobot(Scanner scan, Family family) {
        print(String.format(GameMsg.merg(family.getName())));
        String botId = readAndPrint(scan);
        print(GameMsg.familyRobotJoin(botId));
        print(GameMsg.familyName());
        String otherFamilyName = readAndPrint(scan);
        print(GameMsg.idRobot());
        String otherBotId = readAndPrint(scan);
        Family otherFamily = game.findFamilyByName(otherFamilyName);

        Robot myBot = family.findById(botId);
        Robot otherBot = otherFamily.findById(otherBotId);
        if (family.equals(otherFamily))
            return false;

        return game.merge(myBot, otherFamily, otherBot);
    }

    /**
     * Uses the scanner to read the inputs for the action ATTACK
     * An family cannot attack itself.
     * 
     * @param scan      input to insert the actions
     * @param fAttacker the current family playing the game
     * @return if it was possible to attack, returns true. Otherwise,
     *         returns false.
     */
    private boolean readAttackRobot(Scanner scan, Family fAttacker) {
        print(GameMsg.attack(fAttacker.getName()));
        String attackerId = readAndPrint(scan);
        print(GameMsg.familyRobotAttack(attackerId));
        print(GameMsg.familyName());
        String dFamilyName = readAndPrint(scan);
        print(GameMsg.idRobot());
        String defenderId = readAndPrint(scan);

        Family fDefender = game.findFamilyByName(dFamilyName);

        Robot attacker = fAttacker.findById(attackerId);
        Robot defender = fDefender.findById(defenderId);
        if (!fDefender.equals(fAttacker)) {
            if (game.attack(attacker, fDefender, defender)) {
                fightSummary(fAttacker, attacker, fDefender, defender);
            } else {
                fightSummary(fDefender, defender, fAttacker, attacker);
            }
            return true;
        }
        return false;
    }

    /**
     * Prints the summary of the fight bewtween two robots.
     * 
     * @param wFamily winner family.
     * @param winner  winner robot.
     * @param lFamily loser family.
     * @param loser   loser robot.
     */
    protected void fightSummary(Family wFamily, Robot winner, Family lFamily, Robot loser) {
        print(GameMsg.robotFight(winner.getId(), wFamily.getName(), loser.getId(), lFamily.getName()));
    }

    /**
     * Uses the scanner to read the inputs for the action CREATE
     * 
     * @param scan   input to insert the actions
     * @param family the current family playing the game
     * @return if it was possible to attack, returns true. Otherwise,
     *         returns false.
     */
    private boolean readCreateRobot(Scanner scan, Family family) {
        print(GameMsg.create());
        String robotId = readAndPrint(scan);
        print(GameMsg.createType());
        int typeId = Integer.parseInt(readAndPrint(scan));
        Robot.Type type = getType(typeId);
        Robot bot = family.findById(robotId);
        return game.createRobot(bot, type);
    }

    /**
     * Prints the header for each family and reads the action that family will make.
     * 
     * @param scan   input to insert the actions
     * @param family the current family playing the game
     */
    private void readAction(Scanner scan, Family family) {
        printHeader(family);
        boolean validPlay = isValidPlay(scan, family);
        while (!validPlay) {
            print(GameMsg.invalidPlay());
            print(GameMsg.letsPlay());
            validPlay = isValidPlay(scan, family);
        }
    }

    /**
     * Prints some overall information about the family.
     * 
     * @param family the current family playing the game
     */
    private void printHeader(Family family) {
        print(GameMsg.makePlay(family.getName()));
        String headName = family.getHeadFamily() == null ? GameMsg.noLeader() : family.getHeadFamily().getId();
        print(GameMsg.decision(headName, family.getName()));
        print(GameMsg.letsPlay());
    }

    public String toString() {
        StringBuilder stb = new StringBuilder();
        for (Family family : game.getFamilies()) {
            if (!family.isExtinct())
                stb.append(family.toString());
        }
        return stb.toString();
    }

    /**
     * Returns the type of the robot that should be created.
     * Should only return ENGINEER or PROTOTYPE
     * 
     * @param typeId should be 0 for ENGINEER and 1 for PROTOTYPE
     * @requires {@code typeId == 0 || typeId == 1}
     * @return
     */
    protected Robot.Type getType(int typeId) {
        if (typeId == 0) {
            return Robot.Type.ENGINEER;
        }
        return Robot.Type.PROTOTYPE;

    }

    /**
     * Returns the name of all families separed by a ','
     * 
     * @return the names of the families separated by a ','
     */
    protected String getFamiliesNames() {
        return game.getFamilies().stream().map(f -> f.getName()).collect(Collectors.joining(","));
    }

    /**
     * Read from the scanner and, in case there's a printer, print the value read
     * onto it.
     * 
     * @param scan input to insert the actions
     * @return the String read by scan.
     */
    private String readAndPrint(Scanner scan) {
        String elem = scan.nextLine();
        if (printer != null)
            print(elem);
        return elem;
    }

    protected void print(String args) {
        if (printer != null) {
            printer.println(args);
        } else {
            System.out.println(args);
        }
    }

}
