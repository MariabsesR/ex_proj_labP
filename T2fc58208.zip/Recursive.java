
/**
 * Class with multiple recursive methods 
 * 
 * 
 * @author Maria Rocha fc58208
 *
 */



public class Recursive {

	
	/**
	 * Calculates the sum of the first k terms of the harmonic series
	 * 
	 * @param k amount of terms
	 * @requires {@code k>0}
	 * @return sum of the n terms of the harmonic series
	 */
	
	
	// k >0
	public static double harmonicSum(int k) {
		double result;
		double n = k;
		//if k=1 the result will be one (standard case)
		if (k == 1)
			result = 1;
		else {
			
			result = (1 / n) + harmonicSum(k - 1);

		}
		return result;
	}

	
	/**
	 * Returns the amount of the specified product in the given box code
	 * 
	 * @param boxCode code that shows the type of product and its amount
	 * @param productCode the code of the product we searching for
	 * @requires {@code boxCode.length()>=4 && boxCode.length()%4==0}
	 * @return amount of the specified product
	 */
	
	
	
	public static int containedQuantity(String boxCode, String productCode)throws NumberFormatException   {
		
		StringBuilder node = new StringBuilder(boxCode);
		int result = 0;
		
		if (boxCode.length() == 4) {
			//standard case
			String typeOfProduct = node.substring(0, 2).toString();
			String ammountOfProduct = node.substring(2, 4).toString();
			
			if (Integer.parseInt(typeOfProduct) == Integer.parseInt(productCode)) {
				result = Integer.parseInt(ammountOfProduct);
			}
		} else {
			
			String typeOfProduct = node.substring(0, 2).toString();
			String ammountOfProduct = node.substring(2, 4).toString();
			
			if (Integer.parseInt(typeOfProduct) == Integer.parseInt(productCode)) {
				//makes  a new string without the box codes already used to use in contained
				result = Integer.parseInt(ammountOfProduct) + containedQuantity(boxCode.substring(4), productCode);
			} else {
				//makes  a new string without the box codes already used to use in contained
				result = containedQuantity(boxCode.substring(4), productCode);
			}

		}
		return result;
	}

	/**
	 * Verifies if all the elements of values belong in the given interval
	 * 
	 * @param values array with numbers to check
	 * @param x lowest value of he interval
	 * @param y highest value of the interval
	 * @requires {@code values!=null }
	 * @return  the values on the array all belong on the interval
	 */
	
	
	
	public static boolean allInInterval(int[] values, int x, int y) {
		boolean result = true;

		result = interval(values, x, y, values.length - 1);

		return result;
	}

	/**
	 * Verifies if all the elements of values belong in the given interval
	 * 
	 * @param values array with numbers to check
	 * @param x lowest value of he interval
	 * @param y highest value of the interval
	 * @param index used to move through each value of the given array
	 * @return  the values on the array all belong on the interval
	 */
	
	
	
	private static boolean interval(int[] values, int x, int y, int index) {
		boolean result = true;

		if (index == 0) {
			//standard case
			result = values[0] >= x && values[0] <= y;
		} else {
            // Checks the current value and calls our function to do the rest of the index 
			result = values[index] >= x && values[index] <= y;
			result = result && interval(values, x, y, index - 1);

		}
		return result;
	}

	/**
	 * Receives an array of integers and returns a new vector in
	 * which between each element of the original the values given were inserted 
	 * 
	 * @param v array which we want to modify
	 * @param a the first value to be inserted
	 * @param b the second value to be inserted
	 * @requires {@code v != null && v.length >= 1}
	 * @return modified array with new elements
	 */
	
	
	
	
	public static int[] sandwich(int[] v, int a, int b) {
        //the amount of int  in our new array
		int amountOfnew = 0;
		int[] save = new int[v.length + v.length - 1];
		//the index of the int used in our old array
		int index = 0;
		aplySandwich(v, a, b, save, amountOfnew, index);

		return save;

	}
	/**
	 * Receives an array of integers and returns a new vector in
	 * which between each element of the original the values given were inserted 
	 * 
	 * @param v array which we want to modify
	 * @param a the first value to be inserted
	 * @param b the second value to be inserted
	 * @param index the index of the int currently being used in our old array
	 * @param amountOfnew the amount of int  in our new array
	 * @requires {@code v != null && v.length >= 1}
	 * @return modified array with new elements
	 */
	public static int[] aplySandwich(int[] v, int a, int b, int[] save, int amountOfnew, int index) {
		int[] result = new int[v.length + v.length - 1];

		if (v.length < 2)
			 
			result = v;

		if (index != v.length - 1) {
            //adds the number from the old array to the new 
			save[amountOfnew] = v[index];
			// chooses which element to add 
			if (index % 2 == 0)
				save[amountOfnew + 1] = a;
			else
				save[amountOfnew + 1] = b;
              // adds 2 to ammount of new cause our array gained 2 new number and +1 to index
			  //cause we used that int from it
			aplySandwich(v, a, b, save, amountOfnew + 2, index + 1);

		} else {
			//standard case , adds the last number of or old array to the new
			save[save.length - 1] = v[v.length - 1];
			result = save;
		}

		return result;
	}

	
	/**
	 * Receives two arrays and returns a new array with the values of
	 * both the arrays ordered in ascending order
	 * 
	 * @param v array to merge
	 * @param w array to merge
	 * @requires the given arrays must be ordered in ascending order
	 * @requires {@code v!=null && w!=null}
	 * @return new array with merged values
	 */
	
	
	public static int[] merge(int[] v, int[] w) {
		int[] save = new int[v.length + w.length];
		int counter = 0;
		int indexV = 0;
		int indexW = 0;
		return mergeNum(v, w, indexV, indexW, save, counter);

	}

	/**
	 * 
	 * @param v array to merge
	 * @param w array to merge
	 * @param indexV current index of used int in the array v
	 * @param indexW current index of used int in the array w
	 * @param save new array with merged valued
	 * @param counter index of our new array to input values 
	 * @return  new array with merged values
	 */
	
	public static int[] mergeNum(int[] v, int[] w, int indexV, int indexW, int[] save, int counter) {

		if (indexW == w.length && counter != save.length) {
            //standard case where w has reached its end but v hasnt
			save[counter] = v[indexV];
			indexV++;
			counter++;
			mergeNum(v, w, indexV, indexW, save, counter);
		}
        
		if (indexV == v.length && counter != save.length) {
			 //standard case where v has reached its end but w hasnt
			save[counter] = w[indexW];
			indexW++;
			counter++;
			mergeNum(v, w, indexV, indexW, save, counter);
		}
		if (indexV != v.length && indexW != w.length) {
			//if none have reacher their max length we check which has a smaller number
			//and add it to our new array
			if (v[indexV] <= w[indexW]) {
				save[counter] = v[indexV];
				indexV++;
				counter++;
			} else {

				save[counter] = w[indexW];
				indexW++;
				counter++;

			}
			mergeNum(v, w, indexV, indexW, save, counter);
		}

		return save;
	}

	/**
	 * For a given n returns the element of order n of the sequence L
	 * in which L(0)=2, L(-1)=-1 and L(n)=L(n+2)-L(n+1)
	 * 
	 * @param n order of the element 
	 * @requires {@code n<=0
	 * @return the element of n order in L sequence 
	 */
	
	public static long negativeLucasNumber(int n) {
		
		long result = 0;
		int a = 2;
		int b = -1;
		//in this cases doesnt need to check the L sequence
		if (n == 0)
			return 2;
		if (n == -1)
			return -1;
		result = lucas(n, a, b,result);
		return result;
	}

	public static long lucas(int n, int a, int b,long result) {
		
		if (n == -1) {
			//standard case 
			return b;
		}

		else {
			//does lucas for each n smaller than -1
			result = lucas(n + 1, b, a - b,result);

		}
		return result;
	}
}
