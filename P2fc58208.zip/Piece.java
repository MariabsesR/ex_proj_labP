import java.util.Random;

/**
 * The instances of this class represent pieces with a dimension of 3x3
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Piece {

	public static final String EOL = System.getProperty("line.separator");
	public static final int DIM = 3;
	private Cell[][] piece;

	/**
	 * Creates a Piece with the given shape
	 * 
	 * @param shape array with the shape of out piece
	 * @requires{@code shape.length==3 && shape[0].length==3 && shape[1].length==3
	 *                 && shape[2].length==3
	 */
	public Piece(Cell[][] shape) {
		// creates attribute with predetermined Dimension
		piece = new Cell[DIM][DIM];
		// runs through shapes and makes our piece equal to it

		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				piece[i][j] = shape[i][j];

			}
		}
	}

	/**
	 * Creates a Piece filled with the given Cell type
	 * 
	 * @param type type of Cell that will fill the Piece
	 */

	public Piece(Cell type) {

		// creates attribute with predetermined Dimension
		piece = new Cell[DIM][DIM];

		// runs through our piece and gives all the cells the value of
		// the type given
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				
				piece[i][j] = type;
			}
		}
	}

	/**
	 * Given a Random generator builds a piece in which the values are chosen
	 * randomly
	 * 
	 * @param generator Random generator used to decide the values
	 */
	public Piece(Random generator) {
		
		// creates attribute with predetermined Dimension
		piece = new Cell[DIM][DIM];
		
		// using a random generator chooses the value of each cell in the piece
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				
				long choose = generator.nextInt(2);
				if (choose == 0)
					piece[i][j] = Cell.BUSY;
				else
					piece[i][j] = Cell.FREE;

			}
		}
	}

	/**
	 * Indicates how many positions in the Piece have the value Cell.BUSY
	 * 
	 * @return the amount of cells on the piece filled
	 */

	public int weight() {

		int counter = 0;
		
		// counts the number of Cell.BUSY in our piece
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				
				if (piece[i][j] == Cell.BUSY)
					counter++;
			}
		}
		return counter;
	}

	/**
	 * Returns a copy of the cells in our Piece
	 * 
	 * @return array with the cells of our Piece
	 */

	public Cell[][] getCells() {
        
		//makes a copy of the shaper of our peace and returns it
		Cell[][] copy = new Cell[DIM][DIM];
		
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
			
				copy[i][j] = piece[i][j];
			}
		}
		return copy;
	}

	/**
	 * Flips the piece vertically
	 */

	public void flipVertical() {

		for (int i = 0; i < DIM; i++) {
			// the column value is restarted after each line
			int column = DIM - 1;
			for (int j = 0; j < DIM / 2; j++) {
				
				// saves the first piece
				Cell save = piece[i][j];
				// puts the piece of the last column in the first column,same line
				piece[i][j] = piece[i][column];
				// and puts the saved cell on the last column, same line
				piece[i][column] = save;
				// makes the column smaller
				column--;

			}
		}

	}

	/**
	 * Flips the piece horizontally
	 */
	public void flipHorizontal() {

		int line = DIM - 1;
		for (int i = 0; i < DIM / 2; i++) {

			for (int j = 0; j < DIM; j++) {
				// saves the cell
				Cell save = piece[i][j];
				// trades the saved cell with the cell on the same column
				// but the last line of the piece
				piece[i][j] = piece[line][j];
				piece[line][j] = save;

			}
			// after all the columns the line gets smaller so
			// the next one will work with the 2 line and the last time -1
			line--;
		}
	}

	/**
	 * Rotates the piece 90 degrees
	 */
	public void rotate90() {

		Cell[][] rotate = new Cell[DIM][DIM];

		for (int i = 0; i < DIM; i++) {
			// saves each line of our piece
			Cell[] save = new Cell[DIM];
			save = piece[i];
			for (int j = 0; j < DIM; j++) {
				
				// puts each lien of our piece in the last column of
				// the rotate array
				rotate[j][DIM - 1 - i] = save[j];
			}
		}
		// saves our new piece
		piece = rotate;
	}

	/**
	 * Returns the textual representation of the Piece
	 *
	 * @returns textual representation of the Piece
	 */

	@Override
	public String toString() {
		
		StringBuilder newPieceBuilder = new StringBuilder();
		
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				
				// creates all the values and space between them
				newPieceBuilder.append(piece[i][j]);
				newPieceBuilder.append(" ");
			}
			// changes line after all columns
			newPieceBuilder.append(EOL);
		}
		return newPieceBuilder.toString();
	}

	/**
	 * Checks if the Piece is equal to the one given
	 * 
	 * @param other piece that we gone compare our Piece to
	 * @requires {@code outro!=null}
	 * @return whether the pieces are equal
	 */
	public boolean isEqual(Piece other) {

		boolean isEqual = true;
		Cell[][] test = other.getCells();
		
		for (int i = 0; i < DIM && isEqual != false; i++) {
			for (int j = 0; j < DIM && isEqual != false; j++) {
				
				// checks if the piece have the same values
				if (piece[i][j] != test[i][j])
					isEqual = false;

			}
		}
		return isEqual;
	}

	/**
	 * Checks if the piece given fits our Piece
	 * 
	 * @param outro Piece to test
	 * @return the pieces fit together
	 * @requires {@code outro!=null}
	 */
	public boolean fits(Piece outro) {
		
		boolean fits = true;
		Cell[][] test = outro.getCells();
		
		for (int i = 0; i < DIM && fits != false; i++) {
			for (int j = 0; j < DIM && fits != false; j++) {
		
				// if both pieces have the cell as busy then they can t fit
				if (test[i][j] == Cell.BUSY && piece[i][j] == Cell.BUSY)
					fits = false;
			}
		}
		return fits;
	}

	/**
	 * Merges the given Piece with our Piece
	 * 
	 * @param outro Piece to merge
	 * @requires {@code outro!=null && Piece.fits(outro)==true}
	 * @return merged Piece
	 */

	public Piece merge(Piece outro) {
		// merges our pieces by transforming the empty cells in busy
		Cell[][] test = outro.getCells();

		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {

				if (piece[i][j] == Cell.BUSY)
					test[i][j] = Cell.BUSY;
			}
		}

		return new Piece(test);
	}

	/**
	 * Returns a copy of our Piece with the same shape
	 * 
	 * @return copy of Piece
	 */

	public Piece copy() {
		
		// makes a copy of our piece cells and returns it
		Cell[][] copy = new Cell[DIM][DIM];
		
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				
				copy[i][j] = piece[i][j];
			}
		}

		return new Piece(copy);
	}

}
