
import java.util.Random;

/**
 * The instances of this class represent games in wshich the objective is to
 * fits the biggest number of pieces possible in the board
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Game {

	public static final int DIM = 3; // dimension pieces
	public static final String EOL = System.getProperty("line.separator");

	public int lines;
	public int columns;
	public int points;
	public Piece nextPiece;
	public boolean pieceFits;
	public boolean playIsNotValid;
	private Random rd;
	private Cell[][] saveBoardPiece;
	public Cell[][] board;

	/**
	 * Creates an instance of the game in which the board has 20 lines and 12
	 * columns and fills the board depending on the difficulty chosen
	 * 
	 * @param dificuldade
	 * @param generator
	 * @requires {@code linhas >0 && colunas>0 && dificuldade>0}
	 */

	public Game(int dificuldade, Random generator) {
		//generates the game with this predetermined size
		lines = 20;
		columns = 12;
		generateGame(this.lines, this.columns, dificuldade, generator);

	}

	/**
	 * Creates an instance of the game in which the board has the size of the input
	 * and fills the board depending on the difficulty chosen
	 * 
	 * @param linhas      amount of lines in the board
	 * @param colunas     amount of columns in the board
	 * @param dificuldade amount of cells on the board that are occupied
	 * @param generator   randomizer of the position of the occupied cells
	 * 
	 * @requires {@code linhas >0 && colunas>0 && dificuldade>0}
	 */

	public Game(int linhas, int colunas, int dificuldade, Random generator) {
		//makes the size of our board the input of the user  before generating the game
		lines = linhas;
		columns = colunas;
		generateGame(linhas, colunas, dificuldade, generator);

	}

	/**
	 * Returns a copy of the current piece in Game
	 * 
	 * @return a copy of our current piece
	 */

	public Piece getCurrentPiece() {

		return nextPiece.copy();
	}

	/**
	 * Checks if the current Game is over
	 * 
	 * @return true if the current game is over;
	 */

	public boolean isFinished() {
		
		boolean isFullBusy = true;
		
		for (int i = 0; i < lines && isFullBusy == true; i++) {
			for (int j = 0; j < columns && isFullBusy == true; j++) {
				//Checks if the board if fully busy
				if (board[i][j] == Cell.FREE)
					isFullBusy = false;
			}
		}
        //to check if is finished it has to be full busy or the piece doesnt fit, or the last play was not valid
		return isFullBusy || !pieceFits || playIsNotValid;
	}

	/**
	 * Does n 90 degree rotations on the current piece in the Game
	 * 
	 * @param n the amount of times the piece shall be rotated
	 * @requires {@code i>=0}
	 */

	public void rotatePiece(int n) {
		for (int i = 0; i < n; i++) {
			nextPiece.rotate90();
		}

	}

	/**
	 * Flips horizontally the current piece in the Game
	 */
	public void flipHorizontal() {
		nextPiece.flipHorizontal();
	}

	/**
	 * Flips vertically the current piece in the Game
	 */

	public void flipVertical() {
		nextPiece.flipVertical();
	}

	/**
	 * Returns the textual representation of our game, which includes the board, the
	 * current piece in play, and the current score;
	 * 
	 * @returns a visual representation of our current Game
	 */

	@Override
	public String toString() {

		// creates our new StringBuilder
		StringBuilder newPieceBuilder = new StringBuilder();

		// creates our board
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < columns; j++) {

				newPieceBuilder.append("|");
				newPieceBuilder.append(" " + board[i][j] + " ");

			}
			// when each line is over append the lines number
			newPieceBuilder.append("|");
			newPieceBuilder.append(" " + i);
			newPieceBuilder.append(EOL);
		}
		// change line
		newPieceBuilder.append("" + EOL);
		// add the numbers of each columns
		for (int k = 0; k < columns; k++) {
			if (k == 0)
				newPieceBuilder.append("|");
			if (k <= 9)
				newPieceBuilder.append(" " + k + " |");
			else // to pass the tests
				newPieceBuilder.append(" " + k + "|");

		}
		// change line, create empty line
		newPieceBuilder.append(" " + EOL);
		newPieceBuilder.append("" + EOL);
		newPieceBuilder.append("Proxima Peca:" + EOL);
		// add the piece that will be played on the current round
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				newPieceBuilder.append(this.nextPiece.getCells()[i][j]);
				newPieceBuilder.append(" ");

			}
			// after each line of the piece change line
			newPieceBuilder.append(EOL);
		}
		// create an empty line, and show current points
		newPieceBuilder.append("" + EOL);
		newPieceBuilder.append("Pontuacao actual:" + points + EOL);
		newPieceBuilder.append("");

		return newPieceBuilder.toString();

	}

	/**
	 * Does the move with the current piece at play, in a way that the given line
	 * and column are the center of where the user wants to fir the piece
	 * 
	 * @param linha
	 * @param coluna
	 */

	public void play(int linha, int coluna) {

		// checks if the input is valid, can't be any of the border lines or border
		// columns
		if (linha <= 0 || linha >= board.length - 1 || coluna <= 0 || coluna >= board[0].length - 1)
			this.playIsNotValid = true;
		else {

			// gets the current board piece where the player wants to put the piece
			for (int i = 0; i < DIM; i++) {

				saveBoardPiece[0][i] = board[linha - 1][coluna - 1 + i];
				saveBoardPiece[1][i] = board[linha][coluna - 1 + i];
				saveBoardPiece[2][i] = board[linha + 1][coluna - 1 + i];

			}
			// gets the amount of Cell.BUSY in the current Piece we gonna play to use for
			// points
			int newPoints = nextPiece.weight();

			// checks if the piece fits
			pieceFits = nextPiece.fits(new Piece(saveBoardPiece));

			if (pieceFits == true) {
				// if piece fits it will do the play

				// merges our saved board piece with out random piece
				Piece merged = new Piece(saveBoardPiece).merge(nextPiece);
				// puts the new piece back on the board after it has been merged with our random
				for (int i = 0; i < DIM; i++) {
					board[linha - 1][coluna - 1 + i] = merged.getCells()[0][i];
					board[linha][coluna - 1 + i] = merged.getCells()[1][i];
					board[linha + 1][coluna - 1 + i] = merged.getCells()[2][i];

				}
				// adds our new points and randomizes the next piece to be played
				points += newPoints;
				nextPiece = new Piece(rd);

			}
		}
	}

	/**
	 * Returns the current value of the score of the current Game, that corresponds
	 * to the total positions occupied on the board
	 * 
	 * @return the score of the current game
	 */

	public int getScore() {
		return points;
	}

	/**
	 * Generates the attributes for our game, depending o the method that called it
	 * it may use our predetermined lines and columns or use the ones called by the
	 * method
	 * 
	 * @param linhas      lines that our board game will have
	 * @param colunas     columns that our board game will have
	 * @param dificuldade the amount of cells that shall be filled with
	 *                    {@code Cell.BUSY}
	 * @param generator   will randomly choose the positions of the filled cells
	 */

	private void generateGame(int linhas, int colunas, int dificuldade, Random generator) {

		// initializes our attributes
		this.rd = generator;
		saveBoardPiece = new Cell[DIM][DIM];
		board = new Cell[lines][columns];
		playIsNotValid = false;
		pieceFits = true;
		// our variables that will keep the randomized numbers created to choose which
		// cells shall contain Cell.BUSY
		int line;
		int column;
		// initializes our attribute that will save the place of the board where we
		// wanna fit our random piece
		for (int i = 0; i < DIM; i++) {
			for (int j = 0; j < DIM; j++) {
				saveBoardPiece[i][j] = Cell.FREE;

			}
		}
        //initializes our board whit all the cells  free;
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < columns; j++) {
				board[i][j] = Cell.FREE;

			}
		}
        //checks if the input of the difficulty his higher than the size of our board, if so makes our board fully filled with Cell.BUSY
		if (dificuldade > lines * columns)
			dificuldade = lines * columns;
		for (int i = 0; i < dificuldade; i++) {
			do {
				line = generator.nextInt(lines);
				column = generator.nextInt(columns);
			} while (board[line][column] == Cell.BUSY);

			board[line][column] = Cell.BUSY;
		}
		// generates the piece that the player shall use
		this.nextPiece = new Piece(generator);
		// Checks the amount of Cell.BUSY to make it our initial score
		this.points = dificuldade;
	}

}
