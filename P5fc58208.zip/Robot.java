import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Class that represents intances of Robots
 * 
 * @author Maria Rocha fc58208
 *
 */
public class Robot {

	// atributes of our Robot
	private String id;
	private int influence;
	private Type type;
	private boolean working;
	private boolean headOfFamily;
	private List<Robot> children;
	private int numberOfChildren;

	/**
	 * Creates an instance of a Robot
	 * 
	 * @param id        name of current robot
	 * @param influence amount of influence of the robot
	 * @param type      type of robot
	 */

	public Robot(String id, int influence, Type type) {

		this.id = id;
		this.influence = influence;
		this.type = type;
		working = true;
		children = new ArrayList<Robot>(11);
		numberOfChildren = 0;

		if (id.length() == 1)
			headOfFamily = true;
	}

	/**
	 * Returns the list of children of the current Robot
	 * 
	 * @return list of children of Robot
	 */
	public List<Robot> getChildren() {
		return children;
	}

	/**
	 * Checks if the current robot is the head of the family
	 * 
	 * @return the robot is the head of the family
	 */
	public boolean isHeadOfFamily() {
		return headOfFamily;
	}

	/**
	 * Sets the current Robot as the head of Family
	 */

	public void setAsHeadOfFamily() {
		headOfFamily = true;
	}

	/**
	 * Returns the amount of children that the current Robot has
	 * 
	 * @return amount of children
	 */
	public int getNumberOfChildren() {
		return numberOfChildren;
	}

	/**
	 * Updates the current amount of children that the current Robot has
	 * 
	 * @param add the number of children we want to add or substract
	 */
	public void setNumberOfChildren(int add) {
		numberOfChildren += add;
	}

	/**
	 * Checks if the current robot is working
	 * 
	 * @return the current robot is working
	 */

	public boolean isWorking() {
		return working;
	}

	/**
	 * Checks if the current robot can fabricate another; if so does it, if not
	 * returns false, after creating the robot it will update the influence of the
	 * creator robot
	 * 
	 * @param type type of robot to be created
	 * @return the current robot can fabricate a children robot
	 */

	public boolean fabricate(Type type) {

		boolean wrongTypeOfChild = false;
		// checks is the robot being created is the correct type
		if (type == Robot.Type.GIGACHAD) {
			wrongTypeOfChild = true;
		}
		// checks if the robot creating is a gigachad, if it has less than 10 children
		// and if the
		// child being created is not a gigachad, and checks if the creater robot is
		// working
		if (this.type != Robot.Type.GIGACHAD || numberOfChildren >= 10 || wrongTypeOfChild || !isWorking())
			return false;
		else {

			// adds the children to the first index available
			// and takes influence from the parent robot

			int newRobotInfluence = this.influence / 2;
			if (newRobotInfluence < 1)
				newRobotInfluence = 1;
			children.add(new Robot(this.id + numberOfChildren, newRobotInfluence, type));
			numberOfChildren++;
			// the parent robot cant have less than 1 of influence
			if (this.influence - 2 > 1)
				this.influence -= 2;
			else {
				influence = 1;
			}

			return true;
		}
	}

	/**
	 * Checks if the current robot has more influence then the challenger
	 * 
	 * @param challenger the robot that will challenge the current
	 * @requires {@code this.working && challenger.isWorking()}
	 * @return the current robot has more influence than the challenger
	 */

	public boolean hasDefeated(Robot challenger) {
		if (this.influence > challenger.influence)
			return true;
		else
			return false;
	}

	/**
	 * Deactivates the current robot, if the current robot is the head of family it
	 * will change so to false
	 */

	public void deactivate() {
		working = false;
		if (this.headOfFamily)
			this.headOfFamily = false;
	}

	/**
	 * Checks if the current robot is equal to the given one
	 * 
	 * @param b the robot to compare
	 * @return the robots are equal
	 */
	public boolean isEqual(Robot b) {
		boolean isEqual = headOfFamily == b.isHeadOfFamily() && influence == b.getInfluence()
				&& working == b.isWorking() && numberOfChildren == b.getNumberOfChildren() && id == b.getId();

		// checks if their children are the same and have the same atributes
		for (int i = 0; i < children.size(); i++) {
			isEqual = isEqual && children.get(i).headOfFamily == b.getChildren().get(i).isHeadOfFamily()
					&& children.get(i).influence == getChildren().get(i).getInfluence()
					&& children.get(i).working == b.isWorking()
					&& children.get(i).numberOfChildren == b.getChildren().get(i).getNumberOfChildren()
					&& children.get(i).getId() == b.getChildren().get(i).getId();
		}

		return isEqual;

	}

	/**
	 * Returns the id of the current robot
	 * 
	 * @return id of the current robot
	 */

	public String getId() {
		return id;
	}

	/**
	 * Returns the Robot.Type of the current robot
	 * 
	 * @return type of current robot
	 */

	public Robot.Type getType() {
		return type;
	}

	/**
	 * Changes the type of the current Robot
	 * 
	 * @param type the new type of the current Robot
	 */
	
	public void setType(Robot.Type type) {
		this.type = type;
	}

	/**
	 * Returns the current influence of the Robot
	 * 
	 * @return influence of the current Robot
	 */
	public int getInfluence() {
		return influence;
	}

	/**
	 *Updates the influence of the current robot
	 * 
	 * @param add ammount that we will add or substract to the influence
	 */
	
	public void setInfluence(int add) {
		influence += add;
	}

	/**
	 * The three possible types of a Robot: ENGINEER, PROTOTYPE and GIGACHAD
	 */
	public enum Type {
		ENGINEER, PROTOTYPE, GIGACHAD;
	}

	// ...

	/**
	 * Add some prefix to the buffer based on the robot status.
	 * 
	 * @param buffer     buffer to load strings
	 * @param separator  character that wll be used as separator
	 * @param typeString String that represents a type
	 */
	private void addStats(StringBuilder buffer, String separator, String typeString) {
		if (headOfFamily)
			buffer.append("Lord ");
		buffer.append(id);
		if (working) {
			buffer.append(" ").append(separator);
			buffer.append(typeString).append(":");
			buffer.append(influence).append(separator);
		} else {
			buffer.append("®");
		}
	}

	// This algorithm to print trees is an adaptation of the code by VasiliNovikov
	// - https://diasp.de/u/vn971
	public String toString() {
		StringBuilder buffer = new StringBuilder(50);
		print(buffer, "", "");
		return buffer.toString();
	}

	private void print(StringBuilder buffer, String prefix, String childrenPrefix) {
		buffer.append(prefix);
		switch (type) {
		case GIGACHAD:
			addStats(buffer, ":", "Æ");
			break;
		case ENGINEER:
			addStats(buffer, "|", "E");
			break;
		case PROTOTYPE:
			addStats(buffer, "|", "A");
			break;
		}
		buffer.append(GameMsg.EOL);

		for (Iterator<Robot> it = children.iterator(); it.hasNext();) {
			Robot next = it.next();
			if (it.hasNext()) {
				next.print(buffer, childrenPrefix + "├── ", childrenPrefix + "│   ");
			} else {
				next.print(buffer, childrenPrefix + "└── ", childrenPrefix + "    ");
			}
		}
	}

}
