import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

/**
 * Represent instances of a Game where the objective is to be last family with
 * working Robots The game finished when there is only one family that isnt
 * extinct
 * 
 * @author Maria Rocha fc58208
 *
 */
public class Game {

	// atributes of family
	private List<Family> families;
	private int currentFamilyInPlay;
	private int currentGameTurn;

	/**
	 * Creates an instance of Game
	 * 
	 * @param families   all the families in game
	 * @param influences the influences of each family
	 * @requires {@code families.length > 1 && 
	 * families.length < 10 && 
	 * families.length == influences.length} all names of the families cant be null
	 */

	public Game(String[] names, int[] influences) {
		families = new ArrayList<Family>();

		for (int i = 0; i < names.length; i++) {
			String robotName = String.valueOf(i);
			Family addNew = new Family(names[i], new Robot(robotName, influences[i], Robot.Type.GIGACHAD));
			this.families.add(i, addNew);
			families.get(i).getOwner().fabricate(Robot.Type.ENGINEER);
			families.get(i).getOwner().fabricate(Robot.Type.PROTOTYPE);
			families.get(i).getOwner().fabricate(Robot.Type.PROTOTYPE);
		}
		currentFamilyInPlay = 0;
		currentGameTurn = 1;

	}

	/**
	 * Verefies if bot is an Engenier and prot a prototype, if so merges them
	 * 
	 * @param bot
	 * @param family
	 * @param prot
	 * @requires {@code getPlaying().contains(bot) && family.contains(otherBot)}
	 * @return
	 */
	public boolean merge(Robot bot, Family family, Robot prot) {
		boolean canMerge = bot.getType() == Robot.Type.ENGINEER && prot.getType() == Robot.Type.PROTOTYPE;
		if (canMerge) {

			bot.setType(Robot.Type.GIGACHAD);
			bot.setInfluence(prot.getInfluence());
			family.removeRobot(prot);

		}
		return canMerge;
	}

	/**
	 * Returns the families playing the game
	 * 
	 * @return families playing the game
	 */
	public List<Family> getFamilies() {
		return families;
	}

	/**
	 * Returns the family that is currently playing
	 * 
	 * @return family currently playing
	 */
	public Family getPlaying() {

		return families.get(currentFamilyInPlay);
	}

	/**
	 * Checks if the current robot can fabricate a new child of the given type
	 * 
	 * @param botbot that will create a new child
	 * @param type   the type of child that will be created
	 * @requires getPlaying().contains(bot)
	 * @return the bot can fabricate that type of child
	 */
	public boolean createRobot(Robot bot, Robot.Type type) {
		if (bot != null)
			return bot.fabricate(type);
		else
			return false;
	}

	/**
	 * Receives the robot that will attack and defend and the family of the
	 * defensor, Returns true if the attacking robot won
	 * 
	 * @param botAtk
	 * @param fDef
	 * @param botDef
	 * @requires{@code getPlaying().contains(botAtk) && fDef.contains(botDef) &&
	 *                 fDef!=null}
	 * @return the attacking robot has won
	 */
	public boolean attack(Robot botAtk, Family fDef, Robot botDef) {

		if (botDef.hasDefeated(botAtk) || botDef.getInfluence() == botAtk.getInfluence()) {

			if (botAtk.isHeadOfFamily()) {
				// if the defeated was the head of family deactivates it and searches for a new
				// head
				botAtk.deactivate();
				families.get(currentFamilyInPlay).searchForHeir();

			} else
				botAtk.deactivate();

			return false;
		} else {

			if (botDef.isHeadOfFamily()) {
				// if the defeated was the head of family deactivates it and searches for a new
				// head
				botDef.deactivate();
				fDef.searchForHeir();

			} else
				botDef.deactivate();

			return true;
		}

	}

	/**
	 * Updates the current family playing
	 */
	public void updatePlaying() {
		currentFamilyInPlay = (currentFamilyInPlay + 1) % (families.size());
	}

	/**
	 * Searches for the family with the given name
	 * 
	 * @param familyName name of the family
	 * @return if the family exists returns it else returns null
	 */

	public Family findFamilyByName(String familyName) {

		for (int i = 0; i < families.size(); i++) {
			if (families.get(i).getName().equals(familyName))
				return families.get(i);
		}
		return null;
	}

	/**
	 * The current family playing will offer one of its prototyves to the given
	 * family if the current family playing offers a prototype returns true
	 * 
	 * @param fReceive family that shall receive the prototype
	 * @return can the current family playing offer a prototype
	 */

	public boolean offerPrototype(Family fReceive) {
		boolean finale = true;
		// if the family receiving doesnt have an head or has the maximum amount of
		// children
		// or there is no prototype to give since the owner has no children
		if (fReceive.getHeadFamily() == null || fReceive.getHeadFamily().getNumberOfChildren() >= 10
				|| families.get(currentFamilyInPlay).getOwner().getChildren().isEmpty()) {
			finale = false;
		}
		if (finale == true) {
			boolean prototype = false;
			Deque<Robot> q = new LinkedList<Robot>();
			q.add(families.get(currentFamilyInPlay).getOwner());
			finale = offerPrototypeRecursive(families.get(currentFamilyInPlay).getOwner(), fReceive, q, prototype);
		}

		return finale;
	}

	/**
	 * 
	 * @param current
	 * @param fReceive
	 * @return
	 */
	private boolean offerPrototypeRecursive(Robot current, Family fReceive, Deque<Robot> q, boolean prototype) {

		Robot test = q.remove();
		// checks if the current robot is a prototyve that cna be offered
		prototype = prototype || test.getType().equals(Robot.Type.PROTOTYPE) && test.isWorking();

		if (prototype) {
			families.get(currentFamilyInPlay).getHeadFamily().setInfluence(test.getInfluence() * 2);

			String newName = fReceive.getHeadFamily().getId() + fReceive.getHeadFamily().getNumberOfChildren();

			fReceive.getHeadFamily().getChildren().add(new Robot(newName, test.getInfluence(), test.getType()));
			fReceive.getHeadFamily().setNumberOfChildren(1);
			families.get(currentFamilyInPlay).removeRobot(test);

		}
		// if we havent foudn the prototype to give we add the children of the current
		// robot to the
		// queue
		if (!prototype)
			for (Robot test2 : test.getChildren()) {
				q.add(test2);
			}
		// if we havent found the prototype we will chekc the next robot on queue
		if (!q.isEmpty() && !prototype)
			prototype = offerPrototypeRecursive(current, fReceive, q, prototype);

		return prototype && fReceive.getHeadFamily() != null;
	}

	/**
	 * Removes the given robot from the family
	 * 
	 * @param robot robot we wish to destroy
	 * @requires{@code getPlaying().contains(robot)
	 * @return whether it could destroy the given robot
	 */

	public boolean destroyPrototype(Robot robot) {
		if (robot != null && robot.getType().equals(Robot.Type.PROTOTYPE)
				&& getFamilies().get(currentFamilyInPlay).contains(robot)) {
			if (robot.isHeadOfFamily()) {
				robot.deactivate();
				getFamilies().get(currentFamilyInPlay).searchForHeir();
			}
			getFamilies().get(currentFamilyInPlay).removeRobot(robot);
			return true;
		} else
			return false;
	}

	/**
	 * Checks if the game is finished, hence there is only one family that isnt
	 * extinct
	 * 
	 * @return the game is finished
	 */

	public boolean isFinished() {
		int counter = 0;
		for (int i = 0; i < families.size(); i++) {
			if (!families.get(i).isExtinct())
				counter++;
		}
		return counter == 1;
	}

	/**
	 * Returns the current game turn
	 * 
	 * @return current game turn
	 */
	public int getTurn() {
		return currentGameTurn;
	}

	/**
	 * Updates the current game turn
	 */
	public void nextTurn() {
		currentGameTurn++;
	}

}
