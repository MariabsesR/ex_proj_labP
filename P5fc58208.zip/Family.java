
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

/**
 * Represent instances of a Family of Robots which constitute trees
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Family {

	// atributes
	private String name;
	private final Robot owner;
	private Robot currentHeadOfFamily;

	/**
	 * Creates an instance of Family
	 * 
	 * @param name  name of the family
	 * @param owner current owner of the family
	 */

	public Family(String name, Robot owner) {
		this.name = name;
		this.owner = owner;
		currentHeadOfFamily = owner;
	}

	/**
	 * Tries to find the given id in the current Family
	 * 
	 * @param id id that is being searched for
	 * @requires id!=null e id must be a String of integers
	 * @return if the id exists within the family returns the robot, else returns
	 *         null
	 */
	public Robot findById(String id) {

		// if the owner has children enters here
		if (!owner.getChildren().isEmpty() && id.length() != 1) {
			// current character and counter will help us get to the correct
			// layer of the tree where our id could be
			int currentCharacter = 2;
			int counter = id.length() - 1;
			List<Robot> newList = owner.getChildren();
			Robot foundRobot = null;
			return findByIdRecursive(newList, counter, currentCharacter, owner, id, foundRobot);

		} else {
			// checks if the owner is the id we looking for
			if (owner.getId().equals(id))
				return owner;
			else
				return null;

		}
	}

	public Robot findByIdRecursive(List<Robot> newList, int counter, int currentCharacter, Robot current, String id,
			Robot foundRobot) {

		// gets the list of children we wanna acces
		if (counter > 1) {
			// gets the current characterthat designs the child we want
			String test = id.substring(0, currentCharacter);
			int index = -1;
			for (int i = 0; i < newList.size(); i++) {
				if (test.equals(newList.get(i).getId()))
					index = i;
			}

			// get the children of that child
			// in case it doesnt exist the child that would allows
			// us to get to the correct level of the tree
			// shall skip this and return null
			if (index != -1) {
				newList = newList.get(index).getChildren();
				counter--;
				currentCharacter++;
				// repeats the process until we are in the correct children list

				foundRobot = findByIdRecursive(newList, counter, currentCharacter, current, id, foundRobot);
			}
		}
		// searches for the child in the current list
		for (Robot testRobotId : newList) {

			if (testRobotId.getId().equals(id))
				foundRobot = testRobotId;
		}
		// if it wasnt found any the value of found robot will stay null
		// so it will return null

		return foundRobot;
	}

	/**
	 * Verifies if in the current family has any robot that is working, hence its
	 * not extinct
	 * 
	 * @return all robots arent working in the family
	 */

	public boolean isExtinct() {

		boolean extinct = false;

		if (!owner.getChildren().isEmpty() && !owner.isWorking()) {
			return testExtinct(owner, extinct);

		} else {
			return !owner.isWorking();
		}
	}

	public boolean testExtinct(Robot current, boolean extinct) {

		boolean isExtinct = true;

		if (current.isWorking()) {
			isExtinct = false;
			return false;

		}
		// checks the children of the current robot
		// and calls the method to keep on going to check the tree
		for (Robot testRobotId : current.getChildren()) {

			isExtinct = isExtinct && testExtinct(testRobotId, isExtinct);

		}

		return isExtinct;

	}

	/**
	 * Searches for a new head of family that is working and changes the head of the family,
	 * if there is none available it becomes null
	 * 
	 * @return new head of family
	 */
	public Robot searchForHeir() {
		if (owner.isWorking())
			return owner;
		if (!owner.getChildren().isEmpty())
			return searchForHeirRecursive(owner, owner.getChildren());
		else
			currentHeadOfFamily = null;
		// if the owner isnt working and it has no children can only be null
		return null;
	}

	private Robot searchForHeirRecursive(Robot current, List<Robot> children) {

		boolean goodRobot = false;

		// chekc sthe condition for current to be a new head
		goodRobot = (current.getType() == Robot.Type.ENGINEER || current.getType() == Robot.Type.GIGACHAD)
				&& current.isWorking();
		// if the head of family hasnt been changed yet and the current
		// checks all the rules to be a new head then chnages the current head of family
		if (goodRobot && !currentHeadOfFamily.isWorking()) {
			setHeadOfFamily(current);
		}
		//while the new head of family hasnt been found searches the children 
		if (!currentHeadOfFamily.isWorking()) {
			for (Robot testRobot : current.getChildren()) {
				searchForHeirRecursive(testRobot, testRobot.getChildren());
			}
		}
		// if the current head of family hasnt changed after returning to the owner
		// means nobody cna be a heir of the family so the current head become null
		if (!currentHeadOfFamily.isWorking() && current.getId() == owner.getId())
			currentHeadOfFamily = null;

		return currentHeadOfFamily;

	}

	/**
	 * Checks if the family contains the given Robot
	 * 
	 * @param b robot to search for in the family
	 * @requires{@code b!=null}
	 * @return the family contains the given robot
	 */

	public boolean contains(Robot b) {
		Robot testRobot = findById(b.getId());
		boolean sameRobot = false;
		if (testRobot == null)
			return false;
		else {
			// checks if they are the same instance or if they have the same atributtes
			if (testRobot == b)
				return true;
			sameRobot = testRobot.isEqual(b);
		}

		return sameRobot;
	}

	/**
	 * Returns a textual representation of Family
	 */

	@Override
	public String toString() {
		StringBuilder stb = new StringBuilder();
		stb.append(GameMsg.EOL).append(name).append(GameMsg.EOL);
		stb.append(owner.toString());
		return stb.toString();
	}

	/**
	 * Returns the name of the family
	 * 
	 * @return name of current family
	 */
	public String getName() {

		return name;
	}

	/**
	 * Returns the Robot that is head of the family
	 * 
	 * @return robot that is head of family
	 */

	public Robot getHeadFamily() {

		return currentHeadOfFamily;
	}

	/**
	 * makes the new Head of family the given robot
	 * 
	 * @param b robot that shall be the new head of family
	 */

	public void setHeadOfFamily(Robot b) {
		currentHeadOfFamily = b;
		b.setAsHeadOfFamily();
	}

	/**
	 * Returns the owner of the current family
	 * 
	 * @return owner of the current family
	 */
	public Robot getOwner() {

		return owner;
	}

	/**
	 * Searches for a robot in the family with biggern influence than the current
	 * head of family
	 * 
	 * @return robot with biggest influence
	 */
	public Robot findInfluencer() {

		Deque<Robot> q = new LinkedList<Robot>();
		q.add(owner);
		int biggestInfluence = currentHeadOfFamily.getInfluence();
		Robot influencerRobot = owner;
		influencerRobot = findInfluencerRecursive(q, biggestInfluence, influencerRobot);

		return influencerRobot;

	}

	/**
	 * Searches the tree for a robot with bigger influence than the head of family
	 * 
	 * 
	 * @param q                current robot to check influence
	 * @param biggestInfluence biggest influence in the tree, in this case starts
	 *                         with the head of family influence
	 * @param influencerRobot  the robot with biggest influence
	 * @return robot with biggest influencer in the family tree
	 */
	private Robot findInfluencerRecursive(Deque<Robot> q, int biggestInfluence, Robot influencerRobot) {

		Robot test = q.remove();

		// cheks if the current robot has bigger influence and isnt a prototype
		if (test.isWorking() && test.getInfluence() >= biggestInfluence
				&& !test.getType().equals(Robot.Type.PROTOTYPE)) {
			biggestInfluence = test.getInfluence();
			influencerRobot = test;

		}
		// adds all the current children of the current robot
		/// so when we call the method again it checks the children of the current
		// and ads it to the queque
		for (Robot test2 : test.getChildren()) {
			q.add(test2);
		}
		// while q is not empty(hasnt chekeck all tree) it needs to get searching for
		// the biggest influencer
		if (!q.isEmpty())
			influencerRobot = findInfluencerRecursive(q, biggestInfluence, influencerRobot);
		return influencerRobot;

	}

	/**
	 * Receives as parameter a challenger that will challenge the head of the
	 * family; in case it wins it will become the new head of the family and
	 * deactives the old head; if the challenger is victorious returns true
	 * 
	 * @param head challenger robot
	 * @requires{@code head.getType()==Robot.Type.ENGINEER ||
	 *                 head.getType()==Robot.Type.GIGACHAD}
	 * @return the challenger won
	 */

	public boolean challengerVictory(Robot head) {

		if (getHeadFamily().getInfluence() < head.getInfluence() && head != currentHeadOfFamily) {
			currentHeadOfFamily.deactivate();
			currentHeadOfFamily = head;
			head.setAsHeadOfFamily();
			return true;
		}
		// if the challenger lost deactivates it
		head.deactivate();
		return false;
	}

	/**
	 * Removes the given robot from the family tree
	 * 
	 * @param b robot that we wanna remove
	 * @requires family.contains(b)
	 */
	public void removeRobot(Robot b) {
		String robotName = b.getId();
		String parentRobot = robotName.substring(0, robotName.length() - 1);
		Robot engeneerRobot = findById(parentRobot);
		for (int i = 0; i < engeneerRobot.getChildren().size(); i++) {
			if (engeneerRobot.getChildren().get(i).getId().equals(b.getId()))
				engeneerRobot.getChildren().remove(i);
		}

	}

}
