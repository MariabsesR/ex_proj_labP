import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

/**
 * This class codifies and descodifies alphabetical messages using predefined
 * rules
 * 
 * Rule 1:Each word of the original test is codified separately, the space
 * between them is preserved and is codified from the left to the right
 * 
 * Rule 2:If the letter from the original word doesn't belong in the
 * alphabetical key use cod(letter)
 * 
 * Rule 3: If the letter belongs in the alphabetical key,codify it to a 3 letter
 * String being the first the {@code m} letter of the alphabetic key then
 * cod(letter) and the m+1 letter of the alphabetic key
 * 
 * @author Maria Rocha fc58208
 *
 */

public class CoderDecoder {

	private Scanner sc;
	private String alphabet1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private int numberKey;
	private StringBuilder newLine = new StringBuilder();
	private int m;
	private PrintWriter out;
	private String alphabeticalKey;
	private int numMessages;
	private boolean codify = false;
	private String[] change;

	/**
	 * Codifies the message in inFile according to the 3 predefined rules
	 * 
	 * @param inFile  Name of the input file with original message
	 * @param outFile Name of the output file for the coded message
	 * @requires {@code inFile!=null && outFile!=null}
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	public void codify(String inFile, String outFile) throws FileNotFoundException, IOException {

		information(inFile, outFile);
		// used in cod to see if it should codify or reverse
		codify = true;
//-------------------------------runs through the lines-----------------------
		for (int i = 0; i < numMessages; i++) {
			// resets the line and m at each Line
			newLine.setLength(0);
			m = 1;

			// Divides message in words
			String[] words = sc.nextLine().split(" ");

//--------------------------- runs through all the words-------------------------
			for (int k = 0; k < words.length; k++) {
				// adds the spaces between words
				if (k != 0)
					newLine.append(" ");
				// divides words in chars
				String[] codif = words[k].split("");

//---------------------------runs trough chars of each word------------------------
				for (int j = 0; j < codif.length; j++) {
					// checks if the character is in the alphabetical key
					if (alphabeticalKey.contains(codif[j]) == false) {
						// Does Rule 2
						String newChar = cod(codif[j]);
						newLine.append(newChar);

					} else {
						// since char is in alphabetic key does Rule 3

						// consider m-1 =m to do index
						// consider m =m+1 to do index
						newLine.append(change[(m - 1) % change.length]);
						newLine.append(cod(codif[j]));
						newLine.append(change[m % change.length]);
						m++;

					}

				}

			}
			out.println(newLine.toString());

		}
		codify = false;
		sc.close();
		out.close();
	}

	/**
	 * Transforms each letter to the letter N positions in front of it in the
	 * Alphabet or reverses it depending on the method who called it
	 * 
	 * @param c char to be modified
	 * @return the character codified or decodified
	 */

	private String cod(String c) {

		// checks index of orignal letter
		int n = alphabet1.indexOf(c);
		// first if its to codify and second is to discodify

		if (codify == true)
			n = (n + numberKey) % 26;
		else {
			// when it gets to 0 restarts the n at 26
			if (n + numberKey < 0) {

				n = 26 + (n + numberKey) % 26;
			} else
				n = (n + numberKey) % 26;

		}
		// returns the new char
		return Character.toString(alphabet1.charAt(n));

	}

	/**
	 * Decodifies the message in inFile according to the 3 predefined rule
	 * 
	 * @param inFile  Name of the input file with original message
	 * @param outFile Name of the output file for the decoded message
	 * @requires {@code inFile!=null && outFile!=null}
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	public void decodify(String inFile, String outFile) throws FileNotFoundException, IOException {
		information(inFile, outFile);
		// reverses the number key
		numberKey = -numberKey;

//---------------------- runs through the lines---------------------------------------
		for (int i = 0; i < numMessages; i++) {
			// StringBuidler get reset to 0 and m to 1
			newLine.setLength(0);
			m = 1;
			boolean errorInCodification = false;

			String[] words = sc.nextLine().split(" ");
			// saves the index of the last appended character
			int index = 0;
//------------------------- runs through all the words--------------------------------
			for (int k = 0; k < words.length && errorInCodification == false; k++) {
				// adds spaces to the phrase
				if (k != 0) {
					newLine.append(" ");
					index++;
				}

				String[] newCharSave = words[k].split("");

//------------------------------- runs trough chars of each word-------------------------
				int lastIndexUsed = 0;
				for (int j = 0; j < newCharSave.length && errorInCodification == false; j++) {

					String newChar = cod(newCharSave[j]);
					// reverses rule 2
					if (alphabeticalKey.contains(newChar) == false) {

						newLine.append(newChar);
						index++;

					} else {

						// reverses rule 3
						String[] change = alphabeticalKey.split("");

						if (j != 0)
							newLine.deleteCharAt(index - 1);

						newLine.append(newChar);

//--------------------------------- test rule 3 -------------------------------------------
						errorInCodification = testRules(j, newCharSave, change, errorInCodification, lastIndexUsed);

						lastIndexUsed = j + 1; // save the index of the last character used in rule 3
						m++;
						j++; // skip a char since it was already used for rule 3

					}

				}
			}

			if (errorInCodification == false)
				out.println(newLine.toString());
			else
				out.println("Error in codification");
		}
		sc.close();
		out.close();
	}

	/**
	 * Saves and prints in the outFile the informations of the codification that are
	 * specified in the inFile
	 * 
	 * @param inFile  Name of the input file
	 * @param outFile Name of the output file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	private void information(String inFile, String outFile) throws FileNotFoundException, IOException {
		// create the file to print to
		out = new PrintWriter(new File(outFile));
		// create scanner to read from file
		sc = new Scanner(new File(inFile));
		// save the alphabetical Key
		alphabeticalKey = sc.nextLine();
		change = alphabeticalKey.split("");
		out.println(alphabeticalKey);
		// save the number key
		numberKey = sc.nextInt();
		out.println(numberKey);
		sc.nextLine();
		// save the number of messages
		numMessages = sc.nextInt();
		out.println(numMessages);
		sc.nextLine();

	}

	/**
	 * Checks the character and the characters before it and after to see if the
	 * codification was well done
	 * 
	 * @param j                   current char indicator
	 * @param newCharSave         saved chars of each word
	 * @param change              array with alphabetic key
	 * @param errorInCodification saves if there was an error in the codification
	 * @param lastIndexUsed       index of the last char that was used for rule 3
	 * @return if the character tested has an error in its codification
	 */

	private boolean testRules(int j, String[] newCharSave, String[] change, boolean errorInCodification,
			int lastIndexUsed) {
		// if it is rule 3 and is in the begginign or end of the words then has no
		// letters to surround
		// hence error in codification
		if (j == 0 || j == newCharSave.length - 1)
			errorInCodification = true;
		else {
			// checks if the letters surround the char that has rule 3 are corret
			if (newCharSave[j - 1].matches(change[(m - 1) % change.length]) == false
					|| newCharSave[j + 1].matches(change[m % change.length]) == false) {

				errorInCodification = true;
			}
			// checks if the chars that permit rule 3 are not the ones that
			// Permitted the last char that used rule 3
			if (lastIndexUsed == j - 1 && lastIndexUsed != 0)
				errorInCodification = true;

		}

		return errorInCodification;
	}

}
