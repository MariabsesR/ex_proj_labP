import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * This class is used to recognize defined Patterns 
 * 
 * @author Maria Rocha fc58208
 *
 */
public class RecognisePatterns {

	/**
	 * Checks if the given string is a valid Student Email
	 * 
	 * @param s string to test
	 * @return the given string is a valid email
	 */

	public static boolean isValidStudentEmail(String s) {
		Pattern myPat = Pattern.compile("fc[0-9]{5}@alunos.fc.ul.pt");
		if (s != null) {
			Matcher myMatch = myPat.matcher(s);
			if ( myMatch.matches()) {
				return true;
			}
		}
		return false;

	}
	
	/**
	 * Verifies if the given String is a valid IP adress 
	 * 
	 * @param s the string to test 
	 * @return the given string is a valid IP adress 
	 */

	public static boolean isValidIPAddress(String s) {

		String between0and255 = "(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])";
		Pattern myPat = Pattern
				.compile(between0and255 + "\\." + between0and255 + "\\." + between0and255 + "\\." + between0and255);
		if (s != null) {
			Matcher myMatch = myPat.matcher(s);

			if ( myMatch.matches()) {
				return true;
			}
		}
		return false;

	}

	/**
	 * Checks if the given string contains a date that is formated like NameMonth Day, Year 	
	 * 
	 * @param s the string we want to see if it has a date formated like so
	 * @return if a date with that format was found it will be returned
	 */
	
	public static String matchDate(String s) {

	

		String regexMonths31Days = "(Jan|Mar|May|Jul|Aug|Out|DecApr|Jun|Sep|Jul|Nov|Feb)\\.\\s([0-9]|1[0-9]|2[0-9]|3(1|0))\\,\\s(19[0-9][0-9]|20[0-9][0-9])";
		
		if (s != null) {
			Pattern myPat = Pattern.compile(regexMonths31Days, Pattern.MULTILINE);
			Matcher myMatch = myPat.matcher(s);
			if (myMatch.find()) {
				return myMatch.group(0);
			}
			
		}
		return null;
	}

	/**
	 *Checks of the given string is a valid Parking reservation
	 * 
	 * @param reservation the string to check
	 * @return the reservation is valid 
	 */
	
	public static boolean verifyParkingReservations(String reservation) {
		String regex = "\\d\\d\\d\\d[a-z][a-z]-[a-z]{3,20}\\s\\(([0-1][0-9]|2[0-3]):[0-5][0-9]\\,[0-9].[0-9]\\)";
		Pattern myPat = Pattern.compile(regex, Pattern.MULTILINE);
		if (reservation != null) {
			Matcher myMatch = myPat.matcher(reservation);
			if ( myMatch.find()) {

				return true;
			}
		}
		return false;
	}

}
