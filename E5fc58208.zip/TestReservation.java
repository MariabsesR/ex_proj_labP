import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * 
 * JUnit Tests for the method verifyParkingReservations of the class
 * RecognisePatterns
 * 
 * Characteristic number 1
 *  Description:The car registration must be composed by
 * 6 characters, 4 of them integer followed by 2 lowercase letters 
 * Regions: true or false
 *
 * Characteristic number 2 
 * Description: The type of vehicle must be made from in
 * the minimum 3 letters in the maximum 20, all of them lowerCase
 *  Regions: true or false
 *
 * Characteristic number 3
 * Description: the hour hh:mm must be made from 5
 * characters,2 of them indicating the hour, two to indicate the minutes, and
 * they must be separated by a ':'. hours have values between 00 and 23 and
 * minutes are between 00 and 59 
 * Regions: true or false
 *
 * Characteristic number 4 
 * Description: The length of the car must be described
 * in a x.y format it being a decimal number made by 2 integers seperate by a
 * point
 * Regions: true or false
 * 
 * 
 * Characteristic number 5 
 * Description:between the registration-type and the
 * pair(hh:mm,x.y) it is only accepted a space and the remaining separators "-"
 * "(" "," ")" must all be included so the format of a reservation is correct
 * Regions: true or false
 * 
 * Total number of viable combinations: 16
 *
 * @author Maria Rocha fc58208
 *
 */

public class TestReservation {

	@Test
	/**
	 * Test a reservation showing the right format 
	 * 
	 * The car registration must be composed by 6 characters, 4 of them integer followed by 2 lowercase:true
	 * 
	 * the type of vehicle must be made from in the minimum 3 letters in the maximum
	 * 20, all of them lowerCase:true
	 * 
	 * the hour hh:mm must be made from 5 characters,2 of them indicating the hour,
	 * two to indicate the minutes, and they must be separated by a ':'. hours have
	 * values between 00 and 23 and minutes are between 00 and 59:true
	 * 
	 * 
	 * The length of the car must be described in a x.y format it being a decimal
	 * number made by 2 integers separate by a point :true
	 * 
	 * between the registration-type and the pair(hh:mm,x.y) it is only accepted a
	 * space and the remaining separators "-" "(" "," ")" must all be included so
	 * the format of a reservation is correct :true
	 * 
	 */
	public void testDate1() {

		assertTrue(RecognisePatterns.verifyParkingReservations("2355xf-car (11:05,4.7)"));
	}

	@Test
	/**
	 * Test a reservation showing the wrong format 
	 * 
	 * The car registration must be composed by 6 characters, 4 of them integer followed by 2 lowercase:true
	 * 
	 * the type of vehicle must be made from in the minimum 3 letters in the maximum
	 * 20, all of them lowerCase:true
	 * 
	 * the hour hh:mm must be made from 5 characters,2 of them indicating the hour,
	 * two to indicate the minutes, and they must be separated by a ':'. hours have
	 * values between 00 and 23 and minutes are between 00 and 59 :true
	 * 
	 * The length of the car must be described in a x.y format it being a decimal
	 * number made by 2 integers seperate by a point:true
	 * 
	 * between the registration-type and the pair(hh:mm,x.y) it is only accepted a
	 * space and the remaining separators "-" "(" "," ")" must all be included so
	 * the format of a reservation is correct :false
	 * 
	 */
	public void testDate2() {

		assertFalse(RecognisePatterns.verifyParkingReservations(null));
	}

	@Test
	/**
	 * Test a reservation showing the wrong format The car registration must be
	 * composed by 6 characters, 4 of them integer followed by 2 lowercase:true
	 * 
	 * the type of vehicle must be made from in the minimum 3 letters in the maximum
	 * 20, all of them lowerCase:true
	 * 
	 * the hour hh:mm must be made from 5 characters,2 of them indicating the hour,
	 * two to indicate the minutes, and they must be separated by a ':'. hours have
	 * values between 00 and 23 and minutes are between 00 and 59:false
	 * 
	 * The length of the car must be described in a x.y format it being a decimal
	 * number made by 2 integers seperate by a point:true
	 * 
	 * between the registration-type and the pair(hh:mm,x.y) it is only accepted a
	 * space and the remaining separators "-" "(" "," ")" must all be included so
	 * the format of a reservation is correct :true
	 * 
	 */
	public void testDate3() {

		assertFalse(RecognisePatterns.verifyParkingReservations("2355xf-car (27:05,4.7)"));
	}

	@Test
	/**
	 * Test a reservation showing the right format The car registration must be
	 * composed by 6 characters, 4 of them integer followed by 2 lowercase:true
	 * 
	 * the type of vehicle must be made from in the minimum 3 letters in the maximum
	 * 20, all of them lowerCase:false
	 * 
	 * the hour hh:mm must be made from 5 characters,2 of them indicating the hour,
	 * two to indicate the minutes, and they must be separated by a ':'. hours have
	 * values between 00 and 23 and minutes are between 00 and 59:true
	 * 
	 * The length of the car must be described in a x.y format it being a decimal
	 * number made by 2 integers separate by a point:true
	 * 
	 * between the registration-type and the pair(hh:mm,x.y) it is only accepted a
	 * space and the remaining separators "-" "(" "," ")" must all be included so
	 * the format of a reservation is correct :true
	 * 
	 */
	public void testDate4() {

		assertFalse(RecognisePatterns.verifyParkingReservations("2355xf-carroRoboAutocarroJoana (11:05,4.7)"));
	}
}
