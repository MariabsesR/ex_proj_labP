import static org.junit.Assert.*;
import org.junit.Test;

/**
* 
*
* JUnit Tests for the method isValidIPAddress of the class RecognisePatterns
*
* Characteristic number 1
* The ip has 4 different number separated by  .
* Regions: true or false 
*
* Characteristic number 2
* Description: the numbers of the ip are between 0 and 255
* Regions: true or false 
*
* Characteristic number 3
* all numbers are separated by . and have nothing before it or forward to it
* Regions: true  or false 
*
* Total number of viable combinations: 8
*
* @author Maria Rocha fc58208
*
*/
public class TestIP {

	

	@Test
	/**
	 * Test an ip adress showing the right format
	 *   The ip has 4 different number separated by  .: true
	 *   the numbers of the ip are between 0 and 255 : true
	 *   all numbers are separated by . and have nothing before it or forward to it: true
	 */
	public void testisValidIPAddress  () {	
		assertTrue(RecognisePatterns.isValidIPAddress("254.1.1.106"));
	}

	
	@Test
	/**
	 * Test an ip adress showing the right format
	 *   The ip has 4 different number separated by '.' : false
	 *   the numbers of the ip are between 0 and 255 : true
	 *   all numbers are separated by . and have nothing before it or forward to it: true
	 */
	public void testisValidIPAddress2  () {	
		assertFalse(RecognisePatterns.isValidIPAddress("1.0.106"));
	}
	
	@Test
	/**
	 * Test an ip adress showing the wrong format
	 *   The ip has 4 different number separated by '.' : true
	 *   the numbers of the ip are between 0 and 255 : false
	 *   all numbers are separated by . and have nothing before it or forward to it: true
	 */
	public void testisValidIPAddress3  () {	
		assertFalse(RecognisePatterns.isValidIPAddress("275.1.0.106"));
	}
	
	@Test
	/**
	 * Test an ip adress showing the wrong format
	 *   The ip has 4 different number separated by '.' : true
	 *   the numbers of the ip are between 0 and 255 : true
	 *   all numbers are separated by . and have nothing before it or forward to it: false
	 */
	public void testisValidIPAddress4  () {	
		assertFalse(RecognisePatterns.isValidIPAddress("132.1.0.106."));
	}
}
