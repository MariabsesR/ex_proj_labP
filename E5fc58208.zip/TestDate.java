import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Skeleton to create the four classes of testing for exercise number 5
 *
 * JUnit Tests for the method matchDate of the class RecognisePatterns
 *
 * Characteristic number 1
 *  Description: the Month must be described by the 3 first letters of its name
 *  being the first in uppercase and a '.' at the end Regions: true or false
 *
 * Characteristic number 2 
 * Description: the day must be represented by an
 * integer from 0-31 or 0-29 or 0-30 depending on the month Regions: true or
 * false
 *
 * Characteristic number 3
 *  Description: year must be represented by integers
 * like XXXX Regions: true or false
 *
 * Characteristic number 4 
 * Description: the date must follow a representation
 * like "Month Day, Year" Regions: true or false
 *  Total number of viable combinations: 8
 *
 * @author Maria Rocha fc58208
 *
 */
public class TestDate {

	@Test
	/**
	 * Test an email showing the right format 
	 * the Month must be described by the 3  first letters of its name  being the first in uppercase and a '.'at the end: true 
	 * the day must be represented by an integer from 0-31 or 0-29 or 0-30 depending on the month:true 
	 * year must be represented by integers like XXXX:true
	 * the date must follow a representation like "Month Day, Year" :true
	 * 
	 */
	public void testDate1() {
		String n =RecognisePatterns.matchDate(" Atlanta on Jan. 15, 1929 nnnn");
		
		assertTrue(n!=null);
	}

	@Test
	/**
	 * Tests a Date showing the wrong format 
	 * the Month must be described by the 3  first letters of its name  being the first in uppercase and a '.'at the end: true 
	 * the day must be represented by an integer from 0-31 or 0-29 or 0-30 depending on the month:true 
	 * year must be represented by integers like XXXX:true
	 * the date must follow a representation like "Month Day, Year" :false
	 * 
	 */
	public void testDate2() {
		String n =RecognisePatterns.matchDate(null);
		
		assertTrue(n==null);
	}
	
	@Test
	/**
	 * Tests a Date showing the wrong format 
	 * the Month must be described by the 3  first letters of its name  being the first in uppercase and a '.'at the end: true 
	 * the day must be represented by an integer from 0-31 or 0-29 or 0-30 depending on the month:true 
	 * year must be represented by integers like XXXX:false
	 * the date must follow a representation like "Month Day, Year" :true
	 * 
	 */
	public void testDate3() {
		String n =RecognisePatterns.matchDate("The subject LabP was added to the Undergraduate Programme in Computer Science Engineering on Jun. two, 2019.");
		
		assertTrue(n==null);
	}
	
	@Test
	/**
	 * Tests a Date showing the wrong format 
	 * the Month must be described by the 3  first letters of its name  being the first in uppercase and a '.'at the end: false
	 * the day must be represented by an integer from 0-31 or 0-29 or 0-30 depending on the month:true 
	 * year must be represented by integers like XXXX:true
	 * the date must follow a representation like "Month Day, Year" :true
	 * 
	 */
	public void testDate4() {
		String n =RecognisePatterns.matchDate("My biggest holiday is on February. 14, It's called Valentine's Day.");
		
		assertTrue(n==null);
	}
}
