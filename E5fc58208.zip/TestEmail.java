import static org.junit.Assert.*;

import org.junit.Test;

/**
*
* JUnit Tests for the method isValidStudentEmail of the class RecognisePatterns
*
* Characteristic number 1
* Description: the email starts with the lower-case sequence 'fc'
* Regions: true or false 
*
* Characteristic number 2
* Description: the email contains 5 digits
* Regions: true or false 
*
* Characteristic number 3
* Description: the email ends with the lower-case sequence '@alunos.fc.ul.pt'
* Regions: true  or false 
*
* Total number of viable combinations: 8
*
* @author Maria Rocha fc58208
*
*/

public class TestEmail {

	@Test
	/**
	 * Test an email showing the right format
	 *   starts with the lower-case sequence 'fc': true
	 *   contains 5 digits : true
	 *   ends with the sequence '@alunos.fc.ul.pt': true
	 */
	public void testIsValidStudentEmail1 () {	
		assertTrue(RecognisePatterns.isValidStudentEmail("fc12345@alunos.fc.ul.pt"));
	}

	@Test
	/**
	 * Test an email with the wrong number of digits
	 *   starts with the lower-case sequence 'fc': true
	 *   contains 5 digits : false
	 *   ends with the lower-case sequence '@alunos.fc.ul.pt': true
	 */
	public void testIsValidStudentEmail3 () {	
		assertFalse(RecognisePatterns.isValidStudentEmail ("fc1234@alunos.fc.ul.pt"));
	}
	

	@Test
	/**
	 * Test an email with the wrong lower case sequence as a start
	 *   starts with the lower-case sequence 'fc': false
	 *   contains 5 digits : true
	 *   ends with the lower-case sequence '@alunos.fc.ul.pt': true
	 */
	public void testIsValidStudentEmail2 () {	
		assertFalse(RecognisePatterns.isValidStudentEmail ("nte1234@alunos.fc.ul.pt"));
	}
	
	@Test
	/**
	 * Test an email with the the end lowercase sequence being wrong
	 *   starts with the lower-case sequence 'fc': true
	 *   contains 5 digits : true
	 *   ends with the lower-case sequence '@alunos.fc.ul.pt': false
	 */
	public void testIsValidStudentEmail4 () {	
		assertFalse(RecognisePatterns.isValidStudentEmail ("fc1234@alunos"));
	}
}
