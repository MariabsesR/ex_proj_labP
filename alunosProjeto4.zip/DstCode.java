/*
 * Enumerator representing codes of destination airports
 */
public enum DstCode {
	CPH, MXP, HEL, ORY, MUC, BUD, DUB, AMS, BCN, ZRH;
	
	
	/**
	 * Returns the enum constant that corresponds to value
	 * @param value the given name of the constant
	 * @return the constant whose name corresponds to (the uppercase version of) value
	 * 
	 */
	public static DstCode findByValue(String value) {
		String valueUp = value.toUpperCase();
		 
		return DstCode.valueOf(valueUp);
	}


}