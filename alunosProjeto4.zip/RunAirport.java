import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class is meant to be used by students to test their solution to Project4
 * of LabP
 *
 * @author LabP team
 *
 */
public class RunAirport {
	
	public static void main (String[] args) throws FileNotFoundException {

		System.out.println("Generation of an airport and loading of the bookings...");
		
		Airport humbertoDelgado = new Airport("Humberto Delgado");
		
		// Load some flights for the created airport
		humbertoDelgado.loadFlights("airportFlights.txt");
		

		// Loading the booking requests into the airport's queue
		Scanner bookingsReader = new Scanner(new File("bookings.txt"));
		
		while (bookingsReader.hasNextLine()) {
			humbertoDelgado.loadBooking(bookingsReader.nextLine());
		}
		
		bookingsReader.close();

		System.out.println("Asking the airport to process the loaded bookings...");
		// Ask the airport to distribute the bookings among the available airlines' flights
		humbertoDelgado.processBookings();
		
		// Print a report about the distribution of the bookings
		System.out.println();
		System.out.println(humbertoDelgado.toString());
		
	}
}
