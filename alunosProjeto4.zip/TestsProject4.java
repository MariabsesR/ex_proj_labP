import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

/**
* JUnit Tests for project4 about FIFO queues
*
* @author LabP team
*
*/
public class TestsProject4 {
	
    @Test
    /*
     * Meant to test the methods bookSeats and VerifySchedule of the class Flight
     */
    public void testFlight () {
    	
    	int freeSeats = 20, seatsToBook = 7, expectedFreeSeats = 13;
   
    	
    	// *** Assessing seats are booked correctly through the method bookSeats ***//
    	Flight myFlight = new Flight(DstCode.AMS, LocalTime.now(), freeSeats);
    	
    	myFlight.bookSeats(seatsToBook);

        assertTrue(myFlight.getNumOfSeats() == expectedFreeSeats);
    	// ************************************************************************//
        
        // *** Assessing bookings are answered correctly according to the number of free seats available on a certain flight ****//
    	FlightBooking goodSchedule = new FlightBooking(DstCode.AMS, LocalTime.now().minusHours(2),5,false);
    	
    	assertTrue(myFlight.verifySchedule(goodSchedule));
    	
    	FlightBooking badSchedule = new FlightBooking(DstCode.BUD, LocalTime.now().plusHours(2),20,false);
    	
    	assertFalse(myFlight.verifySchedule(badSchedule));
    	// *********************************************************************************************************************//
    	
    }
    
    /*
     * Meant to test the method addFlight of the class AirlineCompany
     */
    @Test
    public void testAddFlight () {
    	
    	AirlineCompany airline = new AirlineCompany("AirMalta");
    	int freeSeats = 50;
    	
		airline.addFlight(DstCode.AMS, LocalTime.now(), freeSeats);
    	
    	assertTrue(airline.getNumFlights() == 1);
    	
    }

    /*
     * Meant to test the method loadBookings of the class AirlineCompany
     */
    @Test
    public void testLoadBookings () {
       	
       	Airport humbertoDelgado = new Airport("Humberto Delgado");
    	try {
			humbertoDelgado.loadFlights("airportFlights.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	
    
    	// *** we get flights which have been loaded and we construct valid FlightBooking requests starting from that information ***
    	List<AirlineCompany> airlines = humbertoDelgado.getAirlines();
    	ArrayList<Flight> flights = airlines.get(0).getFlights();
    	ArrayList<String> rawBookings = new ArrayList<String>();
    	
    	for (Flight flight: flights) {
    		
        	DstCode dstCode = flight.getDestinationCode();
        	LocalTime time = flight.getTime();
        	int seats = flight.getNumOfSeats();
    		
        	// store valid FlightBooking data
        	rawBookings.add(dstCode + " " + time.toString() + " " + seats);
    	}
    	// *****************************************************************************************************************************
    	
    	// From the data collected through the flights in the previous step, we now create valid FlightBookings
    	int rdNumOfValidBookings = airlines.get(0).getNumFlights();
    	
    	List<FlightBooking> dayBookings = new LinkedList<FlightBooking>();
    	
    	for(int i = 0 ; i < rdNumOfValidBookings ; i++) {
    		
    		String[] bookingTokens = rawBookings.get(i).split(" ");
    		DstCode dstCode = DstCode.findByValue(bookingTokens[0]);
    		dayBookings.add(new FlightBooking(dstCode, LocalTime.parse(bookingTokens[1]), Integer.parseInt(bookingTokens[2]), false));
    	
    	}
    	
    	airlines.get(0).loadBookings(dayBookings);
    	
    	// *****************************************************************************************************************************    	
    	
    	
    	// If the method loadBookings were working as expected, all the bookings generated above should have been served by the airline, 
    	// this means that the company will now have in his booking list rdNumOfValidBookings FlightBookings and that those objects will 
    	// be marked as confirmed/booked
    	List<FlightBooking> gotBookings = airlines.get(0).getBookings();
    	
    	assert(rdNumOfValidBookings == gotBookings.size());
    	
    	boolean bookingFound = false;
    	
    	while(!gotBookings.isEmpty()) {
    		
    		FlightBooking retrieved = gotBookings.remove(0);
    		
    		assertTrue(retrieved.isBooked());
    		
    		String rawBookingString = retrieved.getDestinationCode() + " " + retrieved.getMinimalStartingTime().toString() + " " + retrieved.getNumberOfSeats();
    		
    		for(int i = 0 ; i < rawBookings.size() & !bookingFound ; i++) {
        		
    			bookingFound = rawBookings.get(i).equalsIgnoreCase(rawBookingString);

        	}
    		
    		
    		assertTrue(bookingFound);
    	}
    	// *****************************************************************************************************************************
    	
    }

    /*
     * Meant to test the method loadBooking of the Airport class
     */
    @Test
    public void testLoadSingleBooking () {
    	
		Airport humbertoDelgado = new Airport("Humberto Delgado");
		
    	String rawBookingStr = "CPH 23:15 9";
    	humbertoDelgado.loadBooking(rawBookingStr);
    	
    	assertTrue(humbertoDelgado.getDayBookings().size() == 1);
    	
    	String expectedString = "Flight to CPH - time: 23:15 - seats: 9";
    	
    	assertTrue(humbertoDelgado.toString().contains(expectedString));
    	
    }

    
    /*
     * Meant to test the method sortBookingQueues of the Airport class
     */
    @Test
    public void testSortBookingQueues () {
       	
       	Airport humbertoDelgado = new Airport("Humberto Delgado");
    	try {
			humbertoDelgado.loadFlights("airportFlights.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	
    
    	// *** we get the flights which have been randomly created and we construct valid FlightBooking requests starting from those ***
    	List<AirlineCompany> airlines = humbertoDelgado.getAirlines();
    	ArrayList<Flight> flights = airlines.get(0).getFlights();
    	ArrayList<String> rawBookings = new ArrayList<String>();
    	
    	for (Flight flight: flights) {
    		
        	DstCode dstCode = flight.getDestinationCode();
        	LocalTime time = flight.getTime();
        	int seats = flight.getNumOfSeats();
    		
        	rawBookings.add(dstCode + " " + time.toString() + " " + seats);
    	}
    	// *****************************************************************************************************************************
    	
    	// From the data collected through the flights in the previous step, we now create valid FlightBookings
    	// and we load those into the airport
    	int rdNumOfValidBookings = airlines.get(0).getNumFlights();
    	  	
    	for(int i = 0 ; i < rdNumOfValidBookings ; i++) {
    		
    		humbertoDelgado.loadBooking(rawBookings.get(i));
    	
    	}
    	
    	// we ask the airport to process the loaded requests
    	humbertoDelgado.processBookings();
    	
    	// we expect the loaded requests have been correctly handled, meaning that the queue of requests to be served
    	// will be now empty....
    	List<FlightBooking> dBookings = humbertoDelgado.getDayBookings();
    	
    	assertTrue(dBookings.isEmpty());
    	
    	// ... while the queue of requests which have been successfully booked will contain the elements we have inserted in it
    	List<FlightBooking> reservedBookings = humbertoDelgado.getServedBookings();
    	
    	assertTrue(reservedBookings.size() == rdNumOfValidBookings);
    	
    	
    }
    

    
}

