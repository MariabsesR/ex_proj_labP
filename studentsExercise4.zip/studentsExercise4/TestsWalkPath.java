import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

import org.junit.jupiter.api.Test;

class TestsWalkPath {

	public static final String EOL = System.getProperty("line.separator");

	@Test
	void test2x2Horizontal() {
		
		Random gen = new Random(2);
		Obstacle[][] square = new Obstacle[2][2];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "F:-10 H:-5 S:-20 S:-20";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test2x2Vertical() {
		
		Random gen = new Random(2);
		Obstacle[][] square = new Obstacle[2][2];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		land.setPathType(PathType.VERTICAL_SNAIL);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "S:-20 H:-5 F:-10 S:-20";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test2x2Spiral() {
		
		Random gen = new Random(2);
		Obstacle[][] square = new Obstacle[2][2];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		land.setPathType(PathType.SPIRAL);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "F:-10 S:-20 S:-20 H:-5";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test4x4Horizontal() {
		
		Random gen = new Random(1);
		Obstacle[][] square = new Obstacle[4][4];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "S:-20 S:-20 H:-5 _:1 H:-5 _:1 T:300 T:300 E:-5 T:300 "
				  + "F:-10 F:-10 L:-1 L:-1 F:-10 F:-10";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test4x4Vertical() {
		
		Random gen = new Random(1);
		Obstacle[][] square = new Obstacle[4][4];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		land.setPathType(PathType.VERTICAL_SNAIL);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "L:-1 F:-10 H:-5 _:1 H:-5 _:1 F:-10 L:-1 F:-10 T:300 T:300 "
				  + "S:-20 S:-20 T:300 E:-5 F:-10";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test4x4Spiral() {
		
		Random gen = new Random(1);
		Obstacle[][] square = new Obstacle[4][4];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		land.setPathType(PathType.SPIRAL);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "T:300 T:300 F:-10 _:1 H:-5 S:-20 S:-20 T:300 E:-5 F:-10 "
				  + "F:-10 L:-1 L:-1 F:-10 H:-5 _:1";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test3x6Horizontal() {
		
		Random gen = new Random(0);
		Building[][] square = new Building[3][6];
		RunWalkPath.fillMatrix (square, Building.values(), gen);
		Landscape<Building> land = new Landscape<Building>(square);
		
		StringBuilder sb = new StringBuilder();
		for(Building bld : land) {
			sb.append(bld.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "S:20 C:10 K:20 C:10 T:500 C:10 T:500 P:-10 C:10 S:20 F:10 "
				  + "T:500 C:10 H:5 T:500 P:-10 K:20 S:20";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test3x6Vertical() {
		
		Random gen = new Random(0);
		Building[][] square = new Building[3][6];
		RunWalkPath.fillMatrix (square, Building.values(), gen);
		Landscape<Building> land = new Landscape<Building>(square);
		land.setPathType(PathType.VERTICAL_SNAIL);
		
		StringBuilder sb = new StringBuilder();
		for(Building bld : land) {
			sb.append(bld.toString() + " ");
		}
		String obtained = sb.toString().trim();
		
		String expected = 
				  "S:20 T:500 C:10 T:500 P:-10 K:20 P:-10 C:10 C:10 K:20 "
				  + "S:20 T:500 H:5 F:10 C:10 S:20 T:500 C:10";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test3x6Spiral() {

		// It should give the same order as Horizontal because the landscape
		// is not a square		
		Random gen = new Random(0);
		Building[][] square = new Building[3][6];
		RunWalkPath.fillMatrix (square, Building.values(), gen);
		Landscape<Building> land = new Landscape<Building>(square);
		land.setPathType(PathType.SPIRAL);
		
		StringBuilder sb = new StringBuilder();
		for(Building bld : land) {
			sb.append(bld.toString() + " ");
		}
		String obtained = sb.toString().trim();
 
		String expected = 
				"S:20 C:10 K:20 C:10 T:500 C:10 T:500 P:-10 C:10 S:20 F:10 "
						  + "T:500 C:10 H:5 T:500 P:-10 K:20 S:20";
		
		assertEquals(expected, obtained);
	}

	@Test
	void test5x5Spiral() {
		
		Random gen = new Random(1);
		Obstacle[][] square = new Obstacle[5][5];
		RunWalkPath.fillMatrix (square, Obstacle.values(), gen);
		Landscape<Obstacle> land = new Landscape<Obstacle>(square);
		land.setPathType(PathType.SPIRAL);
		
		StringBuilder sb = new StringBuilder();
		for(Obstacle obs : land) {
			sb.append(obs.toString() + " ");
		}
		String obtained = sb.toString().trim();

		String expected = 
				  "F:-10 _:1 _:1 F:-10 E:-5 H:-5 _:1 F:-10 _:1 T:300 S:-20 "
				  + "E:-5 S:-20 F:-10 L:-1 T:300 T:300 _:1 H:-5 S:-20 S:-20 "
				  + "T:300 F:-10 L:-1 L:-1";
		
		assertEquals(expected, obtained);
	}

}
