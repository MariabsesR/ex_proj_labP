import java.util.Random;

/**
 * This class can be used to experiment creating and using instances of
 * the Landscape class
 *  
 * @author LabP
 *
 */
public class RunWalkPath {

	/**
	 * Creates and fills two matrices and use them to create two landscapes.
	 * Iterates through the landscapes using different iterators (by means
	 * of the for-each instruction):
	 * - first the iterator that goes through the landscape using an 
	 * Horizontal Snail path type (the default for landscapes)
	 * - then using a Vertical Snail path type
	 * - finally using an Spiral path type 
	 * 
	 * @param args Not used
	 *  
	 */
	public static void main(String[] args) {

		Random generator = new Random(1);

		// Creates two matrices and fills them with objects from given
		// enum types
		Obstacle[][] square1 = new Obstacle[4][5];
		fillMatrix (square1, Obstacle.values(), generator);

		Building[][] square2 = new Building[5][5];
		fillMatrix (square2, Building.values(), generator);

		// Creates two landscapes with the matrices, and prints their
		// textual representation in the standard output
		Landscape<Obstacle> land1 = new Landscape<Obstacle>(square1);
		Landscape<Building> land2 = new Landscape<Building>(square2);

		System.out.println("=========== Obstacle Land =============");
		System.out.println(land1.toString());

		System.out.println("=========== Building Land =============");
		System.out.println(land2.toString());

		// Iterates through the first landscape using an Horizontal Snail  
		// path direction (the default one) and prints the textual 
		// representation of the objects obtained 
		System.out.println("====== Horizontal Snail through Obstacles ========");
		for(Obstacle obs : land1) {
			System.out.print(obs.toString() + " ");
		}
		System.out.println();

		// Sets Vertical Snail as the new path type direction through the
		// landscape objects 
		land1.setPathType(PathType.VERTICAL_SNAIL); 
		
		// Iterates through the landscape and prints the textual representation
		// of the objects obtained
		System.out.println("====== Vertical Snail through Obstacles ========");	
		for(Obstacle obs : land1) {
			System.out.print(obs.toString() + " ");
		}
		System.out.println();

		// Sets Spiral as the path type direction to be used to iterate through
		// second landscape 
		land2.setPathType(PathType.SPIRAL);

		// Iterates through the landscape and prints the textual representation
		// of the objects obtained
		System.out.println("====== Spiral through Buildings ========");
		for(Building bld : land2) {
			System.out.print(bld.toString() + " ");
		}
		System.out.println();

	}

	/**
	 * Fill a matrix with randomly generated values of an enum type
	 *  
	 * This is a generic method (you will only talk about these kind of
	 * methods in Desenvolvimento Centrado em Objetos course
	 * 
	 * This method is also used by the TestsWalkPath class
	 * 
	 * @param square The matrix to be filled
	 * @param values The values that can be used in the filling
	 * @param gen The random generator
	 * @requires square != null && values != null && gen != null
	 */
	static <T>  void fillMatrix (T[][] square, T[] values, Random gen){
		for(int i = 0 ; i < square.length ; i++) {
			for (int j = 0 ; j < square[0].length ; j++) {
				square[i][j] = values[gen.nextInt(values.length)];
			}
		}
	}
}
