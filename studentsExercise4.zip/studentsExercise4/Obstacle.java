
public enum Obstacle {
	 EMPTY ("_:1"),
     HOLE ("H:-5"), 
     LAKE ("L:-1"),
     ENEMY ("E:-5"), 
     SPIKE_TREE ("S:-20"), 
     FIRE ("F:-10"),
	 TREASURE("T:300");
	
	String letterValue;
	Obstacle(String text){
		this.letterValue = text;
	}
	
	public String toString() {
		return letterValue;
	}

}
