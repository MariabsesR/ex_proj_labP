
public enum Building {
	 EMPTY ("_:1"),
     HOUSE ("H:5"), 
     CHURCH ("C:10"),
     FACTORY ("F:10"), 
     KINDEGARDEN ("K:20"), 
     PUB ("P:-10"), 
     STORE ("S:20"), 
     COLLEGE ("C:10"),
 	 TREASURE ("T:500");
	
	String letterValue;
	Building(String text){
		this.letterValue = text;
	}
	
	public String toString() {
		return letterValue;
	}

}
