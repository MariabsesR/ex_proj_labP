import java.time.LocalDate;
import java.util.HashMap;

/**
 * Class that represents instances of a Contact Manager
 * 
 * @author Maria Rocha fc58208
 *
 */
public class ContactManager {

	private String owner;
	private StringBuilder logOfCreatedContacts;
	private HashMap<String, Contact> nameContacts;
	private HashMap<String, Contact> numberContacts;

	/**
	 * Receives the name of the manager which owns the contacts and initializes an
	 * instance of Contact Manager
	 * 
	 * @param managerName
	 * @requires{@code managerName!=null}
	 */
	public ContactManager(String managerName) {
		owner = managerName;
		nameContacts = new HashMap<String, Contact>();
		numberContacts = new HashMap<String, Contact>();
		logOfCreatedContacts = new StringBuilder();
	}

	/**
	 * Creates or finds and returns a contact with the given name, if the contact
	 * has to be created all of his parameters will be null except the name
	 * 
	 * @param contactName name of the contact we searching
	 * @requires{@code contactName!=null}
	 * @return either contact that already existed or a new one
	 */

	public Contact contactByName(String contactName) {
		if (nameContacts.containsKey(contactName)) {
			return nameContacts.get(contactName);
		} else {
			// make new contact and add the information to the log
			String EOL = System.getProperty("line.separator");
			Contact makeNew = new Contact(contactName, null, null, null, null);
			nameContacts.put(contactName, makeNew);
			logOfCreatedContacts.append("New contact created: " + contactName + EOL);
			return makeNew.copy();
		}
	}

	/**
	 * Returns the name of the manager of the current ContactManager
	 * 
	 * @return name of manager
	 */
	public String getManagerName() {

		return owner;
	}

	/**
	 * Returns the name associated to this phone number, if the phone number doesnt
	 * exist it returns null
	 * 
	 * @param string phone number
	 * @requires{@code string!=null}
	 * @return name associated to phone number
	 */
	public String getPhoneFromName(String string) {
		if (!nameContacts.isEmpty() && nameContacts.containsKey(string))
			return nameContacts.get(string).getPhone();
		else
			return null;

	}

	/**
	 * Creates or finds and returns a contact with the given phone Number, if the
	 * contact has to be created all of his parameters will be null except for the
	 * phone number
	 * 
	 * @param phoneNumber phone number of the contact
	 * @return new contact or existing contact associated with the given phone
	 *         number
	 * @requires{@code phoneNumber!=null}
	 */
	public Contact contactByPhone(String phoneNumber) {
		if (numberContacts.containsKey(phoneNumber)) {
			return numberContacts.get(phoneNumber);
		} else {
			String EOL = System.getProperty("line.separator");
			Contact makeNew = new Contact(null, phoneNumber, null, null, null);
			numberContacts.put(phoneNumber, makeNew);
			logOfCreatedContacts.append("New contact created: " + phoneNumber + EOL);
			return makeNew.copy();
		}
	}

	/**
	 * Receives a key which may be a phone number or a name of a contact already
	 * existing and a new name, if the contact with that certain key doesnt exist
	 * returns false, if there is a contact in the nameContacts map with the given
	 * newName, it shall also return false. If none of this happens it will return
	 * true and change the name of the contact
	 * 
	 * @param contactKey
	 * @param newName
	 * @return
	 */
	public boolean editContactName(String contactKey, String newName) {
		Contact contactToEdit;

		// nameContacts map has the contact key and doesnt have the new name
		if (nameContacts.containsKey(contactKey) && !nameContacts.containsKey(newName)) {
			contactToEdit = nameContacts.get(contactKey);
			// change name in the name map
			contactToEdit.setName(newName);
			// removes the old contact with the old name and makes it a new contact with a
			// new key
			nameContacts.remove(contactKey);
			nameContacts.put(newName, contactToEdit);

			return true;
		} else {
			if (numberContacts.containsKey(contactKey)&& !nameContacts.containsKey(newName)) {
				contactToEdit = numberContacts.get(contactKey);
				// if the given key was a phone number and the nameContacts
				// map doesnt contains that edit, hence this contacts has no name,
				// adds it to the map
				contactToEdit.setName(newName);
				if (!nameContacts.containsValue(contactToEdit)) {
					nameContacts.put(newName, contactToEdit);
				} else {

					// removes the old contact with the old name and makes it a new contact with a
					// new key
					nameContacts.remove(contactToEdit.getName());
					contactToEdit.setName(newName);
					nameContacts.put(newName, contactToEdit);
				}
				return true;
			}
			return false;
		}
	}

	/**
	 * Receives the key to a contact and a new phone number and either changes an
	 * existing phone number to the new given or simply adds it to the list of phone
	 * numbers of the contact. if the oldPhone is null it shall only add the new
	 * phone number. The method will return false if there isnt a contact with the
	 * given key or if there is already a number in the numberContacts map with the
	 * new phone Number
	 * 
	 * @param contactKey key of the contact
	 * @param newPhone   new phone number
	 * @param oldPhone   old phone number or null
	 * @requires oldPhone and newPhone are a strings that only contain Integers
	 * @return true if the key exists, false if it doesnt
	 */

	public boolean editContactPhone(String contactKey, String newPhone, String oldPhone) {

		Contact contactToEdit;

		// if there if a name with the given key
		if (nameContacts.containsKey(contactKey) && !numberContacts.keySet().contains(newPhone)) {
			contactToEdit = nameContacts.get(contactKey);

			if (oldPhone != null) {

				// since the number has been changed the entry on numberContacts
				// has to be changed
				// removes and adds a new entry to the numberContact map
				numberContacts.remove(oldPhone);
				contactToEdit.upDatePhone(oldPhone, newPhone);
				numberContacts.put(newPhone, contactToEdit);

			} else {
				
				// since we updated the lsit of phones we have to make
				// a new entry on numbersContact map with the new key set
				contactToEdit.getPhones().add(newPhone);
				numberContacts.put(newPhone, contactToEdit);

			}

			return true;
		} else {
			// if the numberContact map doesnt contain the new number and none of the keys
			// of
			// the numberContacts map contain the new phone
			if (numberContacts.containsKey(contactKey) && !numberContacts.keySet().contains(newPhone)) {
				// if the oldphone isnt null it shall update the oldphone to the new number
				if (oldPhone != null) {
					contactToEdit = numberContacts.get(contactKey);
					// updates phone number
					// since we updated the lsit of phones we have to make
					// a new entry on numbersContact map with the new key set
					numberContacts.remove(oldPhone);
					contactToEdit.upDatePhone(oldPhone, newPhone);
					numberContacts.put(newPhone, contactToEdit);
					// if the phone number has a name searches it on the nameContact map to also
					// update the number there
					if (contactToEdit.getName() != null) {
						nameContacts.get(contactToEdit.getName()).upDatePhone(oldPhone, newPhone);
					}
					return true;
				} else {
					// adds the new phone number to both the nameContacts map and the numberContacts
					// map
					contactToEdit = nameContacts.get(contactKey);
					// since we updated the list of phones we have to make
					// a new entry on numbersContact map with the new key set
					
					contactToEdit.addPhone(newPhone);
					numberContacts.put(newPhone, contactToEdit);
					// if the phone number has a name searches it on the nameContact map to also
					// update the number there
					if (contactToEdit.getName() != null) {
						nameContacts.get(contactToEdit.getName()).addPhone(newPhone);

					}
				}
				return true;
			}
			return false;
		}

	}

	/**
	 * Receives a key and checks if it exists in any of the maps, and gives
	 * additional values that we gotta add or edit to the contact with the given
	 * key, if there isnt a contact with the given key it returns false, any
	 * parameters with the null value wont be changed,
	 * 
	 * @param contactKey key of the contact
	 * @param address    new address or null
	 * @param email      new email or null
	 * @param date       new birth date or null
	 * @requires date!= null || email!= null || address != null ))
	 * @return given key is associated to a contact contact exist
	 */

	public boolean editContactOptionalInfo(String contactKey, String address, String email, LocalDate date) {

		if (numberContacts.containsKey(contactKey)) { 
			Contact contactToEdit = numberContacts.get(contactKey);

			if (address != null)
				contactToEdit.setAddress(address);

			if (email != null)
				contactToEdit.setEmail(email);

			if (date != null)
				contactToEdit.setDate(date);

			return true;
		}

		if (nameContacts.containsKey(contactKey)){
			Contact contactToEdit = nameContacts.get(contactKey);

			if (address != null)
				contactToEdit.setAddress(address);

			if (email != null)
				contactToEdit.setEmail(email);

			if (date != null)
				contactToEdit.setDate(date);

			return true;
		}

		return false;

	}

	/**
	 * Checks the phone number to see if there is any phone Number that has a name
	 * on the numberContacts Map, if the contact doesnt exist or it doesnt have a
	 * name it shall return false
	 * 
	 * @param phone phone number to search
	 * @return name of the contact or null
	 */
	public String getNameFromPhone(String phone) {
		if (numberContacts.containsKey(phone)) {
			return numberContacts.get(phone).getName();
		}
		return null;

	}

	/**
	 * Returns a visual representation of the contact associated with the contact
	 * key, it will return null if there isnt any contact with that key
	 * 
	 * @param contactKey
	 * @return
	 */

	public String getInfo(String contactKey) {
		if (numberContacts.containsKey(contactKey))
			return numberContacts.get(contactKey).toString();

		if (nameContacts.containsKey(contactKey))
			return nameContacts.get(contactKey).toString();

		return null;
	}

	/**
	 * Receives a key associated with a contact and removes it from both the
	 * numebrsContact map and the nameContact map
	 * 
	 * @param contactKey key associated with contact we wanna remove
	 */
	public void remove(String contactKey) {
		if (nameContacts.containsKey(contactKey)) {
			Contact contactToEdit = nameContacts.get(contactKey);

			for(int i =0;i<contactToEdit.getPhones().size();i++) {
				numberContacts.remove(contactToEdit.getPhones().get(i));
			}
		
			nameContacts.remove(contactKey);
		}
		if (numberContacts.containsKey(contactKey)) {
			Contact contactToEdit = numberContacts.get(contactKey);
			for(int i =0;i<contactToEdit.getPhones().size();i++) {
				numberContacts.remove(contactToEdit.getPhones().get(i));
			}

		
			nameContacts.remove(contactToEdit.getName());
		}
	}

	/**
	 * Returns the log of all the created contacts
	 * 
	 * @return log of created contacts
	 */
	public String getLog() {

		return logOfCreatedContacts.toString();
	}

}
