import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that represents instances of a Contact
 * 
 * @author Maria Rocha fc58208
 *
 */
public class Contact {

	private String name;
	private List<String> phoneNumbers;
	private String email;
	private String adress;
	private LocalDate dateOfBirth;

	/**
	 * Constructs a new instance of Contact with the given parameters, the contact
	 * must have at least name or a phone number to be created, as long as name or
	 * phone are not null, the remaining parameters may be null
	 * 
	 * @param name        contact name
	 * @param phoneNumber contact knows phone numbers
	 * @param adress      address of contact
	 * @param email       email of contact
	 * @param dateOfBirth date of Birth of contact
	 */
	public Contact(String name, String phoneNumber, String adress, String email, LocalDate dateOfBirth) {
		// to construct something must have at least name or phone number
		if (name != null || phoneNumber != null) {
			// set atributes
			this.name = name;
			this.adress = adress;
			this.email = email;
			this.dateOfBirth = dateOfBirth;
			phoneNumbers = new ArrayList<String>();

			// add all the existing phone numbers given
			if (phoneNumber != null) {
				String[] allPhones = phoneNumber.split(", ");
				for (String phone : allPhones) {
					phoneNumbers.add(phone);
				}
			}

		}
	}

	/**
	 * Returns the first phone of all the ones in the current contact
	 * 
	 * @return first phone of the given contact
	 */

	public String getPhone() {
		if (!phoneNumbers.isEmpty())
			return phoneNumbers.get(0);
		else
			return null;
	}

	/**
	 * Gets email
	 * 
	 * @return email of Contact
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Returns the address
	 * 
	 * @return address of contact
	 */
	public String getAddress() {
		return adress;
	}

	/**
	 * Returns birth date of contact
	 * 
	 * @return date of birth of contact
	 */
	public LocalDate getDate() {
		return dateOfBirth;
	}

	/**
	 * Changes the name of the current contact
	 * 
	 * @param string new name of the current contact
	 */
	public void setName(String string) {
		name = string;

	}

	/**
	 * Returns name of current Contact
	 * 
	 * @return name of current contact
	 */
	public String getName() {
		return name;
	}

	/**
	 * Adds a new phone to he list of phones of the current contact
	 * 
	 * @param string phone number to add
	 */
	public void addPhone(String string) {
		phoneNumbers.add(string);

	}

	/**
	 * Changes the email of the current Contact
	 * 
	 * @param object new email
	 */
	public void setEmail(String object) {
		email = object;

	}

	/**
	 * Changes the current adress of the Contact
	 * 
	 * @param object new adress
	 */
	public void setAddress(String object) {
		adress = object;

	}

	/**
	 * Changes the date of birth of the current contact
	 * 
	 * @param object new date of Birth
	 */
	public void setDate(LocalDate object) {
		dateOfBirth = object;

	}

	/**
	 * Returns the current list of phones
	 * 
	 * @return list of phones of the current contact
	 */
	public List<String> getPhones() {

		return phoneNumbers;
	}

	/**
	 * Removes a number from the list and adds another
	 * 
	 * @param remove number to remove
	 * @param add    number to add
	 * @requires{@code phoneNumbers.contains(remove)}
	 */
	public void upDatePhone(String remove, String add) {
	if(phoneNumbers.contains(remove)) {	
		int index = phoneNumbers.indexOf(remove);

		phoneNumbers.set(index, add);
	}

	}

	/**
	 * Returns a visual representation of Contact
	 */
	@Override
	public String toString() {
		String contact;
		if (phoneNumbers.isEmpty())
			contact = "None";
		else {
			StringBuilder test = new StringBuilder();
			for (int i = 0; i < phoneNumbers.size(); i++) {
				test.append(phoneNumbers.get(i).toString() + ",");

			}
			contact = test.toString();
		}
		String Birthday = "None";
		String nameOfContact = name;
		String contactEmail = email;
		String adress = this.adress;
		String EOL = System.getProperty("line.separator");

		if (dateOfBirth != null)
			Birthday = dateOfBirth.toString();
		if (name == null)
			nameOfContact = "None";
		if (this.adress == null)
			adress = "None";
		if (email == null)
			contactEmail = "None";

		String expected = "Contact: " + EOL + "name = " + nameOfContact + EOL + "phones = " + contact + EOL
				+ "address = " + adress + EOL + "email = " + contactEmail + EOL + "date = " + Birthday + EOL;

		return expected;

	}

	/**
	 * 
	 * Makes and returns a deep copy of the current Contact
	 * 
	 * @return
	 * 
	 */
	public Contact copy() {

		StringBuilder make = new StringBuilder();
		String s;
		for (int i = 0; i < getPhones().size(); i++) {
			make.append(getPhones().get(i) + ", ");
		}
		s=make.toString();
        if(make.isEmpty())s=null;
		Contact copy = new Contact(name, s, adress, email, dateOfBirth);
		return copy;
	}
}
