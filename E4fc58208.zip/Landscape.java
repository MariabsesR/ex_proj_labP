import java.util.Iterator;
/**
 * Class that represents a Landscape occupied with Buildings and Obstacles
 * 
 * @author Maria Rocha fc58208
 * @param <E>  type of objects of Landscape
 */

public class Landscape<E> implements Iterable<E> {

	private PathType iteratorType;
	private E[][] map;

	/**
	 * Creates an instance of Landscape with an horizontalSnail iterator Type
	 * 
	 * @param square type of landscape to create
	 * @requires square is a matrix and {@code square!=null}
	 */

	public Landscape(E[][] square) {
		map = square;
		iteratorType = PathType.HORIZONTAL_SNAIL;
	}

	/**
	 * Changes the pathType to the one given, if the pathType is Spiral but
	 * map.length != map[0].length then it will assume a horrizontalSnail PathType
	 * 
	 * @param verticalSnail the pathType the landscape shall have
	 */

	public void setPathType(PathType verticalSnail) {
		// if the pathtype is spiral checks if it has the same amount of columns and
		// lines
		// if it has keeps it spiral if not assumes horizontal Snail
		if (verticalSnail == PathType.SPIRAL) {
			if (map.length == map[0].length) {
				iteratorType = PathType.SPIRAL;
			} else
				iteratorType = PathType.HORIZONTAL_SNAIL;
		} else {
			// if the given pathtype is not spiral we changes the landscape PathType
			iteratorType = verticalSnail;
		}

	}

	/**
	 * Constructs iterator depending on the current PathType of the landscape;
	 * 
	 * 
	 */

	@Override
	public Iterator<E> iterator() {

		switch (iteratorType) {
		case HORIZONTAL_SNAIL: {
			return new MapIteradorHorizontalSnail();
		}
		case SPIRAL: {
			return new MapIteradorSpiral();
		}
		case VERTICAL_SNAIL: {
			return new MapIteradorVerticallSnail();
		}
		}
		return null;

	}

	/**
	 * Gives a visual representation of the Landscape
	 */
	public String toString() {

		StringBuilder instructions = new StringBuilder();
		String EOL = System.getProperty("line.separator");
		// creates our board
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map[0].length; j++) {

				instructions.append("|");
				instructions.append(" " + map[i][j].toString().substring(0, 1) + " ");

			}
			// when each line is over append the lines number
			instructions.append("|");
			instructions.append(" " + i);
			instructions.append(EOL);
		}
		// change line
		instructions.append("" + EOL);
		// add the numbers of each columns
		for (int k = 0; k < map[0].length; k++) {
			if (k == 0)
				instructions.append("|");
				instructions.append(" " + k + " |");
			

		}
		// change line, create empty line
		instructions.append(" " + EOL);
		instructions.append("" + EOL);
		return instructions.toString();
	}

	/**
	 * 
	 * Class that represents an iterator of LandScape with a PathType of
	 * HorizontalSnail
	 *
	 */

	public class MapIteradorHorizontalSnail implements Iterator<E> {

		int currentLine;
		int currentColumn;
		int counter;

		/**
		 * Constructs an iterator of the type HprizontalSnail
		 */

		public MapIteradorHorizontalSnail() {
			currentLine = 0;
			currentColumn = 0;
			counter = 0;
		}

		/**
		 * Checks if according to the PathType there is a place in Landscape where to go
		 * next
		 */

		@Override
		public boolean hasNext() {
			if (currentLine % 2 == 0) {
				// if the line is pair then it must end of the last columns
				return currentLine < map.length && currentColumn < map[0].length;
			} else {
				// if the line is pair then it must end in the first columns
				return currentLine < map.length && currentColumn > -1;
			}
		}

		/**
		 * Gets the next spot in Landscape according to the pathType
		 */
		@Override
		public E next() {

			int coluna = currentColumn;
			int linha = currentLine;
			// if its in the end of beginning of the columns then must add a line
			if ((currentColumn == map[0].length - 1 && currentLine % 2 == 0)
					|| (currentColumn == 0 && currentLine % 2 != 0)) {
				currentLine++;
			} else {
				// if not must go through all the columns
				if (currentLine % 2 == 0) {
					currentColumn++;
				} else {
					currentColumn--;
				}
			}

			return map[linha][coluna];
		}

	}

	/**
	 * 
	 * Class that represents an iterator of LandScape with a PathType of
	 * VerticalSnail
	 *
	 */
	public class MapIteradorVerticallSnail implements Iterator<E> {

		int currentLine;
		int currentColumn;
		int counter;

		/**
		 * Constructs an iterator of the type VerticalSnail
		 */

		public MapIteradorVerticallSnail() {
			currentLine = map.length - 1;
			currentColumn = map[0].length - 1;
			counter = 0;
		}

		/**
		 * Checks if according to the PathType there is a place in Landscape where to go
		 * next
		 */

		@Override
		public boolean hasNext() {

			if (counter % 2 == 0) {
				// either ends on the 0|0 index
				return currentLine > -1 && currentColumn > -1;
			} else
				// or ends on the first column and on the last line
				return currentLine < map.length && currentColumn > -1;

		}

		/**
		 * Gets the next spot in Landscape according to the pathType
		 */
		@Override
		public E next() {

			int coluna = currentColumn;
			int linha = currentLine;
			// if its on the last or first line it must change columns
			if ((currentLine == 0 && counter % 2 == 0) || (currentLine == map.length - 1 && counter % 2 != 0)) {
				currentColumn--;
				counter++;
			} else {
				// else it needs to change the columns depending on which line is it
				if (counter % 2 == 0) {
					currentLine--;
				} else {
					currentLine++;
				}
			}

			return map[linha][coluna];
		}

	}

	public class MapIteradorSpiral implements Iterator<E> {

		int currentLine;
		int currentColumn;
		int counter;
		int counterChangeDirection;
		int extracounter;
		int sideCounter;

		/**
		 * Constructs an iterator of the type VerticalSnail
		 */
		public MapIteradorSpiral() {

			sideCounter = 1;
			counter = 0;
			counterChangeDirection = 1;
			extracounter = 0;
			// if the size of the map is a pair then it must start in the upper left side
			// of the central cube of 2x2 of the map
			if (map.length % 2 == 0) {
				currentLine = (map.length / 2) - 1;
				currentColumn = (map[0].length / 2) - 1;

			} else {
				// else it will start in the middle of the map
				currentLine = (map.length / 2);
				currentColumn = (map[0].length / 2);

			}

		}

		/**
		 * Checks if according to the PathType there is a place in Landscape where to go
		 * next
		 */

		@Override
		public boolean hasNext() {

			if (extracounter % 2 != 0) {
				// this lines are the ones going up or down hence can only end when the line
				// aint correct
				return (currentLine > -1) && (currentLine < map[0].length);
			} else
				// this lines are going sideways hence only end when the column is too big
				return (currentColumn > -1) && (currentColumn < map.length);

		}

		/**
		 * Gets the next spot in Landscape according to the pathType
		 */
		@Override
		public E next() {

			int coluna = currentColumn;
			int linha = currentLine;

			// the side counter tells us which direction we are supposed to move
			if (sideCounter == 1)
				currentLine++;
			if (sideCounter == 2)
				currentColumn++;
			if (sideCounter == 3)
				currentLine--;
			if (sideCounter == 4)
				currentColumn--;

			counter++;
			// if counter ==changeDirection thats means we need to change the direction we
			// moving
			if (counter == counterChangeDirection) {
				// since lines are now in a different direction we need to up the side counter
				// and the extra counter
				extracounter++;
				sideCounter++;
                //if the side counter reaches it max then we restart it
				if (sideCounter == 5)
					sideCounter = 1;
				//restart the counter since we started a new direction
				counter = 0;
				//if its not the first time then the next moves must be done 1 more than before 
				if (sideCounter == 3 || (sideCounter == 1 && extracounter != 0))
					counterChangeDirection++;
			}

			return map[linha][coluna];
		}

	}

}
