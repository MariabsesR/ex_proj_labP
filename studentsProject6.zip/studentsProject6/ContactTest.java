import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;


public class ContactTest{

	
	@Test
	public void testGetName () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		assertEquals("nome", myContact.getName());
	}
	
	@Test
	public void testGetPhone () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		assertEquals("123456789", myContact.getPhone());
	}
	
	
	@Test
	public void testGetEmail () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		assertEquals("omeucontato@fc.ul.pt", myContact.getEmail());
	}
	
	@Test
	public void testGetAddress () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		assertEquals("Rua Sesamo", myContact.getAddress());
	}
	
	@Test
	public void testGetDate () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		assertEquals("2000-01-01", myContact.getDate().toString());
	}
	
	
	@Test
	public void testSetName () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.setName("name");
		assertEquals("name", myContact.getName());
	}
	
	@Test
	public void testAddPhone () {

		Contact myContact = new Contact("nome", null, "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.addPhone("123456789");
		
		assertEquals("123456789", myContact.getPhone());
	}
	
	@Test
	public void testAddPhone3 () {

		Contact myContact = new Contact("nome", null, "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.addPhone("111111111");
		
		myContact.addPhone("222222222");
		
		assertEquals("111111111", myContact.getPhone());
	}
	
	@Test
	public void testAddPhone2 () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.addPhone("11111111");
		
		assertEquals("123456789", myContact.getPhone());
	}
	
	
	
	@Test
	public void testSetEmail () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.setEmail(null);
		assertEquals(null, myContact.getEmail());
	}
	
	@Test
	public void testSetAddress () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.setAddress(null);
		assertEquals(null, myContact.getAddress());
	}
	
	@Test
	public void testSetDate () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.setDate(null);
		assertEquals(null, myContact.getDate());
	}
	
	@Test
	public void testToString () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		String EOL = System.getProperty("line.separator");
		
		String expected ="Contact: " + EOL
				+ "name = nome" + EOL
				+ "phones = 123456789," + EOL
				+ "address = Rua Sesamo" + EOL
				+ "email = omeucontato@fc.ul.pt" + EOL
				+ "date = 2000-01-01" + EOL;
		
		String obtained = myContact.toString();
		assertEquals(expected, obtained);
	
	}

	
	@Test
	public void testToString2 () {

		Contact myContact = new Contact("nome", null, null, null, null);

		String EOL = System.getProperty("line.separator");
		
		String expected ="Contact: " + EOL
				+ "name = nome" + EOL
				+ "phones = None" + EOL
				+ "address = None" + EOL
				+ "email = None" + EOL
				+ "date = None" + EOL;
		
		String obtained = myContact.toString();
		assertEquals(expected, obtained);
	
	}
	
	@Test
	public void testToString3 () {

		Contact myContact = new Contact(null, "111111", null, null, null);

		String EOL = System.getProperty("line.separator");
		
		String expected ="Contact: " + EOL
				+ "name = None" + EOL
				+ "phones = 111111," + EOL
				+ "address = None" + EOL
				+ "email = None" + EOL
				+ "date = None" + EOL;
		
		String obtained = myContact.toString();
		assertEquals(expected, obtained);
	
	}
	
	
	@Test
	public void testGetPhones () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.addPhone("1111111111");
		
		assertEquals("[123456789, 1111111111]", myContact.getPhones().toString());
	}

	
	@Test
	public void testUpdatePhone () {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.upDatePhone("123456789", "1111111111");
		
		assertEquals("1111111111", myContact.getPhone());
	}
	
	@Test
	public void testUpdatePhone2() {

		Contact myContact = new Contact("nome", "123456789", "Rua Sesamo", "omeucontato@fc.ul.pt", LocalDate.of(2000, 01, 01));

		myContact.upDatePhone("00000000", "1111111111");
		
		assertEquals("123456789", myContact.getPhone());
	}

	
}
