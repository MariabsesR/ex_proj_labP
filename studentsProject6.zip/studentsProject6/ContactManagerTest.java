import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author TeamLabP
 *
 */
class ContactManagerTest {


	@Test
	public void testCreateManager () {

		ContactManager  myManager = new ContactManager("gestorTeste");
		assertEquals(myManager.getManagerName(), "gestorTeste");

	}

	@Test
    public void testContactbyName1 () {
    	
  
    	
    	ContactManager  myManager = new ContactManager("gestorTeste");
    	
    	Contact contact = myManager.contactByName("Pessoa1");
    	
        assertEquals(contact.getName(), "Pessoa1");
    }
	
	@Test
    public void testContactbyName2 () {
    	
  
    	
    	ContactManager  myManager = new ContactManager("gestorTeste");
    	
    	Contact contact = myManager.contactByName("Pessoa1");
    	
        assertTrue(contact.getPhones().isEmpty());
    }
	
	@Test
    public void testContactbyName3 () {
    	
  
    	
    	ContactManager  myManager = new ContactManager("gestorTeste");
    	
    	myManager.contactByName("Pessoa1");
    	
        assertEquals(myManager.getPhoneFromName("Pessoa1"), null);
    }
	
	
	
    @Test
    public void testContactbyPhone1 () {
    	
  
    	
    	ContactManager  myManager = new ContactManager("gestorTeste");
    	
    	Contact contact = myManager.contactByPhone("111222333");
        assertTrue(contact.getPhones().contains("111222333"));

    }
 
    @Test
    public void testContactbyPhone2 () {
    	
  
    	
    	ContactManager  myManager = new ContactManager("gestorTeste");
    	
    	myManager.contactByPhone("111222333");
        assertEquals(myManager.getNameFromPhone("111222333"), null);

    }

	
	@Test
	public void testEditPhone () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		boolean result = myManager.editContactPhone("Pessoa2","222333444", null);
		assertTrue(result);

	}

	@Test
	public void testEditPhone1 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		myManager.editContactPhone("Pessoa2","222333444", null);
		contact = myManager.contactByName("Pessoa2");
		System.out.println(contact);
		assertTrue(contact.getPhones().contains("222333444"));

	}

	@Test
	public void testEditPhone2 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		myManager.editContactPhone("Pessoa2","222333444", null);

		contact = myManager.contactByName("Pessoa2");
		assertTrue(contact.getPhones().contains("222333444"));

	}

	@Test
	public void testEditPhone3 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		myManager.editContactPhone("Pessoa2","222333444", null);

		Boolean result = myManager.editContactPhone("Pessoa2","444555666", "222333444");
		assertTrue(result);

	}


	@Test
	public void testEditPhone4 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		myManager.editContactPhone("Pessoa2","222333444", null);

		myManager.editContactPhone("Pessoa2","444555666", "222333444");

		contact = myManager.contactByName("Pessoa2");
		assertTrue(contact.getPhones().contains("444555666"));

	}



	@Test
	public void testEditPhone5 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		contact.setName("Alterado");
		myManager.editContactPhone("Pessoa2","222333444", null);

		myManager.editContactPhone("Pessoa2","444555666", "222333444");

		contact = myManager.contactByName("Pessoa2");
		assertTrue(!contact.getPhones().contains("111222333"));

	}





	@Test
	public void testEditOptionalInfo () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		myManager.contactByName("Pessoa2");
		boolean result = myManager.editContactOptionalInfo("Pessoa2","Rua Nova", "teste@qualquer", null);
		assertTrue(result);

	}


	@Test
	public void testEditOptionalInfo2 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		myManager.editContactOptionalInfo("Pessoa2","Rua Nova", "teste@qualquer", null);
		contact = myManager.contactByName("Pessoa2");
		assertEquals(contact.getAddress(), "Rua Nova");       

	}

	@Test
	public void testEditOptionalInfo3 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		myManager.editContactOptionalInfo("Pessoa2","Rua Nova", "teste@qualquer", null);
		contact = myManager.contactByName("Pessoa2");

		assertEquals(contact.getEmail(), "teste@qualquer");      

	}


	@Test
	public void testEditOptionalInfo4 () {

		

		ContactManager  myManager = new ContactManager("gestorTeste");

		Contact contact = myManager.contactByName("Pessoa2");
		myManager.editContactOptionalInfo("Pessoa2","Rua Nova", "teste@qualquer", null);
		contact = myManager.contactByName("Pessoa2");

		assertEquals(contact.getEmail(), "teste@qualquer");
		assertEquals(contact.getDate(), null);        

	}


	@Test
	public void testEditOptionalInfo5 () {

		


		ContactManager  myManager = new ContactManager("gestorTeste");

		LocalDate date = LocalDate.of(2000, 1, 1);

		Contact contact = myManager.contactByName("Pessoa2");
		myManager.editContactOptionalInfo("Pessoa2","Rua Nova", "teste@qualquer", date);
		contact = myManager.contactByName("Pessoa2");

		assertEquals(contact.getDate().toString(), "2000-01-01");        

	}


	@Test
	public void testRemove () {


		
		ContactManager  myManager = new ContactManager("gestorTeste");

		myManager.contactByName("Pessoa2");
		boolean result = myManager.editContactPhone("Pessoa2","222333444", null);
		result = myManager.editContactPhone("Pessoa2","555666777", null);
		assertTrue(result);

	}


	@Test
	public void testRemove2 () {


		
		ContactManager  myManager = new ContactManager("gestorTeste");

		myManager.contactByName("Pessoa2");
		myManager.editContactPhone("Pessoa2","222333444", null);
		myManager.editContactPhone("Pessoa2","555666777", null);
		myManager.remove("Pessoa2");
		String key = myManager.getNameFromPhone("222333444");
		assertEquals(key, null); 

	}


	@Test
	public void testRemove3 () {


		
		ContactManager  myManager = new ContactManager("gestorTeste");

		myManager.contactByName("Pessoa2");
		myManager.editContactPhone("Pessoa2","222333444", null);
		myManager.editContactPhone("Pessoa2","555666777", null);
		myManager.remove("Pessoa2");
		String key = myManager.getNameFromPhone("555666777");
		assertEquals(key, null);

	}

	@Test
	public void testRemove4 () {


		
		ContactManager  myManager = new ContactManager("gestorTeste");

		myManager.contactByName("Pessoa2");
		myManager.editContactPhone("Pessoa2","222333444", null);
		myManager.editContactPhone("Pessoa2","555666777", null);
		myManager.remove("Pessoa2");
		String key = myManager.getPhoneFromName("Pessoa2");
		assertEquals(key, null);


	}
}
