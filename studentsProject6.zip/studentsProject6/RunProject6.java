import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Scanner;

public class RunProject6 {
	
	private static final String EOL = System.getProperty("line.separator");
	private static final int DIM = 3;

	public static void main(String[] args) throws FileNotFoundException {
		StringBuilder out = new StringBuilder();
		ContactManager[] managers = new ContactManager[DIM];
		
		for(int i = 0; i < DIM; i++) {
			String agentName = "agent" + i;
			String fileName = "contacts" + i;
			out.append(">>> Creating manager: ").append(agentName).append(" with contacts from file ").append(fileName).append(EOL);
			managers[i] = new ContactManager(agentName);
			loadContacts(managers[i], fileName, out);
			out.append(managers[i].getLog());
			String mainPhone = managers[i].getPhoneFromName("Afonso");
			if (mainPhone == null)
				out.append(">>>This agent does not know a phone for: Afonso").append(EOL);
			else
				out.append(">>>This agent's phone for Afonso is ").append(mainPhone).append(EOL);
			String contactString = managers[i].getInfo("Afonso");
			if (contactString != null)
				out.append(contactString);
			else
				out.append("Unknown contact!").append(EOL);
			String name = managers[i].getNameFromPhone("961234567");
			if (name == null)
				out.append(">>>This agent does not know a name for: 961234567").append(EOL);
			else
				out.append(">>>This agent's name for phone 961234567 is ").append(name).append(EOL);
			contactString = managers[i].getInfo("961234567");
			if (contactString != null)
				out.append(contactString);
			else
				out.append("Unknown contact!").append(EOL);
			out.append(EOL);
		}
	
		PrintWriter output = new PrintWriter("output.txt");
		output.println(out);
		output.close();
	}
	
	private static void loadContacts( ContactManager cm, String filename, StringBuilder sb) throws FileNotFoundException {
		try (Scanner sc = new Scanner(new File (filename ))) {
			while (sc.hasNextLine()) {
				String name = null;
				String[] phones = null;
				int phoneIndex = 0;
				String mainPhone = null;
				String address = null;
				String email = null;
				LocalDate date = null;
				String contacKey = null;
				String [] components = sc.nextLine().split(";");
				if (!components[0].equals(" "))
					name = components[0].strip();
				if (!components[1].equals(" ")) {
					phones = components[1].split(",");
					int i=0;
					while(i < phones.length) {
						phones[i] = phones[i].strip();
						i++;
					}
					mainPhone = phones[0];
				}
				if (!components[2].equals(" "))
					address = components[2].strip();
				if (!components[3].equals(" "))
					email = components[3].strip();
				if (!components[4].equals(" ")) {
					String[] componentsDate = components[4].split("-");
					date = LocalDate.of(Integer.valueOf(componentsDate[0].strip()), 
							Integer.valueOf(componentsDate[1].strip()), 
							Integer.valueOf(componentsDate[2].strip()));
				}
				if (name != null) { 
					contacKey = name;
					cm.contactByName(name);
					phoneIndex = 0;
				}
				else {
					contacKey = mainPhone;
					cm.contactByPhone(mainPhone);
					phoneIndex = 1;
				}
				if (phones != null)
					for (int i = phoneIndex; i < phones.length; i++) {
						cm.editContactPhone(contacKey, phones[i], null);
					}

				cm.editContactOptionalInfo(contacKey, address, email , date);
			}
			
		}
	}

}
