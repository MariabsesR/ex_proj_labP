
/**
 * The instances of this class represent a Vehicle and its defined
 * characteristics
 * 
 * @author Maria Rocha fc58208
 * 
 */
public class Vehicle {

	// Characteristics of the vehicle
	private final String numberPlate;
	private final TypeOfVehicle type;
	private final int arrivingTimeHours;
	private final int arrivingTimeMinutes;
	private final double size;

	/**
	 * Creates an instance of a Vehicle with the given parameters
	 * 
	 * @param numberPlate         the unique vehicle plate
	 * @param type                the type of vehicle
	 * @param arrivingTimeHours   the hours it arrives in the parkingLot
	 * @param arrivingTimeMinutes the minutes it arrives in the parkingLot
	 * @param size                the size of the vehicle
	 * 
	 */

	public Vehicle(String numberPlate, TypeOfVehicle type, int arrivingTimeHours, int arrivingTimeMinutes,
			double size) {

		this.numberPlate = numberPlate;
		this.type = type;
		this.arrivingTimeHours = arrivingTimeHours;
		this.arrivingTimeMinutes = arrivingTimeMinutes;
		this.size = size;

	}

	/**
	 * Returns the unique vehicle plate
	 * 
	 * @return unique vehicle plate
	 */

	public String getVehicleNumberPlate() {
		return numberPlate;
	}

	/**
	 * Returns the type of vehicle
	 * 
	 * @return type of vehicle
	 */

	public TypeOfVehicle getTypeOfVehicle() {
		return type;
	}

	/**
	 * returns the hour that the vehicle arrived
	 * 
	 * @return the hour that the vehicle arrived
	 */

	public int getLeavingTimeHours() {
		return arrivingTimeHours;
	}

	/**
	 * returns the minutes that the vehicle arrived
	 * 
	 * @return the minutes that the vehicle arrived
	 */

	public int getLeavingTimeMinutes() {
		return arrivingTimeMinutes;
	}

	/**
	 * Returns the size of our vehicle
	 * 
	 * @return size of vehicle
	 */
	public double getSize() {
		return size;
	}

}
