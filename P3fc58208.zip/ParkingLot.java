
/**
 * The instances of this class represent a Parking Lot
 * 
 * @author Maria Rocha fc58208
 * 
 */

public class ParkingLot {

	// Attributes of our parking Lot
	// private boolean fullFloor;
	public static final String EOL = System.getProperty("line.separator");
	private static final int AMMOUNT_OF_LEVELS = 3;
	private final static int MINIMUM_HOURS = 0;
	private final static int MAX_HOURS = 23;
	private final static int MINIMUM_MINUTES = 0;
	private final static int MAX_MINUTES = 59;
	private final static int DOESNT_EXIST = -1;
	private Vehicle[] allVehiclesToPark;
	private Floor[] allLevels;
	

	/**
	 * Creates an instance of ParkingLot each floor with the size given for it
	 * 
	 * @param size_floor1 size of 1 floor
	 * @param size_floor2 size of 2 floor
	 * @param size_floor3 size of 3 floor
	 * @requires{@code size_floor1>=0 && size_floor2>=0 && size_floor3>=0}
	 */
	public ParkingLot(double size_floor1, double size_floor2, double size_floor3) {

		// creates for each floor an instance of the object floor
		Floor level1 = new Floor(size_floor1);
		Floor level2 = new Floor(size_floor2);
		Floor level3 = new Floor(size_floor3);
		allLevels = new Floor[] { level1, level2, level3 };
		// fullFloor = false;
		allVehiclesToPark = new Vehicle[0];

	}

	/**
	 * Parks the vehicles in each floor , starting at the lowest,and parks them by
	 * order of they arriving time.
	 * 
	 * @param booking the description of the vehicles to park
	 * @return String with the instructions of the sequence done to park the
	 *         vehicles
	 * @requires {@code validBooking(booking) ==true && String !=null}
	 */
	public String parkVehicles(String booking) {

		String[] park = booking.split(", ");
		allVehiclesToPark = new Vehicle[park.length];
		String plate = "";
		String type = "";
		String size = "";
		String time = "";
		StringBuilder instructions = new StringBuilder();
		StringBuilder notParked = new StringBuilder();

		// runs through the description of each car and gets its atributes and saves
		// them
		for (int totalCars = 0; totalCars < park.length; totalCars++) {
			StringBuilder separate = new StringBuilder(park[totalCars]);

			plate = separate.substring(0, separate.indexOf("-"));
			separate.delete(0, 7);

			type = separate.substring(0, separate.indexOf(" "));
			separate.delete(0, separate.indexOf(" ") + 2);

			time = separate.substring(0, separate.indexOf(","));
			separate.delete(0, separate.indexOf(",") + 1);

			size = separate.substring(0, separate.indexOf(")"));

			TypeOfVehicle typeOfVe = TypeOfVehicle.findByValue(type);
			int hours = Integer.parseInt(time.substring(0, time.indexOf(":")));
			int minutes = Integer.parseInt(time.substring(time.indexOf(":") + 1, time.length()));
			double space = Double.parseDouble(size);

			allVehiclesToPark[totalCars] = new Vehicle(plate, typeOfVe, hours, minutes, space);

		}

		// parking the cars
		int counter = 0;

		while (counter < allVehiclesToPark.length) {

			boolean ableToFitInFloor = false;
			// it will run through all the floor and stop when it find a floor that fits
			for (int i = 0; i < AMMOUNT_OF_LEVELS && !ableToFitInFloor; i++) {

				// checks if the vehicle is able to be parked on the current floor
				ableToFitInFloor = allVehiclesToPark[counter].getSize()
						+ allLevels[i].getOccupiedFloor() <= allLevels[i].getsize()
						&& (allVehiclesToPark[counter].getLeavingTimeHours() > allLevels[i].getLastHourFloor()
								|| (allVehiclesToPark[counter].getLeavingTimeHours() == allLevels[i].getLastHourFloor()
										&& allVehiclesToPark[counter].getLeavingTimeMinutes() >= allLevels[i]
												.getLastMinuteFloor()));
				// if its able to it will park it
				if (ableToFitInFloor) {

					allLevels[i].floor.push(allVehiclesToPark[counter]);
					allLevels[i].occupiedFloor += allVehiclesToPark[counter].getSize();
					allLevels[i].lastHourFloor = allVehiclesToPark[counter].getLeavingTimeHours();
					allLevels[i].lastMinuteFloor = allVehiclesToPark[counter].getLeavingTimeMinutes();

					instructions.append("Go pick " + allVehiclesToPark[counter].getTypeOfVehicle().toString() + " "
							+ allVehiclesToPark[counter].getVehicleNumberPlate() + " and park it on floor " + (i + 1));
					instructions.append(EOL);

				}

			}
			// if after running though all the floors its not able to park the vehicle saves
			// its plate
			if (!ableToFitInFloor)
				notParked.append(allVehiclesToPark[counter].getVehicleNumberPlate() + " ");

			// goes to the next vehicle
			counter++;
		}
		// if there were vehicles that werent parked also adds that information
		if (notParked.length() != 0) {
			instructions.append("No space left to park the following vehicles: ");
			instructions.append(notParked.toString());
		}
		// returns the instructions done
		return instructions.toString();

	}

	/*
	 * Checks if our ParkingLot is empty
	 * 
	 * @returns is the parking Lot empty
	 */
	public boolean isEmpty() {

		boolean isntEmpty = true;
		for (int i = 0; i < AMMOUNT_OF_LEVELS && isntEmpty == true; i++) {
			isntEmpty = allLevels[i].occupiedFloor != 0;
		}

		return !isntEmpty;
	}

	/**
	 * Checks if the given String is a valid booking, hence has all the necessary
	 * parameter so , number plate and type of vehicle(xxxxx-nnnnn), arriving time
	 * and its size (hh:mm,x.y), and all of each are written correctly
	 * 
	 * @param booking the description of multiple vehicles which will be parked
	 * @return the given String is a valid booking
	 * @requires {@code String !=null}
	 */

	// throws NullPointerException if string null
	public BookingStatus validBooking(String booking) {

		String[] park = booking.split(", ");
		String testPlates[] = new String[park.length];
		String plate = "";
		String type = "";
		String size = "";
		String time = "";

		BookingStatus ruleStatus = BookingStatus.VALID_BOOKING;

		// test rule 1 and if its not valid it will stop searching other rules
		for (int totalCars = 0; totalCars < park.length && ruleStatus == BookingStatus.VALID_BOOKING; totalCars++) {

			StringBuilder separate = new StringBuilder(park[totalCars]);

			boolean rule1 = park[totalCars].contains("-") && park[totalCars].contains(" ")
					&& park[totalCars].contains(",");
			// if rule 1 equals true it will save the parameters of the vehicle
			if (rule1) {
				plate = separate.substring(0, separate.indexOf("-"));
				separate.delete(0, 7);

				type = separate.substring(0, separate.indexOf(" "));
				separate.delete(0, separate.indexOf(" ") + 2);

				time = separate.substring(0, separate.indexOf(","));
				separate.delete(0, separate.indexOf(",") + 1);

				size = separate.substring(0, separate.indexOf(")"));
			} else
				ruleStatus = BookingStatus.BAD_FORMAT;

			// test rule 2
			for (int j = 0; j < testPlates.length && ruleStatus == BookingStatus.VALID_BOOKING; j++) {
				if (plate.equals(testPlates[j]))
					ruleStatus = BookingStatus.DUPLICATE_VEHICLE;
			}
			// ads the plate that passed rule 2 to our saved plates
			testPlates[totalCars] = plate;
			// test rule 3
			if (TypeOfVehicle.findByValue(type) == null && ruleStatus == BookingStatus.VALID_BOOKING)
				ruleStatus = BookingStatus.UNKNOWN_VEHICLE_TYPE;

			// test rule 4
			// checks if it has both the hours and minutes
			if (time.indexOf(":") == DOESNT_EXIST && ruleStatus == BookingStatus.VALID_BOOKING)
				ruleStatus = BookingStatus.INVALID_TIME;
			else {
				// if it doesnt have 5 of length than its miising part of either hours or
				// minutes
				// since the hours and minutes both need to have a size of 2
				if (time.length() != 5 && ruleStatus == BookingStatus.VALID_BOOKING) {
					ruleStatus = BookingStatus.INVALID_TIME;
				}
				// if it has the correct size checks to see if the given time is a correct time
				if (time.length() == 5 && ruleStatus == BookingStatus.VALID_BOOKING) {
					int hour = Integer.parseInt(time.substring(0, 2));
					int minute = Integer.parseInt(time.substring(3, 5));
					if (hour < MINIMUM_HOURS || hour > MAX_HOURS || minute < MINIMUM_MINUTES || minute > MAX_MINUTES)
						ruleStatus = BookingStatus.INVALID_TIME;
				}

			}
			// test rule 5
			if (ruleStatus == BookingStatus.VALID_BOOKING && Double.parseDouble(size) < 2.0)
				ruleStatus = BookingStatus.MINIMUM_LENGTH;

		}

		return ruleStatus;
	}

	/**
	 * Checks if we can withdraw the vehicle from the last positions of each floor
	 * of the ParkingLot,and if so withdraws it
	 * 
	 * @param string number plate of the vehicle
	 * @return is the vehicle able to be withdrawn
	 * @requires{@code string!=null}
	 */

	public boolean pickVehicle(String string) {

		boolean result = false;

		for (int i = 0; i < AMMOUNT_OF_LEVELS; i++) {
			if (!allLevels[i].floor.isEmpty()) {
				// if one of the levels is not empty then the parking floor is not empty

				// check to see if the top of our floor is equal to the number plate
				if (allLevels[i].floor.peek().getVehicleNumberPlate().equals(string)) {
					result = true;
					allLevels[i].floor.pop();

				}
				// checks if after the pop, the floor is empty and initializes the
				// atributes with the starting value
				if (allLevels[i].floor.isEmpty())
					allLevels[i] = new Floor(allLevels[i].getsize());

			}

		}

		return result;
	}

	/**
	 * Makes all the floors in the parking Lot empty
	 * 
	 */

	public void free() {

		for (int i = 0; i < AMMOUNT_OF_LEVELS; i++) {
			allLevels[i].lastHourFloor = 0;
			allLevels[i].lastMinuteFloor = 0;
			allLevels[i].occupiedFloor = 0;
			allLevels[i].floor = new ArrayStack<Vehicle>();
		}
	}

	/**
	 * The instances of this class repent each of the floor of our Parking Lot
	 * 
	 *
	 */

	private class Floor {

		private double size_floor;
		private double occupiedFloor;
		private int lastHourFloor;
		private int lastMinuteFloor;
		private Stack<Vehicle> floor;

		/**
		 * Creates a instance of this class with the given size of the floor
		 * 
		 * @param size_floor max size that can be used on each floor
		 */
		private Floor(double size_floor) {

			this.size_floor = size_floor;
			occupiedFloor = 0;
			lastHourFloor = 0;
			lastMinuteFloor = 0;
			floor = new ArrayStack<Vehicle>();

		}

		/**
		 * Returns the amount of occupied space
		 * 
		 * @return amount of occupied space
		 */

		private double getOccupiedFloor() {
			return occupiedFloor;
		}

		/**
		 * Returns the arriving hours of the last car we put in the floor
		 * 
		 * @return the arriving hours
		 */

		private int getLastHourFloor() {
			return lastHourFloor;
		}

		/**
		 * Returns the arriving minutes of the last car we put in the floor
		 * 
		 * @return the arriving minutes
		 */

		private int getLastMinuteFloor() {
			return lastMinuteFloor;
		}

		/**
		 * Returns the max space the vehicles may occupy of the floor
		 * 
		 * @return
		 */
		private double getsize() {
			return size_floor;
		}

	}

}
