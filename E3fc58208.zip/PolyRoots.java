import java.util.Vector;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;

/**
 * This class permits the discovery the remaining roots of a polynomial
 * 
 * @author Maria Rocha fc58208
 *
 */

public class PolyRoots {

	public static final double DELTA = 0.0001;
	
	/**
	 * Returns the remaining roots of the given polynomial
	 * 
	 * @param inFile file with the description of the polynomial, grade and known
	 *               roots
	 * @return remaining rots
	 * @throws FileNotFoundException
	 * @requires{@code inFile!=null}
	 */

	public static double[] find2Roots(String inFile) throws FileNotFoundException {

		Scanner sc = new Scanner(new File(inFile));
		Vector<Double> coficient = new Vector<Double>();
		Vector<Double> root = new Vector<Double>();
		// save grade of polynomial
		double grade = sc.nextDouble();
		sc.nextLine();
		// save coefficient of the polynomial
		for (int i = 0; i <= grade; i++) {
			coficient.add(sc.nextDouble());
		}
		sc.nextLine();
		// save all the known roots
		while (sc.hasNextDouble()) {
			root.add(sc.nextDouble());
		}
		double[] result = new double[2];
		// if the grade is over 2 then it needs to do ruffini first else only needs the
		// solving formula
		if (grade > 2)
			result = resolvingFormula(roufini(coficient, root, 0));
		else
			resolvingFormula(coficient);
		sc.close();

		return result;

	}

	/**
	 * Returns the roots of a polynomial of degree 2
	 * 
	 * @param coficient the coefficient of the polynomial we want to know the roots
	 * @requires {@code (Math.pow(b, 2) - 4 * a * c)>0 && !coficient.isEmpty() && coficient.size()=3}
	 * @requires the file must be in .poly format
	 * @return roots of the polynomial
	 */

	private static double[] resolvingFormula(Vector<Double> coficient) {
		// saves all the needed variable to do the formula
		double a = (double) coficient.get(0);
		double b = (double) coficient.get(1);
		double c = (double) coficient.get(2);

		double[] result = new double[2];

		// does part of the formula
		double part = Math.sqrt(Math.pow(b, 2) - 4 * a * c);
		// does the rest of the formula
		result[1]  = (-b + part) / (2 * a);
		result[0] = (-b - part) / (2 * a);

	     
	     //checks if the roots are not the same if so sorts the array
		if(Math.abs(result[0]-result[1])>DELTA)Arrays.sort(result);

		return result;

	}

	/**
	 * Applies the ruffini to the polynomial until it gets to degree 2
	 * 
	 * @param coficient coefficient of the current polynomial
	 * @param root      the known roots of the polynomial
	 * @param counter   which root is being used to apply the ruffini
	 * @requires{@code !coficient.isEmpty() && coficient.size()>3}
	 * @return polynomial of degree 2
	 */
	private static Vector<Double> roufini(Vector<Double> coficient, Vector<Double> root, int counter) {
		Vector<Double> newCoficient = new Vector<Double>();
		// ads the first coefficient since it will be the same
		newCoficient.add((double) coficient.get(0));
		// does each ruffini
		for (int i = 1; i < coficient.size() - 1; i++) {
			double multiply = (double) newCoficient.get(i - 1);
			double result = (double) coficient.get(i) + ((double) root.get(counter) * multiply);
			newCoficient.add(result);

		}
		// standard case to leave loop
		if (newCoficient.size() > 3) {
			// used the root next to ruffini again
			counter++;
			newCoficient = roufini(newCoficient, root, counter);

		}
		return newCoficient;
	}

}
