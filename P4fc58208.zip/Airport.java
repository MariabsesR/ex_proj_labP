import java.util.LinkedList;
import java.util.List;
import java.io.FileNotFoundException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

/**
 * Class that represents instances of an Airport
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Airport {

	private final String AIRPORT_NAME;
	private final LinkedList<FlightBooking> listOfBookings;
	private final LinkedList<FlightBooking> listOfConfirmedBookings;
	private final ArrayList<AirlineCompany> listOfAirlineCompanies;
	public static final String EOL = System.getProperty("line.separator");

	/**
	 * Creates an instance of an Airport with the given name
	 * 
	 * @param string name of the airport
	 * @requires {@code string!=null}
	 */

	public Airport(String string) {
		AIRPORT_NAME = string;
		listOfBookings = new LinkedList<FlightBooking>();
		listOfConfirmedBookings = new LinkedList<FlightBooking>();
		listOfAirlineCompanies = new ArrayList<AirlineCompany>();
	}

	/**
	 * Reads informations about the Flights that leave the airport and each airline
	 * company from a File and loads them on the Airport
	 * 
	 * @param string name of the File with description
	 * @throws FileNotFoundException
	 * @requires{@code string!=null} the file with string as name, must follow the correct format
	 * for each airline there must be a that first line contains the name of the airline company and the number of flights 
	 *  represented by an integer; the next lines that have to be the same amount as
	 *  indicated previously, and each line must have by order destination which must be a 3 letter string 
	 *  in uppercase and must belong to the DstCode class, leaving time must be specified by
	 *  hh:mm and number of seats must be above or equal to 0 and all of
	 *  them must be separated by " " and {@code string!=null} 
	 */

	public void loadFlights(String string) throws FileNotFoundException {

		Scanner sc = new Scanner(new File(string));
		String nameAirCompany;
		DstCode destination;
		LocalTime leavingtime;
		int numberOfSeats;
		int amountOfFlights;

		while (sc.hasNext()) {
			// reads and creates the ammount of flights and the name of the airline
			nameAirCompany = sc.next();
			AirlineCompany company = new AirlineCompany(nameAirCompany);
			amountOfFlights = sc.nextInt();

			sc.nextLine();

			for (int i = 0; i < amountOfFlights; i++) {
				// gets the parameters of each Flight and loads them to the
				// given airline company
				destination = DstCode.findByValue(sc.next());
				leavingtime = LocalTime.parse(sc.next());
				numberOfSeats = sc.nextInt();

				company.addFlight(destination, leavingtime, numberOfSeats);
				// checks if there is a next line to scan
				if (sc.hasNextLine())
					sc.nextLine();

			}
			// adds the airline company to the airport
			listOfAirlineCompanies.add(company);

		}
		sc.close();
	}

	/**
	 * Return the list of airline company of the airport
	 * 
	 * @return list of airline company
	 */

	public ArrayList<AirlineCompany> getAirlines() {

		return listOfAirlineCompanies;
	}

	/**
	 * Creates a FlightBooking request and adds it to the list of Bookings
	 * 
	 * @param rawBookingStr reservation that contains parameters of FlightBooking
	 * @requires the given string must contain all the parameters,by this order,
	 *           destination which must be a 3 letter string in uppercase and must
	 *           belong to the DstCode class, leaving time must be specified by
	 *           hh:mm and number of seats must be above or equal to 0 and all of
	 *           them must be separated by " " and {@code string!=null}
	 */

	public void loadBooking(String rawBookingStr) {

		String[] details = rawBookingStr.split(" ");
		DstCode destination = DstCode.findByValue(details[0]);
		LocalTime leavingtime = LocalTime.parse(details[1]);
		int numberOfSeats = Integer.parseInt(details[2]);

		listOfBookings.add(new FlightBooking(destination, leavingtime, numberOfSeats, false));

	}

	/**
	 * Returns the list of Bookings of the airport
	 * 
	 * @return list of Bookings
	 */

	public List<FlightBooking> getDayBookings() {

		return listOfBookings;
	}

	/**
	 * Process the list of Booking of the airport and checks with all the airline
	 * companies if they can confirm the reservations, it also sorts the booking
	 * queue after each company has checked the bookings
	 * 
	 * @requires {@code !listOfAirlineCompanies.isEmpty() && !listOfBookings.isEmpty()}
	 */
	public void processBookings() {
		for (int i = 0; i < listOfAirlineCompanies.size(); i++) {
			listOfAirlineCompanies.get(i).loadBookings(listOfBookings);
			sortBookingQueues();
		}

	}

	/**
	 * Returns all the Confirmed Bookings
	 * 
	 * @return confirmed Bookings
	 */
	public List<FlightBooking> getServedBookings() {

		return listOfConfirmedBookings;
	}

	/**
	 * Returns the name of the airport
	 * 
	 * @return name of the airport
	 */

	public String getAirportName() {
		return AIRPORT_NAME;
	}

	/**
	 * Sorts the Booking list by removing all the confirmed Booking
	 */

	public void sortBookingQueues() {
		for (int i = 0; i < listOfBookings.size(); i++) {
			if (listOfBookings.get(i).isBooked()) {
				listOfConfirmedBookings.add(listOfBookings.get(i));
				listOfBookings.remove(i);
				// lost part of the size of the list so our i needs to be pushed back
				i--;
			}
		}
	}

	/**
	 * Returns a textual representation of the Airport
	 */

	public String toString() {
		StringBuilder reservation = new StringBuilder();
		reservation.append("Airport " + getAirportName() + " has the current schedule for today:" + EOL);
		for (int i = 0; i < listOfAirlineCompanies.size(); i++) {
			reservation.append(listOfAirlineCompanies.get(i).toString());
			reservation.append(EOL);

		}
		reservation.append("The airport was not able to schedule the following reservations:" + EOL);
		for (int i = 0; i < listOfBookings.size(); i++) {
			reservation.append(listOfBookings.get(i).toString());
			reservation.append(EOL);

		}

		return reservation.toString();
	}

}
