import java.util.LinkedList;
import java.util.List;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 * Class that represents an instance of an Airline Company
 * 
 * @author Maria Rocha fc58208
 *
 */

public class AirlineCompany {

	private final String AIRLINE_COMPANY_NAME;
	private final ArrayList<Flight> listOfFlights;
	private final LinkedList<FlightBooking> listOfBookings;
	public static final String EOL = System.getProperty("line.separator");

	/**
	 * Creates an instance of AirlineCompany whit the given parameters, and
	 * initializes its attributes empty(list of Flights and list of Bookings)
	 * 
	 * @param airlineName the name of the AirlineCompany
	 * @requires{@code airline!=null}
	 */

	public AirlineCompany(String airlineName) {
		AIRLINE_COMPANY_NAME = airlineName;
		listOfFlights = new ArrayList<Flight>();
		listOfBookings = new LinkedList<FlightBooking>();
	}

	/**
	 * Returns the name of the airline Company
	 * 
	 * @return name of airline Company
	 */

	public String getAirlineCompanyName() {
		return AIRLINE_COMPANY_NAME;
	}

	/**
	 * Returns the amount of Flights of the Airline
	 * 
	 * @return amount of Flights
	 */
	public int getNumFlights() {

		return listOfFlights.size();
	}

	/**
	 * Returns the list of Bookings of the Airline
	 * 
	 * @return list of Bookings
	 */

	public List<FlightBooking> getBookings() {

		return listOfBookings;
	}

	/**
	 * Returns the list of Flights of the Airline
	 * 
	 * @return list of Flights
	 */

	public ArrayList<Flight> getFlights() {

		return listOfFlights;
	}

	/**
	 * Adds a Flight to the list of Flights of the Airline company
	 * 
	 * @param ams       destination of the Flight
	 * @param now       Time the Flight is leaving
	 * @param freeSeats amount of free Seats on the Flight
	 * @requires {@code freeSeats>=0}
	 */

	public void addFlight(DstCode ams, LocalTime now, int freeSeats) {
		Flight airplane = new Flight(ams, now, freeSeats);
		// adds the element to the first spot of the list
		listOfFlights.add(airplane);

	}

	/**
	 * Loads the given list of FlightBooking and does all the possible reservation,
	 * all that were reserved will have their ReservationStatus changed to CONFIRMED
	 * and also it shall copied to the list of Bookings of the airline
	 * 
	 * @param dayBookings FlightBooking to save
	 */

	public void loadBookings(List<FlightBooking> dayBookings) {

		int counterFlights = 0;
		int counterBooking = 0;
		boolean test = false;

		// while none of them is empty and we havent tested all Flights and bookings
		while (!dayBookings.isEmpty() && !listOfFlights.isEmpty() && counterBooking < dayBookings.size()
				&& counterFlights < listOfFlights.size()) {
			for (int i = listOfFlights.size() - 1; i >= 0 && !test; i--) {
				// checks if the reservation can be used with this flight
				test = listOfFlights.get(counterFlights).verifySchedule(dayBookings.get(counterBooking));
				if (test) {
					// confirms the reserve, books the seats and adds the reverse the the list of
					// bookings
					dayBookings.get(counterBooking).confirm();
					listOfFlights.get(counterFlights).bookSeats(dayBookings.get(counterBooking).getNumberOfSeats());
					listOfBookings.add(dayBookings.get(counterBooking).copyFlightBooking());
					// passed to the next booking
					counterBooking++;
				}
				// if the reserve doesnt apply to the current flight will try another
				counterFlights++;
			}
			// changes the booking being tested and resets the flights
			if (!test)
				counterBooking++;
			counterFlights = 0;
			test = false;
		}
	}

	/**
	 * Returns a textual representation of the Airline Company
	 */

	public String toString() {
		StringBuilder reservation = new StringBuilder();
		reservation.append("Airline " + getAirlineCompanyName() + " has the following flights:" + EOL);
		for (int i = 0; i < listOfFlights.size(); i++) {
			reservation.append(listOfFlights.get(i).toString());
			reservation.append(EOL);
		}
		reservation.append("and has accepted the following flight reservations:" + EOL);
		for (int i = 0; i < listOfBookings.size(); i++) {
			reservation.append(listOfBookings.get(i).toString());
			reservation.append(EOL);
		}
		return reservation.toString();
	}

}
