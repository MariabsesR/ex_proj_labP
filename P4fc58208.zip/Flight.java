import java.time.LocalTime;

/**
 * Class that represents instances of Flights
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Flight {

	private final DstCode DESTINATION;
	private final LocalTime LEAVING_TIME;
	private int freeSteats;

	/**
	 * Creates an instance of a Flight with the given parameters
	 * 
	 * @param destination destination of the Flight
	 * @param leavingTime time the the flight is leaving
	 * @param freeSeats   amount of free seats on the flight
	 * @requires{@code freeSeats>=0}
	 */

	public Flight(DstCode destination, LocalTime leavingTime, int freeSeats) {
		DESTINATION = destination;
		LEAVING_TIME = leavingTime;
		this.freeSteats = freeSeats;
	}

	/**
	 * Reserves free seats, hence makes the amount of free seats smaller; In the
	 * case that there is not enough free seats to reserve returns false;
	 * 
	 * @param seatsToBook the amount of seats we will reserve
	 * @return all the seats can be reserved
	 */

	public boolean bookSeats(int seatsToBook) {

		int test = getNumOfSeats() - seatsToBook;
		if (test >= 0)
			freeSteats = test;
		return test >= 0;

	}

	/**
	 * Returns the amount of free seats on the Flight
	 * 
	 * @return amount of free seats
	 */
	public int getNumOfSeats() {

		return freeSteats;
	}

	/**
	 * Destination of the Flight
	 * 
	 * @return destination of the flight
	 */

	public DstCode getDestinationCode() {

		return DESTINATION;
	}

	/**
	 * Returns the leaving time of the Flight
	 * 
	 * @return leaving time of the Flight
	 */

	public LocalTime getTime() {
		return LEAVING_TIME;
	}

	/**
	 * Checks if the given schedule (FlightBooking) can be reserve on the Flight
	 * meaning it gas the same destination, the flight leaves after or at the same
	 * time given by the schedule, and there is enough seats on the plane for the
	 * reservation
	 * 
	 * 
	 * @param Schedule reservation we want to check
	 * @return the given reservation is able to fit of the Flight
	 */

	public boolean verifySchedule(FlightBooking Schedule) {
		// the flight and the booking have the same destination
		boolean result = Schedule.getDestinationCode().equals(this.DESTINATION);
		// flight leaving time is after or equal to the booking leaving time
		boolean result1 = LEAVING_TIME.isAfter(Schedule.getMinimalStartingTime())
				|| LEAVING_TIME.equals(Schedule.getMinimalStartingTime());
		// there are enough seats on the plane to reserve
		boolean result2 = Schedule.getNumberOfSeats() <= freeSteats;

		return result && result1 && result2;
	}

	/**
	 * Returns a textual representation of our Flight
	 */

	public String toString() {

		String reservation = ("DST: " + getDestinationCode() + " - " + getTime() + " - Seats: " + getNumOfSeats());
		return reservation;
	}

}
