import java.time.LocalTime;

/**
 * Class that represents instances of Bookings of Flights
 * 
 * @author Maria Rocha fc58208
 *
 */

public class FlightBooking {

	private final DstCode destination;
	private final LocalTime leavingTime;
	private int numberOfReservations;
	private ReservationState reservationStatus;
	private boolean isBooked;

	/**
	 * Creates an instance of FlightBooking with the given parameters
	 * 
	 * @param destination          the destination of the wanted flight
	 * @param leavingTime          possible leaving time
	 * @param numberOfReservations amount of seats for that reservation
	 * @param confirmedReservation if the reservation is already confirmed or not
	 * @requires{@code numberOfReservations>=0}
	 */

	public FlightBooking(DstCode destination, LocalTime leavingTime, int numberOfReservations,
			boolean confirmedReservation) {

		this.destination = destination;
		this.leavingTime = leavingTime;
		this.numberOfReservations = numberOfReservations;
		isBooked = confirmedReservation;
		if (confirmedReservation)
			this.reservationStatus = ReservationState.CONFIRMED;
		else
			this.reservationStatus = ReservationState.NOT_CONFIRMED;
	}

	/**
	 * Returns destination of the FlightBooking
	 * 
	 * @return destination of the FlightBooking
	 */
	public DstCode getDestinationCode() {
		return destination;
	}

	/**
	 * Status of FlightBooking, given by ReservationState
	 * 
	 * @return Status of FlightBooking
	 */
	
	public ReservationState getReservationState() {
		return reservationStatus;
	}
	/**
	 * Returns possible leaving time
	 * 
	 * @return possible leaving time
	 */
	public LocalTime getMinimalStartingTime() {
		return leavingTime;
	}

	/**
	 * Return number of seats to be reserved
	 * 
	 * @return number of seats to be reserved
	 */

	public int getNumberOfSeats() {
		return numberOfReservations;
	}

	/**
	 * Status of FlightBooking, given by a boolean
	 * 
	 * @return Status of FlightBooking
	 */

	public boolean isBooked() {
		return isBooked;
	}

	/**
	 * Transforms the status of the instance of FlightBooking into
	 * ReservationState.CONFIRMED
	 * 
	 */

	public void confirm() {
		isBooked = true;
		reservationStatus = ReservationState.CONFIRMED;
	}

	/**
	 * Returns a copy of our current FlightBooking
	 * 
	 * @return copy of our current FlightBooking
	 */

	public FlightBooking copyFlightBooking() {
		return new FlightBooking(getDestinationCode(), getMinimalStartingTime(), getNumberOfSeats(), isBooked());
	}

	/**
	 * Returns a textual representation of our FlightBooking
	 */

	public String toString() {

		String reservation = ("Flight to " + getDestinationCode() + " - time: " + getMinimalStartingTime()
				+ " - seats: " + getNumberOfSeats());
		return reservation;
	}

	/**
	 * Enumerator representing the status of the Reservation
	 *
	 */

	private enum ReservationState {
		CONFIRMED, NOT_CONFIRMED;

	}
}
