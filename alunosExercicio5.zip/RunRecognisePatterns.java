import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Class to assess the behavior of the methods in RecognisePatterns.java
 * 
 * @author LabP team
 *
 */
public class RunRecognisePatterns {
	
	public static void main(String[] args) throws FileNotFoundException {

		String eol = System.getProperty("line.separator");
		
		////********************* VALIDATING STUDENTS EMAILS *******************************************////
		Scanner in = new Scanner (new File("emails.txt"));
		StringBuilder outputStr = new StringBuilder(); 
		
		
		while (in.hasNextLine()) {
			String line = in.nextLine();
			
			if(RecognisePatterns.isValidStudentEmail(line) ) {
				outputStr.append(line).append(" is a VALID email address at FCUL").append(eol);
			}
			else {
				outputStr.append(line).append(" is not a valid email address at FCUL").append(eol);
			}
		}
		
		System.out.println(outputStr);
		in.close();
		
		////********************* VALIDATING IPv4 ADDRESSES *******************************************////
		in = new Scanner (new File("IPs.txt"));
		// clean the StringBuilder
		outputStr.setLength(0);
		
		
		while (in.hasNextLine()) {
			String line = in.nextLine();
			
			if( RecognisePatterns.isValidIPAddress(line) ) {
				outputStr.append("\"").append(line).append(" is a VALID IPv4 address").append(eol);
			}
			else {
				outputStr.append("\"").append(line).append("\" is not a valid IPv4 address").append(eol);
			}
		}
		
		System.out.println(outputStr);
		in.close();
		
		////**************************** FINDING DATES***********************************************////
		in = new Scanner (new File("dates.txt"));
		// clean the StringBuilder
		outputStr.setLength(0);
		
		int numOfLine = 0;
		while (in.hasNextLine()) {
			
			numOfLine++;
			String line = in.nextLine();
			
			String resultOfTheSearch = RecognisePatterns.matchDate(line); 
			
			if( resultOfTheSearch != null ) {
			
				outputStr.append("Found date << ").append(resultOfTheSearch).append(" >> on line ")
				.append(numOfLine).append(eol);
			
			}
			
		}
		
		System.out.println(outputStr);
		in.close();		
		
		
		////********************* VALIDATING PARKING RESERVATIONS ******************************////
		
		in = new Scanner (new File("parkingReservations.txt"));
		// clean the stringBuilder
		outputStr.setLength(0);
		
		numOfLine = 0;
		while (in.hasNextLine()) {
			
			numOfLine++;
			String line = in.nextLine();
			
			String[] reservations = line.split(", ");
			
			for (String reservation : reservations) {


				if( !(RecognisePatterns.verifyParkingReservations(reservation)) ) {

					outputStr.append("Parking Reservation ").append(reservation).append(" on line ").append(numOfLine).append(" is not well formatted!").append(eol);

				}

			}
			
		}
		
		System.out.println(outputStr);
		in.close();
		
	}
}
