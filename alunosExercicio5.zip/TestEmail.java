import static org.junit.Assert.*;

import org.junit.Test;

/**
* Skeleton to create the four classes of testing for exercise number 5
*
* JUnit Tests for the method isValidStudentEmail of the class RecognisePatterns
*
* Characteristic number 1
* Description: the email starts with the lower-case sequence 'fc'
* Regions: true or false 
*
* Characteristic number 2
* Description: the email contains 5 digits
* Regions: true or false 
*
* Characteristic number 3
* Description: the email ends with the lower-case sequence '@alunos.fc.ul.pt'
* Regions: true  or false 
*
* Total number of viable combinations: 8
*
* @author LabP team
*
*/

public class TestEmail {

	@Test
	/**
	 * Test an email showing the right format
	 *   starts with the lower-case sequence 'fc': true
	 *   contains 5 digits : true
	 *   ends with the sequence '@alunos.fc.ul.pt': true
	 */
	public void testIsValidStudentEmail1 () {	
		assertTrue(RecognisePatterns.isValidStudentEmail("fc12345@alunos.fc.ul.pt"));
	}

	@Test
	/**
	 * Test an email with the wrong number of digits
	 *   starts with the lower-case sequence 'fc': true
	 *   contains 5 digits : false
	 *   ends with the lower-case sequence '@alunos.fc.ul.pt': true
	 */
	public void testIsValidStudentEmail3 () {	
		assertFalse(RecognisePatterns.isValidStudentEmail ("fc1234@alunos.fc.ul.pt"));
	}
	

}
