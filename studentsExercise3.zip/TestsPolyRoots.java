import static org.junit.Assert.*;

import org.junit.Test;

/**
 * This class  tests the methods in class Recursive
 * @author LabP team
 *
 */
public class TestsPolyRoots {

	// DELTA represents the required precision for calculated double values
	public static final double DELTA = 0.0001;

	@Test
	public void testFind2Roots1 () {

		double[] obtained = PolyRoots.find2Roots("input1.poly");
		double[] expected = new double[] {1.5,3.0};
		assertArrayEquals(expected, obtained, DELTA);
	}
	@Test
	public void testFind2Roots2 () {
		double[] obtained= PolyRoots.find2Roots("input2.poly");
		double[] expected = new double[] {-1.0, 3.0};
		assertArrayEquals(expected, obtained, DELTA);				
	}
	@Test 
	public void testFind2Roots3() { 
		double[]  obtained = PolyRoots.find2Roots("input3.poly");
		double[] expected = new double[] {-1.0,0.2};
		assertArrayEquals(expected, obtained, DELTA);
	}
}
