import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;

/**
 * Executes some simple calls of the method find2Roots defined in class PolyRoots
 * 
 * @author LabP Team
 *
 **/
public class RunPolyRoots {
	
	/**
	 * Executes some calls to test the method find2Roots of class PolyRoots
	 * @param args Not used
	 * @throws FileNotFoundException 
	 *  
	 */
	public static void main(String[] args) throws FileNotFoundException {
		
		PrintWriter out = new PrintWriter("myOutput.txt");
		
		for(int i = 1 ; i <= 3 ; i++) {
			double[] roots = PolyRoots.find2Roots("input" + i + ".poly");
			printResults(out, "input" + i + ".poly", roots);			
		}
				
		out.close();
		
		}
	
	/**
	 * Print the obtained results in a file
	 * @param fileTo The file where to print
	 * @param from The name of the input file from which the given results were obtained
	 * @param roots The results to print
	 * @requires fileTo != null && from != null && roots != null && roots.length == 2
	 */
	private static void printResults(PrintWriter fileTo, String from, double[] roots) {
		fileTo.println("The 2 roots found for the polynomial in file " + from + " are:");
		fileTo.println(roots[0] + " and " + roots[1]);
		fileTo.println("===============");
	}
}
	
