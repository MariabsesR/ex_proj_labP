/**
 *
 * @author LabP team
 *
 */
public enum BookingStatus {
    VALID_BOOKING, BAD_FORMAT, DUPLICATE_VEHICLE, UNKNOWN_VEHICLE_TYPE, INVALID_TIME, MINIMUM_LENGTH
}
