import static org.junit.Assert.*;

import org.junit.Test;

/**
* JUnit Tests for project3
*
* @author LabP team
*
*/
public class TestsProject3 {

    @Test
    public void testLoad () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:25,4.3), "
    			+ "3348xh-car (12:15,4.5), 2143ad-van (22:05,5.9), 3421re-van (11:05,5.4), "
    			+ "9345wq-van (14:35,4.9), 3367ui-moto (10:45,2.2), 2115aq-moto (11:35,2.4)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	myParking.parkVehicles(booking);

        assertTrue(!myParking.isEmpty());

    }
    
    @Test
    public void testUnLoadOneByOne () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:25,4.3)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);
		if ( BookingStatus.VALID_BOOKING.equals(bStatus))
			myParking.parkVehicles(booking);
    	
    	String[] vehicles = {"7710rm", "7880lm", "2355xf"};
    	
    	for(int i = 0; i < vehicles.length; i++) {
    		assertTrue( myParking.pickVehicle(vehicles[i]));	
    	}

    	assertTrue(myParking.isEmpty());
    	
    }
    
    @Test
    public void testUnLoadOneShot () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:25,4.3)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);
    	if ( BookingStatus.VALID_BOOKING.equals(bStatus))
    		myParking.parkVehicles(booking);
    	
    	myParking.free();

    	assertTrue(myParking.isEmpty());
    	
    }

	@Test
    public void testBadFormat () { 

    	String wo_plate = "2355xf-car (12:15,4.5), van (08:21,5.9), 3421re-van (11:05,5.4)";
    	
    	String wo_type = "2355xf (12:15,4.5), 2143ad-van (08:21,5.9), 3421re-van (11:05,5.4)";
    			
    	String wo_time = "2355xf-car (11:05,3.6), 7880lm-car (4.0), 7710rm-car (13:25,4.3)";
    	
    	String wo_length = "2355xf-car (12:15,4.5), 2143ad-van (08:21), 3421re-van (11:05,5.4)";

    	String[] bad_formats = {wo_plate, wo_type,wo_time,wo_length};
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	
    	for (int i = 0; i < bad_formats.length; i++) {

        	BookingStatus bStatus = myParking.validBooking(bad_formats[i]);

            assertEquals(BookingStatus.BAD_FORMAT, bStatus);
            
    	}

    }
    
    
    @Test
    public void testDuplicateVehicle () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:25,4.3), "
    			+ "2355xf-car (12:15,4.5), 2143ad-van (22:05,5.9), 3421re-van (11:05,5.4)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);

        assertEquals(BookingStatus.DUPLICATE_VEHICLE, bStatus);

    }
    
    @Test
    public void testUnknownVehicleType () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:25,4.3), "
    			+ "3399xf-car (12:15,4.5), 2143ad-van (22:05,5.9), 3421re-truck (11:05,10.4)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);

        assertEquals(BookingStatus.UNKNOWN_VEHICLE_TYPE, bStatus);

    }
    
    @Test
    public void testInvalidTime () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13,4.3), "
    			+ "3399xf-car (12:15,4.5), 2143ad-van (22:05,5.9), 3421re-car (11:05,4.4)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);

        assertEquals(BookingStatus.INVALID_TIME, bStatus);

    }
    
    @Test
    public void testMinimumLength () {

    	String booking = "2355xf-car (11:05,3.6), 7880lm-car (12:05,4.0), 7710rm-car (13:00,4.3), "
    			+ "3399xf-car (12:15,4.5), 3367ui-moto (10:45,1.9), 3421re-car (11:05,4.4)";
    	
    	double size_floor3 = 9.1, size_floor2 = 10.2, size_floor1 = 20.5;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);
    	
    	BookingStatus bStatus = myParking.validBooking(booking);

        assertEquals(BookingStatus.MINIMUM_LENGTH, bStatus);
        
    }
    
}

