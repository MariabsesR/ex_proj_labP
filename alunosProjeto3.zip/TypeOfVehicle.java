/**
 *
 * @author LabP team
 *
 */
public enum TypeOfVehicle {
	CAR("car"), VAN("van"), MOTO("moto");
	
	private final String value;

	TypeOfVehicle (String value) {
	        this.value = value;
	}
	
	public static TypeOfVehicle findByValue(String value) {
		TypeOfVehicle result = null;
	    for (TypeOfVehicle v : values()) {
	        if (v.getValue().equalsIgnoreCase(value)) {
	            result = v;
	            break;
	        }
	    }
	    return result;
	}

	private String getValue() {
		// TODO Auto-generated method stub
		return this.value;
	}
}
