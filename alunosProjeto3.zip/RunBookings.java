import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class is to be used by students to test their solution to the Project 3
 * of LabP
 *
 * @author LabP team
 *
 */
public class RunBookings {

    /**
     * This testing method creates an object ParkingLot and reads files containing booking requests for the created parking lot.
     * For each booking request it asks the ParkingLot whether they are valid descriptions and for those that are valid, 
     * it asks the ParkingLot to print the parking instructions.
     *
     * @param args Not used
     * @throws FileNotFoundException if the input files with the booking requests are not present in the project root directory
     */
    public static void main(String[] args) throws FileNotFoundException {

    	// create a parking-lot with three floors
    	double size_floor3 = 9.0, size_floor2 = 12.0, size_floor1 = 20;
    	ParkingLot myParking = new ParkingLot(size_floor1, size_floor2, size_floor3);

    	Scanner reader;
    	String[] inputFiles = {"reserva1.txt", "reserva2.txt", "reserva3.txt"};

	    System.out.println("===========================================================");
    	System.out.println("Reading available bookings...\n");
	
    	for (int i = 0; i < inputFiles.length; i++) {
    		
    		System.out.println("Loading booking in " + inputFiles[i] + "...");
    		reader = new Scanner(new File(inputFiles[i]));
		
    		// the booking is stored into a single line of the input line
    		String booking = reader.nextLine();
		
    		// check whether or not the booking is valid
    		BookingStatus bStatus = myParking.validBooking(booking);
    		System.out.println("The booking in " + inputFiles[i] + " is " + bStatus + "\n");
		
    		if ( BookingStatus.VALID_BOOKING.equals(bStatus)) {
    			
    			String parkingDescription = myParking.parkVehicles(booking);
        		System.out.println("The booking has generated the following actions:");
        		System.out.println(parkingDescription + "\n");
    		
    		}

    		// free the parking lot
    		if(!myParking.isEmpty()) {
    			System.out.println("Unloading the parking lot...\n");
    			myParking.free();
    		}
    		
    		// close the reader
    		reader.close();
    	}

    	System.out.println("===========================================================");

    }

}