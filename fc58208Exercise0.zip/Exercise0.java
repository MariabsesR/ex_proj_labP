import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.File;


/**
 * Analyzes the information of input file , applies a transformation and puts the content in  the output file
 * 
 * 
 * @author Maria Rocha fc58208
 *
 */

public class Exercise0 {
	
	private static Scanner sc;
	private static PrintWriter out;
	

	/**
	 * Copies the content of the input file to the output file
	 * 
	 * @param fileIn name of the file that needs to be copied
	 * @param fileOut name of the file where it will be copied to
	 * @throws FileNotFoundException
	 * @requires The input file must not be null  
	 */
	
	 public  static  void copyText (String  fileIn,  String  fileOut) throws FileNotFoundException {
		
		sc = new Scanner (new File(fileIn));
		out = new PrintWriter (fileOut);
		
		
		while(sc.hasNext()) {
			
		out.println(sc.nextLine());
			
		}
		out.close();
		sc.close();
		
	}
	 
	 
	/**
	 *  writes in a new file the squares of the numbers on the input file
	 *  
	 * @param fileIn  name of the file with the input
	 * @param fileOut name of the file with the output
	 * @throws FileNotFoundException 
	 * @requires each line of {@code new File(fileIn)} must only have 1 integer
	 * @requires The input file must not be null 
	 */
	 
	 public  static  void  writeSquares  (String  fileIn,  String  fileOut) throws FileNotFoundException {
		 
		 
		 out = new PrintWriter (fileOut);
		 sc = new Scanner (new File(fileIn));
		 int num;
		 
		 while(sc.hasNext()) {
			 num = sc.nextInt();
			out.println(num*num);	 
			 
		 }
		 out.close();
		 sc.close();
		 
	 }
	 
	 
	 /**
	  * writes in a new file the text of the input file converting the letters to 
	  * to lower case and the next line to upper case, every 2  lines 
	  * 
	  * @param fileIn  name of the file with the input
	  * @param fileOut name of the file with the output
	  * @throws FileNotFoundException
	  * @requires The input file must not be null 
	  */
	 
	 public  static  void  lowerUpper  (String  fileIn,  String  fileOut)  throws  FileNotFoundException{
		   
		    sc = new Scanner (new File(fileIn));
			out = new PrintWriter (fileOut);
			int counter=0 ;
			while(sc.hasNextLine()){
				
			  if(counter%2!=0) {
				  out.println(sc.nextLine().toUpperCase());
			  }else 
				  out.println(sc.nextLine().toLowerCase());
			  counter++ ;
			}
			  
			out.close();
			sc.close();	 
	 }
	 
	 /**
	  * The integer that appear both  on the input file and the array will be copied to he output file
	  * 
	  * @param fileIn  name of the file with the input
	  * @param fileOut name of the file with the output
	  * @param values array that contains integers
	  * @throws FileNotFoundException
	  * @requires each line of {@code fileIn} must only have 1 integer
	  * @requires The input file must not be null 
	  * @requires {@code values !=null}
	  */
	 
	 public static void commonElements (String fileIn, String fileOut,  int[]  values)  throws  FileNotFoundException { 	 
	 
		 out = new PrintWriter (fileOut);
		 sc = new Scanner (new File(fileIn));
		 int num;
		 
		 while(sc.hasNext()) {
			 num = sc.nextInt();
			 for(int i =0 ; i<values.length;i++) {
				 if(num == values[i]) {
					out.println(num);
				 }
			 }
		 }	 
		 out.close();
		 sc.close();
  }	 
	 
	 
	 /**
	  * Integers in  input file that are multiples of the given integer will
	  * be copied to the output file
	  * 
	  * @param fileIn  name of the file with the input
	  * @param fileOut name of the file with the output
	  * @param n integer 
	  * @throws FileNotFoundException
	  * @requires each line of {@code fileIn} must only have 1 integer
	  * @requires The input file must not be null 
	  * 
	  */
	 
	 public static void writeMultiples (String fileIn, String  fileOut, int n) throws FileNotFoundException	 {
	 
		 out = new PrintWriter (fileOut);
		 sc = new Scanner (new File(fileIn));
		 int num;
		 
		 while(sc.hasNext()) {
			 num = sc.nextInt();
			 if(n==0 && num==0 ) {
				 out.println(num); 
			 }   
			 if(n!=0 && num%n==0 ) {
				out.println(num);
				
				  
			 }
		 }
		 out.close();
		 sc.close();
	 }
	 
	 
	 
} 