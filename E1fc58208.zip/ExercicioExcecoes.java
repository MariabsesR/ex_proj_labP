
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 
 * @author Maria Rocha fc58208
 * 
 *         Ler vetor de inteiros e uma potencia e imprimir os valores das
 *         potencias dos inteiros
 *
 */
public class ExercicioExcecoes {

	/**
	 * 
	 * 
	 * Ler vetor de inteiros e uma potencia e imprimir os valores das potencias dos
	 * inteiros
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(new File(args[0]))) {

			int tamanho = lerTamanhoVetor(sc);
			int[] inteiros = lerInteirosVetor(sc, tamanho);
			double potencia = lerValorPotencia(sc);

			if (potencia < 0) {
				throw new IllegalArgumentException("A potencia foi negativa ");
			}
			double[] calculados = calculaPotencias(inteiros, potencia);
			imprimirVetor(calculados);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			System.out.println("O Input nao pode ser convertida para um numero");

		} catch (InputMismatchException e) {
			System.out.println(e.getMessage());

		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());

		} catch (FileNotFoundException e) {
			System.out.println("O ficheiro nao foi encontrado ou nao existe");

		} catch (IOException e) {
			System.out.println(e.getMessage()); //
		}

	}

	/**
	 * Ler e devolver o tamanho do vetor original
	 * 
	 * @param sc - o scanner usado para a leitura
	 * @return o tamanho do vetor a ler
	 * @throws IOException,NumberFormatException
	 * @requires sc != null
	 */
	public static int lerTamanhoVetor(Scanner sc) throws IOException, NumberFormatException {

		if (sc.hasNextLine() == false) {
			throw new IOException("O ficheiro de input encontra se vazio ");

		} else {
			int num = Integer.parseInt(sc.nextLine());
			if (num < 0) {
				throw new InputMismatchException("A primeira linha do ficheiro nao representa um inteiro positivo");
			}
			return num;
		}
	}

	/**
	 * Ler um dado numero de inteiros e guardar num vetor
	 * 
	 * @param sc      - o scanner usado para a leitura
	 * @param tamanho - o numero de valores a ler
	 * @return o vetor de inteiros obtidos da leitura
	 * @throws IOException, NumberFormatException
	 * @requires sc != null && tamanho > 0
	 */
	public static int[] lerInteirosVetor(Scanner sc, int tamanho) throws IOException, NumberFormatException {

		int[] vetor;
		int counter;

		if (sc.hasNextLine() == false) {
			throw new IOException("Nao existe mais linhas no ficheiro");
		} else {

			counter = 0;
			String[] line = sc.nextLine().split(" ");
			vetor = new int[line.length];
			for (int i = 0; i < line.length; i++) {

				counter++;
				vetor[i] = Integer.parseInt(line[i]);
			}
			if (counter != tamanho) {
				throw new InputMismatchException(
						"O valor do parametro tamanho nao e igual ao numero de inteiros na linha 2");

			} // deveria ter como else ou como sai do programa nao necessita
				// so deve retornar se nao houver erro
			return vetor;

		}

	}

	/**
	 * Ler um valor que representa a potencia
	 * 
	 * @param sc - o scanner usado para a leitura
	 * @return o valor obtido da leitura
	 * @requires sc != null
	 * @throws NumberFormatException
	 */
	public static double lerValorPotencia(Scanner sc) throws NumberFormatException {

		return Double.parseDouble(sc.nextLine());
	}

	/**
	 * Determina as potencias de um vector
	 * 
	 * @param inteiros - o vetor original
	 * @param potencia - a potencia que se pretende calcular do vetor de inteiros
	 * @return o vetor com as potencias de inteiros
	 * @requires inteiros != null && potencia >= 0
	 */
	private static double[] calculaPotencias(int[] inteiros, double potencia) {
		double[] newVec = new double[inteiros.length];
		for (int i = 0; i < inteiros.length; i++) {
			int num = inteiros[i];
			newVec[i] = Math.pow(num, potencia);
			if (Double.isNaN(newVec[i])) {
				throw new ArithmeticException(
						"O double com o indice " + i + " e um NaN quando a sua potencia � " + potencia);
			}
		}
		return newVec;
	}

	/**
	 * Imprime os valores de um vetor de doubles
	 * 
	 * @param v - o vetor do qual se quer imprimir os valores
	 * @requires {@code v!=null}
	 */
	private static void imprimirVetor(double[] v) {
		for (double d : v) {
			System.out.println(d);
		}
	}

}
