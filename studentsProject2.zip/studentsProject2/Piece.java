import java.util.Random;
public class Piece {


	public static final int DIM = 3;

	public Piece (Cell[][] shape) {
	}

	public Piece (Cell type) {
	}

	public Piece (Random generator) {
	}	

	public int weight() {
		return -1;
	}

	public Cell[][] getCells() {
		return null;
	}

	public void flipVertical() {
	}

	public void flipHorizontal() {
	}

	public void rotate90() {
	}

	
	@Override
	public String toString() {
		return null;
	}


	public boolean isEqual(Piece other) {
		return false;
	}
	

	public boolean fits(Piece outro) {
		return false;
	}



	public Piece merge(Piece outro) {
		return null;
	}


	public Piece copy() {
		return null;
	}


}
