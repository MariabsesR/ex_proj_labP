import java.util.Random;

public class Game {

	public Game(int dificuldade, Random generator) {
	}


	public Game(int linhas, int colunas, int dificuldade, Random generator) {
	}

	public Piece getCurrentPiece() {
		return null;
	}

	public boolean isFinished() {
		return false;
	}

	public void rotatePiece(int n) {
	}

	public void flipHorizontal() {
	}

	public void flipVertical() {
	}


	@Override
	public String toString() {
		return null;
	}


	public void play(int linha, int coluna) {
	}



	public int getScore() {
		return -1;
	}

}
